import * as React from 'react';
/**
 * Format search result descriptions cleanly:
 * - Replaces <ddd/> tags with standard ellipsis "..."
 * - Wraps <c0>...</c0> highlighted query matches in beautiful themed highlight spans
 * - Dynamically matches background/color with the file brand accent color
 * - Debounces / handles manual highlights when no SharePoint tags are present (fallbacks)
 */
export declare const getCleanSharePointUrl: (webUrl: string, title: string) => string;
export declare const getSharePointThumbnailUrl: (webUrl: string, title: string, resolution?: number) => string;
export declare const renderFormattedSummary: (summary: string, query?: string, highlightColor?: string) => React.ReactNode;
//# sourceMappingURL=SearchHelpers.d.ts.map