/**
 * Format a byte count into a human-readable string.
 */
export declare function formatFileSize(bytes: number): string;
/**
 * Format an ISO date string into a short readable form.
 */
export declare function formatDate(iso: string): string;
/**
 * Truncate text to a max length.
 */
export declare function truncate(text: string, maxLength?: number): string;
/**
 * Get a colour class name based on file type.
 */
export declare function getFileTypeColor(fileType: string): string;
/**
 * Get the display badge label for a file type.
 */
export declare function getFileTypeBadge(fileType: string): string;
/**
 * Extract the project hub display name from a URL.
 */
export declare function getSiteDisplayUrl(url: string): string;
//# sourceMappingURL=Helpers.d.ts.map