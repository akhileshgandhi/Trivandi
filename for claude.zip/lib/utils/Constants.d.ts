export declare const PAGE_SIZE = 20;
export declare const FILE_TYPE_OPTIONS: ({
    key: string;
    text: string;
    count: any;
} | {
    key: string;
    text: string;
    count?: undefined;
})[];
export declare const DATE_OPTIONS: {
    key: string;
    text: string;
}[];
export declare const SEARCH_PLACEHOLDER = "Search documents, pages, files...";
//# sourceMappingURL=Constants.d.ts.map