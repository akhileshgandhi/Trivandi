import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
import '../../styles/PremiumSearch.module.scss';
export interface IGlobalSearchCustomizerApplicationCustomizerProperties {
    testMessage: string;
}
export default class GlobalSearchCustomizerApplicationCustomizer extends BaseApplicationCustomizer<IGlobalSearchCustomizerApplicationCustomizerProperties> {
    private _modalContainer;
    private _observer;
    private _attached;
    private _isModalOpen;
    onInit(): Promise<void>;
    private _createModalContainer;
    private _interceptSearchBar;
    private _attachListeners;
    private _openModal;
    private _closeModal;
    onDispose(): void;
}
//# sourceMappingURL=GlobalSearchCustomizerApplicationCustomizer.d.ts.map