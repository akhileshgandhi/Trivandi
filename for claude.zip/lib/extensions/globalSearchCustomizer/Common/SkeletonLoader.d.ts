import * as React from 'react';
import { ISkeletonLoaderProps } from '../interface/ISkeletonLoaderProps';
export declare const SkeletonLoader: React.FC<ISkeletonLoaderProps>;
//# sourceMappingURL=SkeletonLoader.d.ts.map