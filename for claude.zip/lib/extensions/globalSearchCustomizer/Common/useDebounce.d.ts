export declare function useDebounce<T>(value: T, delay: number): [T, {
    isPending: () => boolean;
    flush: () => void;
    cancel: () => void;
}];
//# sourceMappingURL=useDebounce.d.ts.map