declare const styles: {
    paginationContainer: string;
    pagination: string;
    pageItem: string;
    pageLink: string;
    activePage: string;
    disabledPage: string;
};
export default styles;
//# sourceMappingURL=Pagination.module.scss.d.ts.map