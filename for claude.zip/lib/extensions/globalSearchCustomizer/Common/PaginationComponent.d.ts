import * as React from 'react';
import { IPaginationComponentProps } from '../interface/IPaginationComponentProps';
export declare const PaginationComponent: React.FC<IPaginationComponentProps>;
//# sourceMappingURL=PaginationComponent.d.ts.map