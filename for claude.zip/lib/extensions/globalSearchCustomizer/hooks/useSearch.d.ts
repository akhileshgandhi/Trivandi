import { ISearchResult } from '../../../models/ISearchResult';
import { IUseSearchOptions } from '../interface/IUseSearchOptions';
export declare function useSearch({ service, initialQuery, pageSize }: IUseSearchOptions): {
    query: string;
    setQuery: import("react").Dispatch<import("react").SetStateAction<string>>;
    fileTypes: string[];
    setFileTypes: import("react").Dispatch<import("react").SetStateAction<string[]>>;
    activeTopTab: string;
    setActiveTopTab: import("react").Dispatch<import("react").SetStateAction<string>>;
    date: string;
    setDate: import("react").Dispatch<import("react").SetStateAction<string>>;
    selectedAuthors: string[];
    setSelectedAuthors: import("react").Dispatch<import("react").SetStateAction<string[]>>;
    results: ISearchResult[];
    totalCount: number;
    loading: boolean;
    error: string;
    from: number;
    setFrom: import("react").Dispatch<import("react").SetStateAction<number>>;
    sortBy: string;
    setSortBy: import("react").Dispatch<import("react").SetStateAction<string>>;
    pageSize: number;
    refresh: () => Promise<void>;
};
//# sourceMappingURL=useSearch.d.ts.map