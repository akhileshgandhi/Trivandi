export interface ISkeletonLoaderProps {
    count?: number;
}
//# sourceMappingURL=ISkeletonLoaderProps.d.ts.map