export interface ISearchTabsProps {
    activeTab: string;
    onTabChange: (tab: string) => void;
    onClearAll?: () => void;
}
//# sourceMappingURL=ISearchTabsProps.d.ts.map