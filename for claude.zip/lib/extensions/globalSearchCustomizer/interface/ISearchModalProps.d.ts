export interface ISearchModalProps {
    context: any;
    isOpen: boolean;
    onDismiss: () => void;
}
//# sourceMappingURL=ISearchModalProps.d.ts.map