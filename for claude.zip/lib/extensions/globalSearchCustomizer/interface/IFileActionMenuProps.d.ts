import { ISearchResult } from '../../../models/ISearchResult';
export interface IFileActionMenuProps {
    file: ISearchResult;
    onOpenChange?: (isOpen: boolean) => void;
}
//# sourceMappingURL=IFileActionMenuProps.d.ts.map