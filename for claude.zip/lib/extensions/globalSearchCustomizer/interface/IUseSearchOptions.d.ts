import { GraphSearchService } from '../services/GraphSearchService';
export interface IUseSearchOptions {
    service: GraphSearchService | null;
    initialQuery?: string;
    pageSize?: number;
}
//# sourceMappingURL=IUseSearchOptions.d.ts.map