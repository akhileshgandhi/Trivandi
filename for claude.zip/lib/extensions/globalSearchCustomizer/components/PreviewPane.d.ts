import * as React from 'react';
import { IDocumentAnalysisProps } from '../interface/IDocumentAnalysisProps';
export declare const PreviewPane: React.FC<IDocumentAnalysisProps>;
//# sourceMappingURL=PreviewPane.d.ts.map