import * as React from 'react';
import { IResultCardProps } from '../interface/IResultCardProps';
export declare const ResultCard: React.FC<IResultCardProps>;
//# sourceMappingURL=ResultCard.d.ts.map