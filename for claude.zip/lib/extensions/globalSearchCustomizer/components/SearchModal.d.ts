import * as React from 'react';
import { ISearchModalProps } from '../interface/ISearchModalProps';
export default function SearchModal({ context, isOpen, onDismiss }: ISearchModalProps): React.ReactElement | null;
//# sourceMappingURL=SearchModal.d.ts.map