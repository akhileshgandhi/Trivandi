import * as React from 'react';
import { ISearchTabsProps } from '../interface/ISearchTabsProps';
export declare const SearchTabs: React.FC<ISearchTabsProps>;
//# sourceMappingURL=SearchTabs.d.ts.map