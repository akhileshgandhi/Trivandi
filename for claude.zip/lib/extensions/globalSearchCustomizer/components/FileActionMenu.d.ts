import * as React from 'react';
import { IFileActionMenuProps } from '../interface/IFileActionMenuProps';
export declare const FileActionMenu: React.FC<IFileActionMenuProps>;
//# sourceMappingURL=FileActionMenu.d.ts.map