import * as React from 'react';
import { ISearchHistoryProps } from '../interface/ISearchHistoryProps';
export declare const HistoryPane: React.FC<ISearchHistoryProps>;
//# sourceMappingURL=HistoryPane.d.ts.map