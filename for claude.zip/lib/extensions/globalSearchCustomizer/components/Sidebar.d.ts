import * as React from 'react';
import { IFiltersPanelProps } from '../interface/IFiltersPanelProps';
export declare const Sidebar: React.FC<IFiltersPanelProps>;
//# sourceMappingURL=Sidebar.d.ts.map