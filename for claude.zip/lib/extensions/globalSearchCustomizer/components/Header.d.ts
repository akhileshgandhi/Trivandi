import * as React from 'react';
import { IHeaderProps } from '../interface/IHeaderProps';
export declare const Header: React.FC<IHeaderProps>;
//# sourceMappingURL=Header.d.ts.map