import * as React from 'react';
import { IDetailPanelProps } from '../interface/IDetailPanelProps';
export declare const DetailPanel: React.FC<IDetailPanelProps>;
//# sourceMappingURL=DetailPanel.d.ts.map