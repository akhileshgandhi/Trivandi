import * as React from 'react';
import { ISearchResultsListProps } from '../interface/ISearchResultsListProps';
export declare const SearchResultsList: React.FC<ISearchResultsListProps>;
//# sourceMappingURL=SearchResultsList.d.ts.map