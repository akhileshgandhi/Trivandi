import { ISearchStore } from '../interface/ISearchStore';
export declare const useSearchStore: import("zustand").UseBoundStore<Omit<import("zustand").StoreApi<ISearchStore>, "persist"> & {
    persist: {
        setOptions: (options: Partial<import("zustand/middleware").PersistOptions<ISearchStore, ISearchStore>>) => void;
        clearStorage: () => void;
        rehydrate: () => void | Promise<void>;
        hasHydrated: () => boolean;
        onHydrate: (fn: (state: ISearchStore) => void) => () => void;
        onFinishHydration: (fn: (state: ISearchStore) => void) => () => void;
        getOptions: () => Partial<import("zustand/middleware").PersistOptions<ISearchStore, ISearchStore>>;
    };
}>;
//# sourceMappingURL=useSearchStore.d.ts.map