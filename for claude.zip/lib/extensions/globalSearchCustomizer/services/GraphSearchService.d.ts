import { MSGraphClientFactory } from '@microsoft/sp-http';
import { ISearchResult } from '../../../models/ISearchResult';
export declare class GraphSearchService {
    private _msGraphClientFactory;
    constructor(msGraphClientFactory: MSGraphClientFactory);
    search(query: string, pageSize?: number, from?: number, fileTypes?: string[], activeTopTab?: string, date?: string, selectedAuthors?: string[], sortBy?: string): Promise<{
        results: ISearchResult[];
        totalCount: number;
    }>;
    private sortAuthorsList;
    getAuthors(query?: string): Promise<string[]>;
}
//# sourceMappingURL=GraphSearchService.d.ts.map