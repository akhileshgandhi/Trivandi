export interface IPromotedResult {
    id: string;
    keywordMatches: string[];
    title: string;
    description: string;
    url: string;
    category: string;
    type: string;
}
export declare class PromotedResultsService {
    private static promotedList;
    /**
     * Matches a search query against keyword arrays and returns matches
     */
    static getPromotedResults(query: string): IPromotedResult[];
}
//# sourceMappingURL=PromotedResultsService.d.ts.map