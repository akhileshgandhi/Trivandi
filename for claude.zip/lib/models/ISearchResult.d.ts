export interface ISearchResult {
    id: string;
    title: string;
    webUrl: string;
    fileType: string;
    lastModified: string;
    author: string;
    size: number;
    summary: string;
    siteUrl: string;
    siteName: string;
    isStarred?: boolean;
    thumbnailUrl?: string;
    createdDate?: string;
    objectType?: string;
}
//# sourceMappingURL=ISearchResult.d.ts.map