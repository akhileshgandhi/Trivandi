export interface ISearchFilters {
    fileType?: string;
    author?: string;
    modifiedDate?: string;
    specificDate?: string;
    site?: string;
}
//# sourceMappingURL=ISearchFilters.d.ts.map