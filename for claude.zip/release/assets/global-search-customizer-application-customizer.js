(()=>{ var __RUSHSTACK_CURRENT_SCRIPT__ = document.currentScript; define("a886704a-9718-4402-8f93-bf183172c188_0.0.1", ["@microsoft/sp-application-base","react","react-dom"], (__WEBPACK_EXTERNAL_MODULE__8023__, __WEBPACK_EXTERNAL_MODULE__2650__, __WEBPACK_EXTERNAL_MODULE__2729__) => { return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 746:
/*!****************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/Common/Pagination.module.css ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 1919);
// Imports


_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".paginationContainer_0ede9947{align-items:center;display:flex;justify-content:center;padding:1rem;width:100%}.paginationContainer_0ede9947 .pagination_0ede9947{align-items:center;display:flex;gap:8px;list-style:none;margin:0;padding:0}.paginationContainer_0ede9947 .pagination_0ede9947 .pageItem_0ede9947{display:flex}.paginationContainer_0ede9947 .pagination_0ede9947 .pageItem_0ede9947 .pageLink_0ede9947{align-items:center;border:1px solid transparent;border-radius:6px;color:#64748b;cursor:pointer;display:flex;font-size:13px;font-weight:500;height:32px;justify-content:center;min-width:32px;padding:0 8px;transition:all .2s ease}.paginationContainer_0ede9947 .pagination_0ede9947 .pageItem_0ede9947 .pageLink_0ede9947:hover{background:#f1f5f9;color:#0f172a}.paginationContainer_0ede9947 .pagination_0ede9947 .activePage_0ede9947 .pageLink_0ede9947{background:#1a73e8;border-color:#1a73e8;color:#fff;font-weight:600}.paginationContainer_0ede9947 .pagination_0ede9947 .activePage_0ede9947 .pageLink_0ede9947:hover{background:#1557b0;color:#fff}.paginationContainer_0ede9947 .pagination_0ede9947 .disabledPage_0ede9947 .pageLink_0ede9947{cursor:not-allowed;opacity:.5}.paginationContainer_0ede9947 .pagination_0ede9947 .disabledPage_0ede9947 .pageLink_0ede9947:hover{background:0 0;color:#64748b}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvdXNlci9NYW5hc3ZpL1NoYXJlUG9pbnQvVHJpdmFuZGlpaWlpaWlpaWlpaS9Ucml2YW5kaS9zcmMvZXh0ZW5zaW9ucy9nbG9iYWxTZWFyY2hDdXN0b21pemVyL0NvbW1vbi9QYWdpbmF0aW9uLm1vZHVsZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDhCQUdFLGtCQUFBLENBRkEsWUFBQSxDQUNBLHNCQUFBLENBRUEsWUFBQSxDQUNBLFVBQUEsQ0FFQSxtREFNRSxrQkFBQSxDQUxBLFlBQUEsQ0FFQSxPQUFBLENBREEsZUFBQSxDQUdBLFFBQUEsQ0FEQSxTQUVBLENBRUEsc0VBQ0UsWUFBQSxDQUVBLHlGQUVFLGtCQUFBLENBV0EsNEJBQUEsQ0FOQSxpQkFBQSxDQUdBLGFBQUEsQ0FDQSxjQUFBLENBVkEsWUFBQSxDQU9BLGNBQUEsQ0FDQSxlQUFBLENBSkEsV0FBQSxDQUZBLHNCQUFBLENBQ0EsY0FBQSxDQUVBLGFBQUEsQ0FNQSx1QkFDQSxDQUVBLCtGQUNFLGtCQUFBLENBQ0EsYUFBQSxDQU1KLDJGQUNFLGtCQUFBLENBRUEsb0JBQUEsQ0FEQSxVQUFBLENBRUEsZUFBQSxDQUVBLGlHQUNFLGtCQUFBLENBQ0EsVUFBQSxDQU1KLDZGQUVFLGtCQUFBLENBREEsVUFDQSxDQUVBLG1HQUNFLGNBQUEsQ0FDQSxhQUFBIiwiZmlsZSI6IlBhZ2luYXRpb24ubW9kdWxlLmNzcyJ9 */", true);


/***/ }),

/***/ 7395:
/*!*********************************************!*\
  !*** ./lib/styles/PremiumSearch.module.css ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 1919);
// Imports


_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".overlay_fffcc516{align-items:center;backdrop-filter:blur(12px);background:rgba(15,23,42,.35);display:flex;inset:0;justify-content:center;position:fixed;z-index:99999}.overlay_fffcc516,.overlay_fffcc516 *{font-family:Segoe UI,-apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif!important}@keyframes modalFadeIn_fffcc516{0%{opacity:0;transform:scale(.985)}to{opacity:1;transform:scale(1)}}.modal_fffcc516{animation:modalFadeIn_fffcc516 .3s cubic-bezier(.16,1,.3,1) forwards;background:#fff;display:flex;flex-direction:column;font-family:Segoe UI,-apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;inset:0;overflow:hidden;position:fixed;z-index:100000}.body_fffcc516{background:#f8fafc}.body_fffcc516,.mainLayout_fffcc516{display:flex;flex:1;overflow:hidden;position:relative}.header_fffcc516{align-items:center;background:#fff;border-bottom:1px solid #e2e8f0;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);display:flex;flex-shrink:0;height:64px;justify-content:space-between;padding:0 32px;position:relative;z-index:50}.logoWrapper_fffcc516{align-items:center;display:flex;gap:12px}.logoSvg_fffcc516{height:32px;width:auto}.logoText_fffcc516{fill:#1a73e8;font-size:24px;font-weight:700;letter-spacing:-.02em}.closeBtn_fffcc516{background:0 0;border:none;border-radius:9999px;color:#64748b;cursor:pointer;display:flex;padding:8px;transition:all .15s cubic-bezier(.4,0,.2,1)}.closeBtn_fffcc516:hover{background:#f1f5f9;color:#1e293b}.searchBarContainer_fffcc516{flex:0 0 672px!important;max-width:672px!important;min-width:672px!important;position:relative!important;width:672px!important}.searchBarWrapper_fffcc516{max-width:100%!important;position:relative!important;width:100%!important}.searchIcon_fffcc516{align-items:center;color:#94a3b8;display:flex;left:18px;pointer-events:none;position:absolute;top:50%;transform:translateY(-50%) scale(1);transition:all .15s cubic-bezier(.4,0,.2,1)}.searchBarWrapper_fffcc516:focus-within .searchIcon_fffcc516{color:#1a73e8;transform:translateY(-50%) scale(1.08)}.searchInput_fffcc516{background:rgba(248,250,252,.7);border:1px solid rgba(226,232,240,.8);border-radius:9999px;box-shadow:inset 0 2px 4px 0 rgba(0,0,0,.02),0 2px 8px -2px rgba(100,116,139,.06);color:#1e293b;font-size:14.5px;font-weight:500;height:44px;outline:0;padding-left:50px;padding-right:44px;transition:all .25s cubic-bezier(.4,0,.2,1);width:100%}.searchInput:-ms-input-placeholder{color:rgba(148,163,184,.8)}.searchInput_fffcc516:-ms-input-placeholder{color:rgba(148,163,184,.8)}.searchInput_fffcc516::placeholder{color:rgba(148,163,184,.8)}.searchInput_fffcc516:focus{background:#fff;border-color:rgba(26,115,232,.7);box-shadow:0 4px 20px rgba(26,115,232,.06),0 0 0 3px rgba(26,115,232,.12)}.logoImage_fffcc516{display:block;height:100px;object-fit:contain;width:150px}.searchClearBtn_fffcc516{align-items:center!important;background:0 0!important;border:none!important;border-radius:9999px!important;color:#94a3b8!important;cursor:pointer!important;display:flex!important;justify-content:center!important;left:auto!important;padding:6px!important;position:absolute!important;right:16px!important;top:50%!important;transform:translateY(-50%) scale(1)!important;transition:all .15s cubic-bezier(.4,0,.2,1)!important;z-index:10!important}.searchClearBtn_fffcc516:hover{background:#f1f5f9;color:#334155;transform:translateY(-50%) scale(1.08)}@keyframes slideDownFade_fffcc516{0%{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}.searchSuggestionBox_fffcc516{animation:slideDownFade_fffcc516 .2s cubic-bezier(.16,1,.3,1);background:#fff;border:1px solid rgba(226,232,240,.8);border-radius:16px;box-shadow:0 10px 30px -10px rgba(15,23,42,.12);left:0;margin-top:8px;overflow:hidden;position:absolute;right:0;top:100%;z-index:100}.suggestionHeader_fffcc516{background:#f8fafc;border-bottom:1px solid #f1f5f9;color:#94a3b8;font-size:10px;font-weight:700;letter-spacing:.1em;padding:10px 18px;text-transform:uppercase}.suggestionItem_fffcc516{align-items:center;background:0 0;border:none;color:#475569;cursor:pointer;display:flex;font-size:13.5px;gap:12px;padding:12px 18px;text-align:left;transition:all .2s ease;width:100%}.suggestionItem_fffcc516:hover{background:rgba(26,115,232,.04);color:#1a73e8;padding-left:22px}.suggestionIcon_fffcc516{color:#cbd5e1;transition:color .2s ease}.suggestionItem_fffcc516:hover .suggestionIcon_fffcc516{color:#1a73e8}.headerMeta_fffcc516{align-items:center;display:flex;gap:16px;justify-content:flex-end}.metaTextContainer_fffcc516{text-align:right}@media (max-width:640px){.metaTextContainer_fffcc516{display:none}}.metaResultsCount_fffcc516{color:#1e293b;font-size:12px;font-weight:600}.metaSubTitle_fffcc516{color:#94a3b8;font-size:9px;font-weight:500;letter-spacing:.08em;margin-top:4px;text-transform:uppercase}.metaDivider_fffcc516{background:#e2e8f0;height:32px;margin:0 4px;width:1px}.sidebar_fffcc516{background:#fff;border-right:1px solid #e2e8f0;box-sizing:border-box;flex-shrink:0;overflow-y:auto;-webkit-user-select:none;-ms-user-select:none;user-select:none}@media (max-width:768px){.sidebar_fffcc516{display:none}}.sidebar_fffcc516::-webkit-scrollbar{display:none}.sidebarInner_fffcc516{display:flex;flex-direction:column;gap:24px;padding:20px}.sidebarTitle_fffcc516{border-b:1px solid #f1f5f9;color:#1e293b;font-size:10px;font-weight:900;letter-spacing:.15em;margin-bottom:16px;padding-bottom:8px;text-transform:uppercase}.sidebarOptionList_fffcc516{display:flex;flex-direction:column;gap:6px}.checkboxLabel_fffcc516{align-items:center;color:#475569;cursor:pointer;display:flex;font-size:15px;font-weight:500;gap:12px}.checkboxLabel_fffcc516:hover{color:#0f172a}.checkboxActive_fffcc516{color:#1a73e8;font-weight:600}.checkboxInput_fffcc516{border:1px solid #cbd5e1;border-radius:4px;color:#1a73e8;cursor:pointer;height:16px;transition:all .15s cubic-bezier(.4,0,.2,1);width:16px}.checkboxInput_fffcc516:focus{box-shadow:0 0 0 3px rgba(26,115,232,.15)}.checkboxBadge_fffcc516{background:#f1f5f9;border-radius:9999px;color:#94a3b8;font-size:10px;font-weight:600;margin-left:auto;padding:2px 8px}.sidebarSectionHeader_fffcc516{align-items:center;border-bottom:1px solid #f1f5f9;color:#1e293b;display:flex;font-size:10px;font-weight:900;justify-content:space-between;letter-spacing:.15em;margin-bottom:12px;margin-top:24px;padding-bottom:8px;text-transform:uppercase}.countLabel_fffcc516{color:#94a3b8;font-weight:500;letter-spacing:normal;text-transform:lowercase}.authorInputWrapper_fffcc516{position:relative}.authorIcon_fffcc516{color:#94a3b8;left:16px;position:absolute;top:50%;transform:translateY(-50%);transition:color .15s cubic-bezier(.4,0,.2,1)}.authorInput_fffcc516{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;box-shadow:inset 0 1px 2px rgba(0,0,0,.05);color:#334155;font-size:14px;font-weight:600;height:36px;outline:0;padding-left:44px;padding-right:16px;transition:all .15s cubic-bezier(.4,0,.2,1);width:100%}.authorInput_fffcc516:focus{background:#fff;border-color:rgba(26,115,232,.2)}.authorDropdown_fffcc516{background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);display:flex;flex-direction:column;left:0;margin-top:8px;max-height:256px;overflow-y:auto;padding:8px 0;position:absolute;right:0;top:100%;z-index:50}.authorDropdown_fffcc516::-webkit-scrollbar{display:none}.authorDropdownItem_fffcc516{align-items:center;background:0 0;border:none;color:#475569;cursor:pointer;display:flex;font-size:14px;gap:8px;padding:8px 16px;text-align:left;transition:all .15s cubic-bezier(.4,0,.2,1);width:100%}.authorDropdownItem_fffcc516:hover{background:#f8fafc;color:#1a73e8}.authorInitialsAvatar_fffcc516{align-items:center;background:#f1f5f9;border-radius:9999px;color:#1e293b;display:flex;font-size:10px;font-weight:600;height:24px;justify-content:center;width:24px}.authorDropdownItem_fffcc516:hover .authorInitialsAvatar_fffcc516{background:rgba(26,115,232,.1);color:#1a73e8}.dateFilterButton_fffcc516{background:0 0;border:none;border-radius:12px;color:#475569;cursor:pointer;font-size:14px;font-weight:500;padding:8px 12px;text-align:left;transition:all .15s cubic-bezier(.4,0,.2,1);width:100%}.dateFilterButton_fffcc516:hover{background:#f1f5f9}.dateFilterActive_fffcc516{background:#1a73e8;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#fff;font-weight:600}.dateFilterActive_fffcc516:hover{background:#1a73e8}.datePickerLabel_fffcc516{color:#1e293b;font-size:10px;font-weight:900;letter-spacing:.15em;margin-bottom:12px;margin-top:24px;padding:0 4px;text-transform:uppercase}.datePickerBox_fffcc516{align-items:center;background:#f8fafc;border:1px solid rgba(226,232,240,.5);border-radius:16px;cursor:pointer;display:flex;gap:8px;padding:8px;position:relative;transition:all .15s cubic-bezier(.4,0,.2,1)}.datePickerBox_fffcc516:hover{background:#fff;border-color:rgba(26,115,232,.3)}.datePickerIcon_fffcc516{color:#1a73e8;display:flex;padding:6px}.dateInput_fffcc516{background:0 0;border:none;color:#334155;cursor:pointer;font-size:14px;font-weight:700;outline:0;width:100%}.dateInput_fffcc516::-webkit-calendar-picker-indicator{cursor:pointer}.sidebarActionWrapper_fffcc516{border-top:1px solid #f1f5f9;display:flex;flex-direction:column;gap:8px;margin-top:auto;padding-top:16px}.applyButton_fffcc516{background:#1a73e8;border:none;border-radius:12px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#fff;cursor:pointer;font-size:16px;font-weight:600;height:40px;transition:all .15s cubic-bezier(.4,0,.2,1);width:100%}.applyButton_fffcc516:hover{background:rgba(26,115,232,.9)}.applyButton_fffcc516:active{transform:scale(.98)}.resetButton_fffcc516{background:0 0;border:none;border-radius:12px;color:#94a3b8;cursor:pointer;font-size:10px;font-weight:700;height:40px;letter-spacing:.1em;text-transform:uppercase;transition:all .15s cubic-bezier(.4,0,.2,1);width:100%}.resetButton_fffcc516:hover{background:#f1f5f9;color:#475569}.resizeHandle_fffcc516{align-items:center;cursor:col-resize;display:flex;flex-shrink:0;justify-content:center;position:relative;width:8px;z-index:110}.resizeHandle_fffcc516,.resizeHandle_fffcc516:after{background:0 0;transition:background .15s cubic-bezier(.4,0,.2,1)}.resizeHandle_fffcc516:after{bottom:0;content:\"\";left:3px;position:absolute;right:3px;top:0}.resizeHandle_fffcc516:hover:after{background:rgba(26,115,232,.2)}.resizeHandle_fffcc516:hover .resizeGrip_fffcc516{background:#1a73e8;border-color:#1a73e8;box-shadow:0 4px 12px rgba(26,115,232,.25);color:#fff;transform:translate(-50%,-50%) scale(1.1)}.resizeHandleActive_fffcc516:after{background:rgba(26,115,232,.4)!important}.resizeHandleActive_fffcc516 .resizeGrip_fffcc516{background:#1557b0!important;border-color:#1557b0!important;box-shadow:0 4px 14px rgba(21,87,176,.3)!important;color:#fff!important;transform:translate(-50%,-50%) scale(1.1)!important}.resizeGrip_fffcc516{align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:6px;box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -2px rgba(0,0,0,.1);color:#475569;display:flex;height:32px;justify-content:center;left:50%;position:absolute;top:50%;transform:translate(-50%,-50%) scale(1);transition:all .15s cubic-bezier(.4,0,.2,1);width:20px;z-index:120}.mainContainer_fffcc516{background:#fff;display:flex;flex:1;flex-direction:column;overflow:hidden}.topTabBar_fffcc516{align-items:center;background:#fff;border-bottom:1px solid #f1f5f9;display:flex;flex-shrink:0;justify-content:space-between;padding:0 24px}.tabButtonsWrapper_fffcc516{display:flex;gap:32px}.topTabItem_fffcc516{background:0 0;border:none;color:#64748b;cursor:pointer;font-size:14px;font-weight:900;padding:12px 4px;position:relative;transition:color .15s cubic-bezier(.4,0,.2,1)}.topTabItem_fffcc516:hover{color:#1e293b}.topTabItemActive_fffcc516,.topTabItemActive_fffcc516:hover{color:#1a73e8}.activeTabLine_fffcc516{background:#1a73e8;border-radius:9999px;bottom:0;height:3px;left:4px;position:absolute;right:4px}.clearAllBtn_fffcc516{align-items:center;background:#f1f5f9;border:1px solid #e2e8f0;border-radius:9999px;color:#1a73e8;cursor:pointer;display:inline-flex;font-size:11px;font-weight:700;justify-content:center;letter-spacing:.05em;padding:6px 16px;text-transform:uppercase;transition:all .15s cubic-bezier(.4,0,.2,1)}.clearAllBtn_fffcc516:hover{background:#e2e8f0;border-color:#cbd5e1;color:#1557b0}.clearAllBtn_fffcc516:active{transform:scale(.96)}.statsBar_fffcc516{align-items:center;background:rgba(248,250,252,.1);border-bottom:1px solid #f1f5f9;display:flex;flex-shrink:0;height:auto;justify-content:space-between;min-height:40px;padding:8px 24px}.statsLeft_fffcc516{align-items:center;display:flex;flex:1;gap:12px}.statsDivider_fffcc516{align-self:center;background-color:#e2e8f0;flex-shrink:0;height:28px;margin:0 16px;width:1px}.statsLabel_fffcc516{color:#334155;font-size:12px;font-weight:700;white-space:nowrap}.filterBadgeWrapper_fffcc516{align-items:center;border-left:1px solid #e2e8f0;display:flex;gap:8px;overflow-x:auto;padding-left:12px}.filterBadge_fffcc516{align-items:center;background:rgba(26,115,232,.08);border:1px solid rgba(26,115,232,.18);border-radius:9999px;box-shadow:0 1px 2px rgba(26,115,232,.05);color:#1a73e8;display:flex;font-size:11px;font-weight:700;gap:8px;letter-spacing:.05em;padding:4px 12px;text-transform:uppercase;transition:all .2s ease;white-space:nowrap}.filterBadge_fffcc516:hover{background:rgba(26,115,232,.12);border-color:rgba(26,115,232,.3);box-shadow:0 2px 4px rgba(26,115,232,.1)}.filterBadgeClose_fffcc516{align-items:center;background:rgba(26,115,232,.1);border:none;border-radius:50%;color:#1a73e8;cursor:pointer;display:flex;justify-content:center;margin-right:-4px;padding:3px;transition:all .2s ease}.filterBadgeClose_fffcc516:hover{background:rgba(26,115,232,.25);color:#1151a5;transform:rotate(90deg)}.historyNavButton_fffcc516{align-items:center;background:#1a73e8;border:none;border-radius:6px;box-shadow:0 2px 4px rgba(26,115,232,.15);color:#fff;cursor:pointer;display:flex;font-size:11px;font-weight:700;gap:5px;padding:4px 10px;transition:all .15s cubic-bezier(.4,0,.2,1)}.historyNavButton_fffcc516:hover{background:rgba(26,115,232,.9)}.historyNavButton_fffcc516 span{font-weight:900}.resultsListWrapper_fffcc516{background:#f8fafc;display:flex;flex:1;flex-direction:column;gap:16px;overflow-y:auto;padding:24px}.resultsListWrapper_fffcc516::-webkit-scrollbar{display:none}.resultCard_fffcc516{background:#fff;border:1px solid #f1f5f9;border-left-width:4px;border-radius:12px;cursor:pointer;display:flex;gap:18px;padding:18px 20px;position:relative;transition:all .25s cubic-bezier(.4,0,.2,1)}@media (max-width:640px){.resultCard_fffcc516{flex-direction:column}}.resultCard_fffcc516:hover{border-color:#e2e8f0;box-shadow:0 12px 24px -10px rgba(15,23,42,.08);transform:translateY(-3px)}.resultCardSelected_fffcc516{box-shadow:0 0 0 2px rgba(26,115,232,.1);transform:scale(1.01)}.resultCardMenuOpen_fffcc516{z-index:50!important}.starIconButtonStarred_fffcc516{color:#fbbf24!important}.cardTitleSelected_fffcc516{font-weight:700}.type_pdf_fffcc516{border-left-color:#00acc1!important}.type_pdf_fffcc516:hover{background:linear-gradient(90deg,rgba(0,172,193,.015),#fff)!important;border-color:rgba(0,172,193,.2) rgba(0,172,193,.2) rgba(0,172,193,.2) #00acc1!important}.type_pdf_fffcc516 .cardIconBox_fffcc516{background-color:rgba(0,172,193,.08)!important;color:#00acc1!important}.type_pdf_fffcc516 .cardTitleSelected_fffcc516,.type_pdf_fffcc516 .projectHubValue_fffcc516{color:#00acc1!important}.type_xlsx_fffcc516{border-left-color:#00796b!important}.type_xlsx_fffcc516:hover{background:linear-gradient(90deg,rgba(0,121,107,.015),#fff)!important;border-color:rgba(0,121,107,.2) rgba(0,121,107,.2) rgba(0,121,107,.2) #00796b!important}.type_xlsx_fffcc516 .cardIconBox_fffcc516{background-color:rgba(0,121,107,.08)!important;color:#00796b!important}.type_xlsx_fffcc516 .cardTitleSelected_fffcc516,.type_xlsx_fffcc516 .projectHubValue_fffcc516{color:#00796b!important}.type_pptx_fffcc516{border-left-color:#e52592!important}.type_pptx_fffcc516:hover{background:linear-gradient(90deg,rgba(229,37,146,.015),#fff)!important;border-color:rgba(229,37,146,.2) rgba(229,37,146,.2) rgba(229,37,146,.2) #e52592!important}.type_pptx_fffcc516 .cardIconBox_fffcc516{background-color:rgba(229,37,146,.08)!important;color:#e52592!important}.type_pptx_fffcc516 .cardTitleSelected_fffcc516,.type_pptx_fffcc516 .projectHubValue_fffcc516{color:#e52592!important}.type_image_fffcc516{border-left-color:#9334e6!important}.type_image_fffcc516:hover{background:linear-gradient(90deg,rgba(147,52,230,.015),#fff)!important;border-color:rgba(147,52,230,.2) rgba(147,52,230,.2) rgba(147,52,230,.2) #9334e6!important}.type_image_fffcc516 .cardIconBox_fffcc516{background-color:rgba(147,52,230,.08)!important;color:#9334e6!important}.type_image_fffcc516 .cardTitleSelected_fffcc516,.type_image_fffcc516 .projectHubValue_fffcc516{color:#9334e6!important}.type_video_fffcc516{border-left-color:#ea4335!important}.type_video_fffcc516:hover{background:linear-gradient(90deg,rgba(234,67,53,.015),#fff)!important;border-color:rgba(234,67,53,.2) rgba(234,67,53,.2) rgba(234,67,53,.2) #ea4335!important}.type_video_fffcc516 .cardIconBox_fffcc516{background-color:rgba(234,67,53,.08)!important;color:#ea4335!important}.type_video_fffcc516 .cardTitleSelected_fffcc516,.type_video_fffcc516 .projectHubValue_fffcc516{color:#ea4335!important}.type_folder_fffcc516{border-left-color:#f5b041!important}.type_folder_fffcc516:hover{background:linear-gradient(90deg,rgba(245,176,65,.015),#fff)!important;border-color:rgba(245,176,65,.2) rgba(245,176,65,.2) rgba(245,176,65,.2) #f5b041!important}.type_folder_fffcc516 .cardIconBox_fffcc516{background-color:rgba(245,176,65,.08)!important;color:#f5b041!important}.type_folder_fffcc516 .cardTitleSelected_fffcc516,.type_folder_fffcc516 .projectHubValue_fffcc516{color:#f5b041!important}.type_default_fffcc516{border-left-color:#1a73e8!important}.type_default_fffcc516:hover{background:linear-gradient(90deg,rgba(26,115,232,.015),#fff)!important;border-color:rgba(26,115,232,.2) rgba(26,115,232,.2) rgba(26,115,232,.2) #1a73e8!important}.type_default_fffcc516 .cardIconBox_fffcc516{background-color:rgba(26,115,232,.08)!important;color:#1a73e8!important}.type_default_fffcc516 .cardTitleSelected_fffcc516,.type_default_fffcc516 .projectHubValue_fffcc516{color:#1a73e8!important}.actionMenuAnchor_fffcc516{position:absolute;right:12px;top:12px;z-index:10}.cardLeftBlock_fffcc516{align-items:center;display:flex;flex-direction:column;flex-shrink:0;gap:12px}@media (max-width:640px){.cardLeftBlock_fffcc516{flex-direction:row;justify-content:space-between}}.cardIconBox_fffcc516{align-items:center;border-radius:12px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);display:flex;height:44px;justify-content:center;transition:transform .15s cubic-bezier(.4,0,.2,1);width:44px}.cardThumbnailImage_fffcc516{border-radius:inherit!important;display:block!important}.resultCard_fffcc516:hover .cardIconBox_fffcc516{transform:scale(1.05)}.starIconButton_fffcc516{background:0 0;border:none;border-radius:9999px;color:#cbd5e1;cursor:pointer;display:flex;padding:6px;transition:background .15s cubic-bezier(.4,0,.2,1),color .15s cubic-bezier(.4,0,.2,1),transform .2s cubic-bezier(.175,.885,.32,1.275)}.starIconButton_fffcc516:hover{background:#f8fafc;color:#94a3b8;transform:scale(1.22)}.starIconButton_fffcc516:active{transform:scale(.9)}.cardBody_fffcc516{flex:1;min-width:0}.cardHeaderRow_fffcc516{align-items:start;display:flex;gap:12px;justify-content:space-between}.cardTitle_fffcc516{color:#0f172a;font-size:16px;font-weight:600;letter-spacing:-.01em;margin-bottom:2px;margin-top:0;overflow:hidden;padding-right:32px;text-overflow:ellipsis;transition:color .15s cubic-bezier(.4,0,.2,1);white-space:nowrap}.resultCard_fffcc516:hover .cardTitle_fffcc516{color:#334155}.scoreContainer_fffcc516{align-items:end;display:flex;flex-direction:column;gap:4px;margin-right:28px}.scoreRow_fffcc516{align-items:center;display:flex;gap:8px}.scoreBadge_fffcc516{border-radius:4px;font-size:9px;font-weight:700;letter-spacing:-.05em;padding:2px 6px;text-transform:uppercase}.scoreBM25_fffcc516{background:#ecfdf5;color:#059669}.scoreTFIDF_fffcc516{background:#eef2fd;color:#4f46e5}.fileTypeBadge_fffcc516{align-items:center;border:1px solid transparent;border-radius:8px;display:flex;font-size:10px;font-weight:700;gap:6px;letter-spacing:.1em;padding:4px 10px;text-transform:uppercase}.cardMetadataRow_fffcc516{align-items:center;color:#64748b;display:flex;font-size:12px;gap:10px;margin-bottom:8px;overflow:hidden;white-space:nowrap}.metaBoldLabel_fffcc516{font-size:10px;font-weight:700;letter-spacing:.1em;opacity:.6;text-transform:uppercase}.metaValueDark_fffcc516{color:#334155;font-weight:600}.metaDot_fffcc516{background:#cbd5e1;border-radius:50%;flex-shrink:0;height:4px;width:4px}.cardDescription_fffcc516{-webkit-line-clamp:2;-webkit-box-orient:vertical;color:#64748b;display:-webkit-box;font-size:12px;font-weight:500;line-height:1.6;margin:6px 0 12px;overflow:hidden}.cardProjectHubRow_fffcc516{align-items:center;color:#64748b;display:flex;font-size:10px;font-weight:700;gap:8px;letter-spacing:.1em;text-transform:uppercase}.projectHubValue_fffcc516{cursor:pointer;font-weight:600;letter-spacing:normal;overflow:hidden;text-overflow:ellipsis;text-transform:none;white-space:nowrap}.projectHubValue_fffcc516:hover{text-decoration:underline}.pagination_fffcc516{align-items:center;background:#fff;border-top:1px solid #f1f5f9;display:flex;flex-shrink:0;height:56px;padding:0 24px}.paginationInfo_fffcc516{color:#94a3b8;font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap!important}.infoDivider_fffcc516{color:#cbd5e1;margin:0 8px}.infoHighlight_fffcc516{color:#475569}.pageNumberControls_fffcc516{align-items:center;display:flex;flex:1;gap:6px;justify-content:center}.pageArrowBtn_fffcc516{background:0 0;border:none;border-radius:12px;color:#94a3b8;cursor:pointer;display:flex;padding:8px;transition:all .15s cubic-bezier(.4,0,.2,1)}.pageArrowBtn_fffcc516:hover{background:#f8fafc}.pageArrowBtn_fffcc516:disabled{cursor:not-allowed;opacity:.3}.pageNumBtn_fffcc516{align-items:center;background:0 0;border:1px solid transparent;border-radius:12px;color:#64748b;cursor:pointer;display:flex;font-size:12px;font-weight:700;height:32px;justify-content:center;transition:all .15s cubic-bezier(.4,0,.2,1);width:32px}.pageNumBtn_fffcc516:hover{background:#f8fafc;border-color:#f1f5f9}.pageNumActive_fffcc516{background:#1a73e8;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#fff}.pageNumActive_fffcc516:hover{background:#1a73e8}.paginationEllipsis_fffcc516{color:#cbd5e1;font-size:12px;font-weight:700;letter-spacing:.15em;padding:0 8px}.jumpToWrapper_fffcc516{align-items:center;display:flex;gap:8px}.jumpToLabel_fffcc516{color:#94a3b8;font-size:10px;font-weight:900;letter-spacing:.1em;text-transform:uppercase}.jumpToInput_fffcc516{background:#f8fafc;border:2px solid transparent;border-radius:8px;color:#1e293b;font-size:12px;font-weight:900;height:32px;outline:0;text-align:center;transition:all .15s cubic-bezier(.4,0,.2,1);width:40px}.jumpToInput_fffcc516:focus{background:#fff;border-color:rgba(26,115,232,.3)}.bottomTabNav_fffcc516{align-items:center;background:#fff;border-top:1px solid #f1f5f9;display:flex;flex-shrink:0;height:42px;padding:0 24px}.bottomTabWrapper_fffcc516{align-items:center;display:flex;flex:1;gap:16px}.bottomTabItem_fffcc516{background:0 0;border:none;color:#64748b;cursor:pointer;font-size:11.5px;font-weight:800;height:42px;letter-spacing:.05em;padding:0 8px;position:relative;text-transform:uppercase;transition:all .15s cubic-bezier(.4,0,.2,1)}.bottomTabItem_fffcc516:hover{color:#1e293b}.bottomTabActive_fffcc516,.bottomTabActive_fffcc516:hover{color:#1a73e8}.bottomActiveLine_fffcc516{background:#1a73e8;border-radius:9999px;bottom:0;height:3px;left:4px;position:absolute;right:4px}.previewPane_fffcc516{animation:slideInRight_fffcc516 .3s cubic-bezier(.16,1,.3,1) forwards;background:#fff;border-left:1px solid #e2e8f0;bottom:0;box-shadow:-10px 0 30px -5px rgba(15,23,42,.08);display:flex;flex-direction:column;height:100%;position:absolute;right:0;top:0;z-index:100}.previewPane_fffcc516,.previewPane_fffcc516 *{font-family:Segoe UI,-apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif!important}@keyframes slideInRight_fffcc516{0%{transform:translateX(100%)}to{transform:translateX(0)}}.previewHeader_fffcc516{align-items:center;background:#fff;border-bottom:1px solid #e2e8f0;display:flex;flex-shrink:0;height:56px;justify-content:space-between;padding:0 24px}.previewTitleLabel_fffcc516{color:#0f172a;font-size:10px;font-weight:900;letter-spacing:.15em;text-transform:uppercase}.previewCloseBtn_fffcc516{background:0 0;border:none;border-radius:9999px;color:#94a3b8;cursor:pointer;display:flex;padding:8px;transition:all .15s cubic-bezier(.4,0,.2,1)}.previewCloseBtn_fffcc516:hover{background:#fee2e2;color:#ef4444}.previewContentScroll_fffcc516{background:#f8fafc;flex:1;overflow-y:auto;padding:32px}.previewContentScroll_fffcc516::-webkit-scrollbar{display:none}.previewDocVisualCard_fffcc516{aspect-ratio:3/4;background:#fff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 10px 15px -3px rgba(0,0,0,.1),0 4px 6px -4px rgba(0,0,0,.1);display:flex;flex-direction:column;margin-bottom:32px;overflow:hidden;position:relative}.visualCardTop_fffcc516{background:#f1f5f9;display:flex;flex:1;flex-direction:column;gap:20px;padding:40px}.visualPulseLine1_fffcc516{width:75%}.visualPulseLine1_fffcc516,.visualPulseLine2_fffcc516{animation:pulse_fffcc516 2s cubic-bezier(.4,0,.6,1) infinite;background:#e2e8f0;border-radius:4px;height:20px}.visualPulseLine2_fffcc516{opacity:.6;width:50%}.visualInnerFrame_fffcc516{align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:inset 0 2px 4px 0 rgba(0,0,0,.05);display:flex;height:160px;justify-content:center;margin-top:24px;overflow:hidden;position:relative}.frameGripBackground_fffcc516{background-image:radial-gradient(#1a73e8 1px,transparent 0);background-size:16px 16px;inset:0;opacity:.05;position:absolute}.frameIcon_fffcc516{color:#1a73e8;opacity:.2}.visualPulseList_fffcc516{display:flex;flex-direction:column;gap:12px;margin-top:24px}.pulseRow_fffcc516{animation:pulse_fffcc516 2s cubic-bezier(.4,0,.6,1) infinite;background:#e2e8f0;border-radius:4px;height:12px;width:100%}.pulseRowMid_fffcc516{opacity:.7;width:83.333%}.pulseRowShort_fffcc516{opacity:.4;width:66.666%}.visualCardBottom_fffcc516{align-items:center;background:#fff;border-top:1px solid #f1f5f9;display:flex;height:48px;justify-content:center}.visualRestrictedLabel_fffcc516{color:#94a3b8;font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase}.previewIframe_fffcc516{background:#fff;border:none;height:100%;width:100%}.previewImage_fffcc516{background:#fff;height:100%;object-fit:contain;width:100%}.mockThumbnailWrapper_fffcc516{background:#fff;box-sizing:border-box;display:flex;flex-direction:column;height:100%;justify-content:space-between;padding:24px;width:100%}.mockThumbnailHeader_fffcc516{align-items:center;display:flex;justify-content:space-between;margin-bottom:20px}.mockThumbnailIcon_fffcc516{align-items:center;border-radius:8px;display:flex;height:40px;justify-content:center;width:40px}.mockThumbnailBadge_fffcc516{border-radius:6px;font-size:11px;font-weight:800;letter-spacing:.5px;padding:4px 10px}.mockThumbnailBody_fffcc516{display:flex;flex:1;flex-direction:column}.mockThumbnailTitle_fffcc516{-webkit-line-clamp:3;-webkit-box-orient:vertical;color:#1e293b;display:-webkit-box;font-size:15px;font-weight:700;line-height:1.4;margin:0 0 16px;overflow:hidden}.mockThumbnailTextLine_fffcc516{background:#f1f5f9;border-radius:4px;height:8px;margin-bottom:10px}.mockThumbnailFooter_fffcc516{align-items:center;border-top:1px dashed #e2e8f0;display:flex;justify-content:space-between;margin-top:auto;padding-top:12px}.mockThumbnailMeta_fffcc516{color:#94a3b8;font-size:11px;font-weight:600}.previewMetaGrid_fffcc516{grid-template-cols:repeat(2,minmax(0,1fr));display:grid;gap:24px;margin:32px 0}.previewMetaItem_fffcc516{display:flex;flex-direction:column;gap:4px}.previewMetaLabel_fffcc516{color:#64748b;font-size:9px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}.previewMetaValue_fffcc516{color:#334155;font-size:14px;font-weight:600}.primaryAuthorCard_fffcc516{background:#fff;border:1px solid #e2e8f0;border-radius:12px;display:flex;flex-direction:column;gap:4px;grid-column:span 2/span 2;padding:16px}.authorCardRow_fffcc516{align-items:center;display:flex;gap:12px;margin-top:8px}.authorAvatarSphere_fffcc516{align-items:center;background:#1a73e8;border-radius:9999px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#fff;display:flex;font-size:10px;font-weight:700;height:32px;justify-content:center;width:32px}.extractedSection_fffcc516{display:flex;flex-direction:column;gap:12px;margin-bottom:32px}.extractedContentBlock_fffcc516{background:#fff;border:1px solid #f1f5f9;border-radius:12px;color:#475569;font-size:12px;font-style:italic;line-height:1.6;max-height:192px;overflow-y:auto;padding:16px}.extractedContentBlock_fffcc516::-webkit-scrollbar{display:none}.previewActionsWrapper_fffcc516{display:flex;gap:12px;padding-bottom:32px;padding-top:8px}.previewFullBtn_fffcc516{align-items:center;background:#1a73e8;border:none;border-radius:12px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#fff;cursor:pointer;display:flex;flex:1;font-size:14px;font-weight:700;gap:8px;height:44px;justify-content:center;transition:all .15s cubic-bezier(.4,0,.2,1)}.previewFullBtn_fffcc516:hover{background:rgba(26,115,232,.9)}.previewFullBtn_fffcc516:active{transform:scale(.98)}.previewDownloadBtn_fffcc516{align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#334155;cursor:pointer;display:flex;height:44px;justify-content:center;transition:all .15s cubic-bezier(.4,0,.2,1);width:44px}.previewDownloadBtn_fffcc516:hover{background:#f1f5f9}.historyPane_fffcc516{background:#f8fafc;border-left:1px solid #e2e8f0;box-shadow:0 20px 25px -5px rgba(0,0,0,.1),0 8px 10px -6px rgba(0,0,0,.1);display:flex;flex-direction:column;flex-shrink:0;height:100%;z-index:40}.historyHeader_fffcc516{align-items:center;background:#fff;border-bottom:1px solid #e2e8f0;display:flex;flex-shrink:0;height:56px;justify-content:space-between;padding:0 24px}.historyTitleBox_fffcc516{align-items:center;display:flex;gap:8px}.historyTitleLabel_fffcc516{color:#0f172a;font-size:10px;font-weight:900;letter-spacing:.15em;text-transform:uppercase}.historyCloseBtn_fffcc516{background:0 0;border:none;border-radius:9999px;color:#94a3b8;cursor:pointer;display:flex;padding:8px;transition:all .15s cubic-bezier(.4,0,.2,1)}.historyCloseBtn_fffcc516:hover{background:#fee2e2;color:#ef4444}.historyScrollContent_fffcc516{flex:1;overflow-y:auto;padding:24px}.historyScrollContent_fffcc516::-webkit-scrollbar{display:none}.historyListGroup_fffcc516{display:flex;flex-direction:column;gap:8px}.historyItemCard_fffcc516{border:2px solid transparent;border-radius:12px;position:relative;transition:all .15s cubic-bezier(.4,0,.2,1)}.historyItemCard_fffcc516:hover{background:#fff;border-color:rgba(26,115,232,.1);box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -2px rgba(0,0,0,.1)}.historyItemTrigger_fffcc516{align-items:center;background:0 0;border:none;cursor:pointer;display:flex;gap:16px;padding:16px;text-align:left;width:100%}.historyItemIconBox_fffcc516{background:#f1f5f9;border-radius:8px;box-shadow:inset 0 1px 2px rgba(0,0,0,.05);display:flex;padding:10px;transition:all .15s cubic-bezier(.4,0,.2,1)}.historyItemCard_fffcc516:hover .historyItemIconBox_fffcc516{background:#1a73e8;color:#fff}.historyItemInfo_fffcc516{flex:1;min-width:0;padding-right:24px}.historyItemQueryText_fffcc516{color:#334155;font-size:14px;font-weight:600;margin:0;overflow:hidden;text-overflow:ellipsis;transition:color .15s cubic-bezier(.4,0,.2,1);white-space:nowrap}.historyItemCard_fffcc516:hover .historyItemQueryText_fffcc516{color:#1a73e8}.historyItemTimeLabel_fffcc516{color:#94a3b8;font-size:10px;font-weight:500;letter-spacing:.05em;margin:2px 0 0;text-transform:uppercase}.historyItemRemoveBtn_fffcc516{background:0 0;border:none;border-radius:9999px;color:#cbd5e1;cursor:pointer;display:flex;opacity:0;padding:8px;position:absolute;right:12px;top:50%;transform:translateY(-50%);transition:all .15s cubic-bezier(.4,0,.2,1)}.historyItemRemoveBtn_fffcc516:hover{background:#fee2e2;color:#ef4444}.historyItemCard_fffcc516:hover .historyItemRemoveBtn_fffcc516{opacity:1}.historyEmptyState_fffcc516{padding:80px 24px;text-align:center}.historyEmptyIconFrame_fffcc516{align-items:center;background:#fff;border:2px solid #f1f5f9;border-radius:16px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);display:flex;height:64px;justify-content:center;margin:0 auto 24px;width:64px}.historyEmptyTitle_fffcc516{color:#94a3b8;font-size:14px;font-weight:900;letter-spacing:.15em;margin-bottom:8px;text-transform:uppercase}.historyEmptyDesc_fffcc516{color:#94a3b8;font-size:12px;font-weight:500;line-height:1.5;margin:0}.historyFooter_fffcc516{background:#fff;border-top:1px solid #e2e8f0;padding:24px}.clearHistoryButton_fffcc516{background:#f8fafc;border:none;border-radius:12px;color:#64748b;cursor:pointer;font-size:10px;font-weight:700;height:44px;letter-spacing:.1em;text-transform:uppercase;transition:all .15s cubic-bezier(.4,0,.2,1);width:100%}.clearHistoryButton_fffcc516:hover{background:#fee2e2;color:#ef4444}.clearHistoryButton_fffcc516:active{transform:scale(.98)}.actionMenuWrapper_fffcc516{position:relative}.actionTriggerBtn_fffcc516{background:0 0;border:none;border-radius:6px;color:#94a3b8;cursor:pointer;display:flex;padding:6px;transition:all .15s cubic-bezier(.4,0,.2,1)}.actionTriggerBtn_fffcc516:hover{background:#f8fafc;color:#475569}.actionTriggerBtnActive_fffcc516{background:#f1f5f9!important;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);color:#0f172a!important}.actionDropdownList_fffcc516{background:#fff;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 20px 25px -5px rgba(0,0,0,.1),0 8px 10px -6px rgba(0,0,0,.1);margin-top:4px;padding:6px 0;position:absolute;right:0;top:100%;width:208px;z-index:100}.actionDropdownItem_fffcc516{align-items:center;background:0 0;border:none;color:#334155;cursor:pointer;display:flex;font-size:14px;gap:12px;padding:8px 12px;text-align:left;transition:background .15s cubic-bezier(.4,0,.2,1),color .15s cubic-bezier(.4,0,.2,1);width:100%}.actionDropdownItem_fffcc516:hover{background:#f8fafc;color:#0f172a}.actionItemIcon_fffcc516{color:#94a3b8;flex-shrink:0;transition:color .15s cubic-bezier(.4,0,.2,1)}.actionDropdownItem_fffcc516:hover .actionItemIcon_fffcc516{color:#475569}.actionIconCopied_fffcc516,.actionItemCopied_fffcc516{color:#16a34a!important}.detailBackdrop_fffcc516{backdrop-filter:blur(4px);background:rgba(15,23,42,.2);inset:0;position:fixed;z-index:40}.detailDrawer_fffcc516{background:#fff;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);display:flex;flex-direction:column;height:100%;max-width:576px;position:fixed;right:0;top:0;width:100%;z-index:50}.detailHeader_fffcc516{align-items:center;border-bottom:1px solid #f1f5f9;display:flex;flex-shrink:0;justify-content:space-between;padding:24px}.detailHeaderLeft_fffcc516{align-items:center;display:flex;gap:12px}.detailIconBox_fffcc516{align-items:center;background:rgba(0,71,171,.05);border-radius:8px;color:#0047ab;display:flex;height:40px;justify-content:center;width:40px}.detailHeadingBox_fffcc516{min-width:0}.detailDocTitle_fffcc516{color:#0f172a;font-size:18px;font-weight:700;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.detailDocSub_fffcc516{color:#64748b;font-size:12px;font-weight:500;margin:2px 0 0}.detailCloseBtn_fffcc516{background:0 0;border:none;border-radius:9999px;color:#94a3b8;cursor:pointer;display:flex;padding:8px;transition:all .15s cubic-bezier(.4,0,.2,1)}.detailCloseBtn_fffcc516:hover{background:#f1f5f9;color:#475569}.detailScrollContent_fffcc516{flex:1;overflow-y:auto;padding:32px}.detailSection_fffcc516{margin-bottom:32px}.detailSectionHeader_fffcc516{align-items:center;color:#0047ab;display:flex;font-size:10px;font-weight:700;gap:8px;letter-spacing:.15em;margin-bottom:16px;text-transform:uppercase}.detailContentBlock_fffcc516{background:#f8fafc;border:1px solid #f1f5f9;border-radius:12px;color:#334155;font-size:14px;line-height:1.6;padding:24px}.timelineGroup_fffcc516{display:flex;flex-direction:column;gap:16px}.timelineItem_fffcc516{display:flex;gap:16px}.timelineLeft_fffcc516{align-items:center;display:flex;flex-direction:column}.timelineNode_fffcc516{background:#cbd5e1;border-radius:50%;height:8px;margin-top:6px;width:8px}.timelineLine_fffcc516{background:#e2e8f0;flex:1;margin:4px 0;width:1px}.timelineRight_fffcc516{padding-bottom:16px}.timelineDate_fffcc516{color:#94a3b8;font-size:10px;font-weight:700;margin-bottom:2px}.timelineAuthor_fffcc516{color:#1e293b;font-size:12px;font-weight:700}.timelineAction_fffcc516{color:#64748b;font-size:12px;margin-top:2px}.detailFooter_fffcc516{background:#f8fafc;border-top:1px solid #f1f5f9;display:flex;flex-shrink:0;gap:12px;padding:24px}.footerPrimaryBtn_fffcc516{align-items:center;background:#0047ab;border:none;border-radius:8px;color:#fff;cursor:pointer;display:flex;flex:1;font-size:14px;font-weight:700;gap:8px;height:44px;justify-content:center;transition:background .15s cubic-bezier(.4,0,.2,1)}.footerPrimaryBtn_fffcc516:hover{background:#003682}.footerSecondaryBtn_fffcc516{align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:8px;color:#334155;cursor:pointer;display:flex;flex:1;font-size:14px;font-weight:700;gap:8px;height:44px;justify-content:center;transition:background .15s cubic-bezier(.4,0,.2,1)}.footerSecondaryBtn_fffcc516:hover{background:#f8fafc}.loadingRow_fffcc516{align-items:center;color:#64748b;display:flex;font-size:14px;font-weight:500;gap:12px;justify-content:center;padding:40px}.spinner_fffcc516{animation:spin_fffcc516 .8s linear infinite;border:2.5px solid #e2e8f0;border-radius:50%;border-top-color:#1a73e8;height:20px;width:20px}.emptyState_fffcc516{align-items:center;color:#94a3b8;display:flex;flex-direction:column;justify-content:center;padding:80px 24px;text-align:center}.emptyState_fffcc516 svg{margin-bottom:16px;opacity:.15}.emptyState_fffcc516 h3{color:#334155;font-size:18px;font-weight:700;margin:0 0 8px}.emptyState_fffcc516 p{color:#64748b;font-size:14px;margin:0}@keyframes spin_fffcc516{to{transform:rotate(1turn)}}@keyframes pulse_fffcc516{0%,to{opacity:1}50%{opacity:.5}}.previewHeaderContainer_fffcc516{align-items:center;display:flex;gap:12px}.previewHeaderTitle_fffcc516{color:#0f172a;font-size:14px;font-weight:800;line-height:1;margin:0}.previewHeaderSubtitle_fffcc516{color:#94a3b8;font-size:10px;font-weight:700;letter-spacing:.1em;margin:4px 0 0;text-transform:uppercase}.visualIdentityHeader_fffcc516{margin-bottom:24px;margin-top:16px}.visualTitle_fffcc516{color:#0f172a;font-size:20px;font-weight:900;letter-spacing:-.02em;line-height:1.25;margin:0 0 8px}.visualSubRow_fffcc516{align-items:center;display:flex;gap:8px}.siteBadge_fffcc516{border-radius:4px;font-size:10px;letter-spacing:.5px;padding:2px 8px;text-transform:uppercase}.verifiedLabel_fffcc516{color:#64748b;font-size:10px;font-weight:600}.bentoGrid_fffcc516{display:flex!important;flex-wrap:wrap!important;gap:12px!important;margin-bottom:24px!important}.bentoItem_fffcc516{background:#f8fafc;border:1px solid rgba(241,245,249,.5);border-radius:16px;box-sizing:border-box!important;padding:16px;transition:border-color .15s cubic-bezier(.4,0,.2,1);width:calc(50% - 6px)!important}.bentoItem_fffcc516:hover{border-color:rgba(26,115,232,.2)}.bentoLabel_fffcc516{color:#94a3b8;font-size:9px;font-weight:800;letter-spacing:.1em;line-height:1;margin:0 0 4px;text-transform:uppercase}.bentoValue_fffcc516{color:#1e293b;font-size:14px;font-weight:800;margin:0}.authorCard_fffcc516{align-items:center;background:#fff;border:1px solid #f1f5f9;border-radius:16px;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);display:flex;justify-content:space-between;margin-bottom:24px;padding:16px;transition:all .15s cubic-bezier(.4,0,.2,1)}.authorCard_fffcc516:hover{box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -2px rgba(0,0,0,.1)}.authorCardLeft_fffcc516{align-items:center;display:flex;gap:12px}.authorAvatar_fffcc516{align-items:center;border-radius:12px;color:#fff;display:flex;font-size:14px;font-weight:800;height:40px;justify-content:center;width:40px}.authorBadge_fffcc516{background:#f8fafc;border-radius:9999px;color:#64748b;font-size:10px;font-weight:800;padding:4px 12px;transition:all .15s cubic-bezier(.4,0,.2,1)}.authorBadge_fffcc516:hover{background:rgba(26,115,232,.05);color:#1a73e8}.highlightsSection_fffcc516{margin-bottom:28px}.highlightsHeader_fffcc516{align-items:center;display:flex;justify-content:space-between;margin-bottom:12px}.highlightsTitle_fffcc516{color:#0f172a;font-size:11px;font-weight:900;letter-spacing:.1em;margin:0;text-transform:uppercase}.copySnippet_fffcc516{color:#1a73e8;cursor:pointer;font-size:10px;font-weight:800}.copySnippet_fffcc516:hover{text-decoration:underline}.highlightsContentWrapper_fffcc516{padding-left:20px;position:relative}.highlightsLineAccent_fffcc516{background:rgba(242,39,151,.2);border-radius:2px;bottom:0;left:0;position:absolute;top:0;width:4px}.highlightsText_fffcc516{color:#475569;font-size:14px;font-style:italic;font-weight:500;line-height:1.6;margin:0}.actionFooter_fffcc516{display:flex;gap:12px;padding-bottom:40px;padding-top:16px}.actionPrimaryBtn_fffcc516{align-items:center;background:#1a73e8;border:none;border-radius:16px;box-shadow:0 10px 20px -5px rgba(26,115,232,.2);color:#fff;cursor:pointer;display:flex;flex:1;font-size:12px;font-weight:900;gap:8px;height:48px;justify-content:center;letter-spacing:.1em;text-transform:uppercase;transition:all .15s cubic-bezier(.4,0,.2,1)}.actionPrimaryBtn_fffcc516:hover{background:#1567d3;transform:translateY(-1px)}.actionPrimaryBtn_fffcc516:active{transform:translateY(0)}.actionSecondaryBtn_fffcc516{align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:16px;color:#94a3b8;cursor:pointer;display:flex;height:48px;justify-content:center;transition:all .15s cubic-bezier(.4,0,.2,1);width:48px}.actionSecondaryBtn_fffcc516:hover{background:#f8fafc;border-color:#cbd5e1;color:#0f172a}.copyDialogOverlay_fffcc516{align-items:center;backdrop-filter:blur(4px);background-color:rgba(15,23,42,.4);display:flex;inset:0;justify-content:center;position:fixed;z-index:999999}.copyDialogContent_fffcc516{background:#fff;border-radius:16px;box-shadow:0 20px 25px -5px rgba(0,0,0,.1),0 10px 10px -5px rgba(0,0,0,.04);box-sizing:border-box;padding:24px;position:relative;width:450px}.copyDialogClose_fffcc516{background:0 0;border:none;color:#94a3b8;cursor:pointer;font-size:18px;position:absolute;right:16px;top:16px}.copyDialogHeader_fffcc516{align-items:center;display:flex;gap:10px;margin-bottom:16px}.copyDialogCheckCircle_fffcc516{align-items:center;background-color:#4caf50;border-radius:50%;color:#fff;display:flex;font-size:12px;font-weight:700;height:20px;justify-content:center;width:20px}.copyDialogTitle_fffcc516{color:#202124;font-family:Segoe UI,sans-serif;font-size:15px;font-weight:700;margin:0}.copyDialogInputRow_fffcc516{align-items:center;background:#f8f9fa;border:1px solid #dadce0;border-radius:8px;display:flex;gap:8px;margin-bottom:12px;padding:6px 12px}.copyDialogUrlText_fffcc516{color:#3c4043;flex:1;font-family:Segoe UI,sans-serif;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.copyDialogCopyButton_fffcc516{background:#fff;border:1px solid #dadce0;border-radius:20px;color:#1a73e8;cursor:pointer;font-family:Segoe UI,sans-serif;font-size:13px;font-weight:700;padding:6px 16px;transition:all .15s ease}.copyDialogCopyButton_fffcc516:hover{background:#f1f5f9}.copyDialogCopyButtonCopied_fffcc516{background:#e8f5e9!important;color:#2e7d32!important}.copyDialogFooter_fffcc516{align-items:center;color:#5f6368;display:flex;font-family:Segoe UI,sans-serif;font-size:12px;justify-content:space-between}.copyDialogSettingsLink_fffcc516{align-items:center;color:#1a73e8;cursor:pointer;display:flex;font-weight:600;gap:4px}.centerContainer_fffcc516{display:flex;flex:1;flex-direction:column;overflow:hidden}.previewResizeHandle_fffcc516{bottom:0!important;left:0!important;position:absolute!important;top:0!important;z-index:10!important}.previewHeaderIconBox_fffcc516{align-items:center;border-radius:8px;display:flex;justify-content:center;padding:8px}.actionItemText_fffcc516{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ownerTitle_fffcc516{color:#94a3b8;font-size:9px;font-weight:800;letter-spacing:.1em;line-height:1;margin:0 0 2px;text-transform:uppercase}.ownerName_fffcc516{color:#1e293b;font-size:14px;font-weight:800;margin:0}.statusSuccess_fffcc516{color:#10b981!important}.siteBadge_fffcc516{border-radius:6px;font-size:9px;font-weight:800;max-width:300px;overflow:hidden;padding:4px 10px;text-overflow:ellipsis;white-space:nowrap}.skeleton_w90_fffcc516{width:90%!important}.skeleton_w80_fffcc516{width:80%!important}.skeleton_w95_fffcc516{width:95%!important}.skeleton_w60_fffcc516{width:60%!important}.authorDropdownHeader_fffcc516{margin-top:24px!important}.authorDropdownWrapper_fffcc516{margin-bottom:16px!important;position:relative!important}.authorDropdownTrigger_fffcc516{border-radius:16px!important;cursor:pointer!important;display:flex!important;gap:8px!important;padding:8px!important;position:relative!important;transition:all .2s ease!important}.authorDropdownTrigger_fffcc516:hover{background:#fff!important;border-color:rgba(26,115,232,.3)!important}.authorIcon_fffcc516{align-items:center!important;color:#1a73e8!important;display:flex!important;padding:6px!important}.authorInput_fffcc516{background:0 0!important;border:none!important;color:#334155!important;font-size:14px!important;font-weight:700!important;outline:0!important;width:100%!important}.authorDropdownMenu_fffcc516{background:#fff!important;border:1px solid #e2e8f0!important;border-radius:12px!important;box-shadow:0 10px 25px -5px rgba(0,0,0,.05),0 8px 10px -6px rgba(0,0,0,.05)!important;display:flex!important;flex-direction:column!important;left:0!important;margin-top:6px!important;max-height:250px!important;padding:6px 0!important;position:absolute!important;right:0!important;top:100%!important;z-index:100!important}.authorDropdownMenuHeader_fffcc516{align-items:center!important;border-bottom:1px solid #f1f5f9!important;display:flex!important;justify-content:space-between!important;margin-bottom:8px!important;padding:2px 4px 8px!important}.authorDropdownMenuTitle_fffcc516{color:#94a3b8!important;font-size:11px!important;font-weight:600!important}.authorDropdownMenuDone_fffcc516{background:0 0!important;border:none!important;color:#2563eb!important;cursor:pointer!important;font-size:11px!important;font-weight:700!important}.authorDropdownScroll_fffcc516{display:flex!important;flex-direction:column!important;gap:5px!important;max-height:170px!important;overflow-y:auto!important;padding-right:2px!important}.authorItemLabel_fffcc516{align-items:center!important;background-color:transparent!important;cursor:pointer!important;display:flex!important;gap:12px!important;padding:10px 16px!important;transition:all .15s ease!important;-webkit-user-select:none!important;-ms-user-select:none!important;user-select:none!important}.authorItemLabelChecked_fffcc516,.authorItemLabel_fffcc516:hover{background-color:#f8fafc!important}.authorItemAvatar_fffcc516{align-items:center!important;background-color:#f1f5f9!important;border-radius:50%!important;color:#64748b!important;display:flex!important;font-size:12px!important;font-weight:600!important;height:28px!important;justify-content:center!important;width:28px!important}.authorItemAvatarChecked_fffcc516{background-color:#dbeafe!important;color:#2563eb!important}.authorItemName_fffcc516{color:#334155!important;font-size:13px!important;font-weight:500!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}.authorItemNameChecked_fffcc516{color:#2563eb!important;font-weight:600!important}.authorDropdownEmpty_fffcc516{color:#94a3b8!important;font-size:12px!important;font-style:italic!important;padding:16px!important;text-align:center!important}.historyHeaderIcon_fffcc516{color:#475569!important}.historyEmptyIcon_fffcc516{color:#cbd5e1!important}.cardIconBoxImage_fffcc516{align-items:center!important;display:flex!important;justify-content:center!important;overflow:hidden!important;padding:0!important}.cardThumbnailImage_fffcc516{height:100%!important;object-fit:cover!important;width:100%!important}.sortContainer_fffcc516{align-items:center!important;display:flex!important;gap:8px!important;margin:0 8px!important}.sortLabel_fffcc516{color:#64748b!important;font-size:10px!important;font-weight:700!important;letter-spacing:.1em!important;text-transform:uppercase!important}.sortSelect_fffcc516{background:#f1f5f9!important;border:1px solid #cbd5e1!important;border-radius:9999px!important;color:#334155!important;cursor:pointer!important;font-size:11px!important;font-weight:700!important;height:30px!important;outline:0!important;padding:0 12px!important;transition:all .2s ease!important}.sortSelect_fffcc516:hover{background:#e2e8f0!important;border-color:#94a3b8!important}.sortSelect_fffcc516:focus{border-color:#1a73e8!important;box-shadow:0 0 0 2px rgba(26,115,232,.15)!important}.promotedSection_fffcc516{display:flex!important;flex-direction:column!important;gap:16px!important;margin-bottom:24px!important}.promotedCard_fffcc516{background:linear-gradient(135deg,rgba(26,115,232,.02),rgba(242,39,151,.02))!important;border:1px solid rgba(245,158,11,.25)!important;border-left:5px solid #f59e0b!important;border-radius:16px!important;box-shadow:0 4px 12px rgba(245,158,11,.05)!important;cursor:pointer!important;display:flex!important;gap:16px!important;padding:16px 20px!important;text-decoration:none!important;transition:all .25s cubic-bezier(.4,0,.2,1)!important}.promotedCard_fffcc516:hover{background:linear-gradient(135deg,rgba(26,115,232,.04),rgba(242,39,151,.04))!important;border-color:rgba(245,158,11,.4)!important;box-shadow:0 10px 20px rgba(245,158,11,.08)!important;transform:translateY(-2px)!important}.promotedCrownBox_fffcc516{align-items:center!important;background:rgba(245,158,11,.12)!important;border-radius:50%!important;box-shadow:inset 0 2px 4px rgba(245,158,11,.08)!important;display:flex!important;flex-shrink:0!important;font-size:20px!important;height:40px!important;justify-content:center!important;width:40px!important}.promotedCardBody_fffcc516{display:flex!important;flex:1!important;flex-direction:column!important;gap:4px!important;min-width:0!important}.promotedTitleRow_fffcc516{align-items:center!important;display:flex!important;gap:12px!important;justify-content:space-between!important}.promotedCardTitle_fffcc516{color:#1a73e8!important;font-size:15px!important;font-weight:700!important;margin:0!important}.promotedCategoryBadge_fffcc516{background:rgba(245,158,11,.1)!important;border-radius:9999px!important;color:#f59e0b!important;font-size:9px!important;font-weight:800!important;letter-spacing:.08em!important;padding:2px 8px!important;text-transform:uppercase!important}.promotedCardDescription_fffcc516{color:#475569!important;font-size:12px!important;line-height:1.5!important;margin:4px 0!important}.promotedUrlLabel_fffcc516{align-items:center!important;color:#f22797!important;display:inline-flex!important;font-size:11px!important;font-weight:700!important;gap:4px!important;letter-spacing:.05em!important;margin-top:4px!important;text-transform:uppercase!important}.promotedUrlLabel_fffcc516:hover{text-decoration:underline!important}.historySectionHeader_fffcc516{border-bottom:1px solid #f1f5f9!important;color:#94a3b8!important;display:block!important;font-size:9px!important;font-weight:800!important;letter-spacing:.15em!important;margin-bottom:12px!important;margin-top:24px!important;padding-bottom:6px!important;text-transform:uppercase!important}.analyticsWrapper_fffcc516{margin-bottom:24px!important}.analyticsQueriesList_fffcc516{display:flex!important;flex-direction:column!important;gap:8px!important}.analyticsQueryRow_fffcc516{align-items:center!important;background:#fff!important;border:1px solid #f1f5f9!important;border-radius:12px!important;cursor:pointer!important;display:flex!important;justify-content:space-between!important;padding:10px 14px!important;transition:all .2s ease!important;width:100%!important}.analyticsQueryRow_fffcc516:hover{background:rgba(26,115,232,.03)!important;border-color:rgba(26,115,232,.15)!important}.analyticsQueryRow_fffcc516:hover .analyticsQueryText_fffcc516{color:#1a73e8!important}.analyticsQueryText_fffcc516{color:#334155!important;font-size:13px!important;font-weight:600!important;overflow:hidden!important;text-align:left!important;text-overflow:ellipsis!important;white-space:nowrap!important}.analyticsCountBadge_fffcc516{background:rgba(26,115,232,.08)!important;border-radius:9999px!important;color:#1a73e8!important;font-size:10px!important;font-weight:700!important;padding:2px 8px!important;white-space:nowrap!important}.analyticsDocsList_fffcc516{display:flex!important;flex-direction:column!important;gap:8px!important}.analyticsDocRow_fffcc516{align-items:center!important;background:#fff!important;border:1px solid #f1f5f9!important;border-radius:12px!important;cursor:pointer!important;display:flex!important;gap:12px!important;padding:10px 14px!important;text-decoration:none!important;transition:all .2s ease!important}.analyticsDocRow_fffcc516:hover{background:rgba(242,39,151,.03)!important;border-color:rgba(242,39,151,.15)!important}.analyticsDocRow_fffcc516:hover .analyticsDocTitle_fffcc516{color:#f22797!important}.analyticsDocIcon_fffcc516{flex-shrink:0!important;font-size:18px!important}.analyticsDocInfo_fffcc516{flex:1!important;min-width:0!important}.analyticsDocTitle_fffcc516{color:#334155!important;font-size:13px!important;font-weight:600!important;margin:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}.analyticsDocClicks_fffcc516{color:#64748b!important;font-size:10px!important;font-weight:600!important;margin:2px 0 0!important}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvdXNlci9NYW5hc3ZpL1NoYXJlUG9pbnQvVHJpdmFuZGlpaWlpaWlpaWlpaS9Ucml2YW5kaS9zcmMvc3R5bGVzL1ByZW1pdW1TZWFyY2gubW9kdWxlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBK0JBLGtCQU9FLGtCQUFBLENBRkEsMEJBQUEsQ0FEQSw2QkFBQSxDQUVBLFlBQUEsQ0FKQSxPQUFBLENBTUEsc0JBQUEsQ0FQQSxjQUFBLENBRUEsYUFNQSxDQUVBLHNDQUZBLGlHQUdFLENBSUosZ0NBQ0UsR0FDRSxTQUFBLENBQ0EscUJBQUEsQ0FFRixHQUNFLFNBQUEsQ0FDQSxrQkFBQSxDQUFBLENBSUosZ0JBU0Usb0VBQUEsQ0FGQSxlQUFBLENBSEEsWUFBQSxDQUNBLHFCQUFBLENBR0EsdUZBQUEsQ0FOQSxPQUFBLENBSUEsZUFBQSxDQUxBLGNBQUEsQ0FFQSxjQU1BLENBR0YsZUFLRSxrQkFBQSxDQUdGLG9DQVBFLFlBQUEsQ0FDQSxNQUFBLENBQ0EsZUFBQSxDQUNBLGlCQVFBLENBTUYsaUJBS0Usa0JBQUEsQ0FGQSxlQUFBLENBREEsK0JBQUEsQ0FRQSxzQ0FBQSxDQU5BLFlBQUEsQ0FJQSxhQUFBLENBUEEsV0FBQSxDQU1BLDZCQUFBLENBREEsY0FBQSxDQUtBLGlCQUFBLENBRkEsVUFFQSxDQUdGLHNCQUVFLGtCQUFBLENBREEsWUFBQSxDQUVBLFFBQUEsQ0FHRixrQkFDRSxXQUFBLENBQ0EsVUFBQSxDQUdGLG1CQUNFLFlBQUEsQ0FDQSxjQUFBLENBRUEsZUFBQSxDQURBLHFCQUNBLENBR0YsbUJBQ0UsY0FBQSxDQUNBLFdBQUEsQ0FHQSxvQkFBQSxDQUZBLGFBQUEsQ0FHQSxjQUFBLENBQ0EsWUFBQSxDQUhBLFdBQUEsQ0FJQSwyQ0FBQSxDQUVBLHlCQUNFLGtCQUFBLENBQ0EsYUFBQSxDQUlKLDZCQUlFLHdCQUFBLENBRkEseUJBQUEsQ0FDQSx5QkFBQSxDQUVBLDJCQUFBLENBSkEscUJBSUEsQ0FHRiwyQkFHRSx3QkFBQSxDQUZBLDJCQUFBLENBQ0Esb0JBQ0EsQ0FHRixxQkFRRSxrQkFBQSxDQUhBLGFBQUEsQ0FFQSxZQUFBLENBTEEsU0FBQSxDQUlBLG1CQUFBLENBTEEsaUJBQUEsQ0FFQSxPQUFBLENBQ0EsbUNBQUEsQ0FLQSwyQ0FBQSxDQUdGLDZEQUNFLGFBQUEsQ0FDQSxzQ0FBQSxDQUdGLHNCQU1FLCtCQUFBLENBREEscUNBQUEsQ0FFQSxvQkFBQSxDQUtBLGlGQUFBLENBRkEsYUFBQSxDQUZBLGdCQUFBLENBQ0EsZUFBQSxDQVBBLFdBQUEsQ0FTQSxTQUFBLENBUkEsaUJBQUEsQ0FDQSxrQkFBQSxDQVNBLDJDQUFBLENBWkEsVUFZQSxDQUVBLG1DQUNFLDBCQUFBLENBREYsNENBQ0UsMEJBQUEsQ0FERixtQ0FDRSwwQkFBQSxDQUdGLDRCQUNFLGVBQUEsQ0FDQSxnQ0FBQSxDQUNBLHlFQUFBLENBR0osb0JBSUUsYUFBQSxDQUZBLFlBQUEsQ0FDQSxrQkFBQSxDQUZBLFdBR0EsQ0FHRix5QkFXRSw0QkFBQSxDQUxBLHdCQUFBLENBQ0EscUJBQUEsQ0FPQSw4QkFBQSxDQU5BLHVCQUFBLENBQ0Esd0JBQUEsQ0FDQSxzQkFBQSxDQUVBLGdDQUFBLENBVEEsbUJBQUEsQ0FVQSxxQkFBQSxDQVpBLDJCQUFBLENBQ0Esb0JBQUEsQ0FFQSxpQkFBQSxDQUNBLDZDQUFBLENBVUEscURBQUEsQ0FDQSxvQkFBQSxDQUVBLCtCQUNFLGtCQUFBLENBQ0EsYUFBQSxDQUNBLHNDQUFBLENBSUosa0NBQ0UsR0FDRSxTQUFBLENBQ0EsMEJBQUEsQ0FFRixHQUNFLFNBQUEsQ0FDQSx1QkFBQSxDQUFBLENBSUosOEJBWUUsNkRBQUEsQ0FOQSxlQUFBLENBQ0EscUNBQUEsQ0FDQSxrQkFBQSxDQUNBLCtDQUFBLENBTkEsTUFBQSxDQUVBLGNBQUEsQ0FNQSxlQUFBLENBVkEsaUJBQUEsQ0FHQSxPQUFBLENBRkEsUUFBQSxDQVFBLFdBRUEsQ0FHRiwyQkFFRSxrQkFBQSxDQUNBLCtCQUFBLENBSUEsYUFBQSxDQUhBLGNBQUEsQ0FDQSxlQUFBLENBR0EsbUJBQUEsQ0FQQSxpQkFBQSxDQUtBLHdCQUVBLENBR0YseUJBU0Usa0JBQUEsQ0FMQSxjQUFBLENBREEsV0FBQSxDQUlBLGFBQUEsQ0FJQSxjQUFBLENBSEEsWUFBQSxDQUZBLGdCQUFBLENBSUEsUUFBQSxDQUxBLGlCQUFBLENBSEEsZUFBQSxDQVVBLHVCQUFBLENBWEEsVUFXQSxDQUVBLCtCQUNFLCtCQUFBLENBQ0EsYUFBQSxDQUNBLGlCQUFBLENBSUoseUJBQ0UsYUFBQSxDQUNBLHlCQUFBLENBR0Ysd0RBQ0UsYUFBQSxDQUdGLHFCQUVFLGtCQUFBLENBREEsWUFBQSxDQUVBLFFBQUEsQ0FDQSx3QkFBQSxDQUdGLDRCQUNFLGdCQUFBLENBRUEseUJBSEYsNEJBSUksWUFBQSxDQUFBLENBSUosMkJBR0UsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUNBLENBR0YsdUJBS0UsYUFBQSxDQUpBLGFBQUEsQ0FDQSxlQUFBLENBRUEsb0JBQUEsQ0FFQSxjQUFBLENBSEEsd0JBR0EsQ0FHRixzQkFHRSxrQkFBQSxDQUZBLFdBQUEsQ0FHQSxZQUFBLENBRkEsU0FFQSxDQU1GLGtCQUVFLGVBQUEsQ0FEQSw4QkFBQSxDQUtBLHFCQUFBLENBRkEsYUFBQSxDQURBLGVBQUEsQ0FFQSx3QkFBQSxDQUFBLG9CQUFBLENBQUEsZ0JBQ0EsQ0FFQSx5QkFSRixrQkFTSSxZQUFBLENBQUEsQ0FHRixxQ0FDRSxZQUFBLENBSUosdUJBRUUsWUFBQSxDQUNBLHFCQUFBLENBQ0EsUUFBQSxDQUhBLFlBR0EsQ0FHRix1QkFPRSwwQkFBQSxDQUZBLGFBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLG9CQUFBLENBRUEsa0JBQUEsQ0FFQSxrQkFBQSxDQUxBLHdCQUtBLENBR0YsNEJBQ0UsWUFBQSxDQUNBLHFCQUFBLENBQ0EsT0FBQSxDQUdGLHdCQUVFLGtCQUFBLENBSUEsYUFBQSxDQUNBLGNBQUEsQ0FOQSxZQUFBLENBR0EsY0FBQSxDQUNBLGVBQUEsQ0FGQSxRQUlBLENBRUEsOEJBQ0UsYUFBQSxDQUlKLHlCQUNFLGFBQUEsQ0FDQSxlQUFBLENBR0Ysd0JBSUUsd0JBQUEsQ0FEQSxpQkFBQSxDQUVBLGFBQUEsQ0FDQSxjQUFBLENBSkEsV0FBQSxDQUtBLDJDQUFBLENBTkEsVUFNQSxDQUVBLDhCQUNFLHlDQUFBLENBSUosd0JBS0Usa0JBQUEsQ0FFQSxvQkFBQSxDQUhBLGFBQUEsQ0FGQSxjQUFBLENBQ0EsZUFBQSxDQUZBLGdCQUFBLENBS0EsZUFDQSxDQUdGLCtCQVdFLGtCQUFBLENBSEEsK0JBQUEsQ0FIQSxhQUFBLENBS0EsWUFBQSxDQVRBLGNBQUEsQ0FDQSxlQUFBLENBVUEsNkJBQUEsQ0FSQSxvQkFBQSxDQUdBLGtCQUFBLENBREEsZUFBQSxDQUdBLGtCQUFBLENBTkEsd0JBU0EsQ0FHRixxQkFDRSxhQUFBLENBQ0EsZUFBQSxDQUVBLHFCQUFBLENBREEsd0JBQ0EsQ0FHRiw2QkFDRSxpQkFBQSxDQUdGLHFCQUtFLGFBQUEsQ0FIQSxTQUFBLENBREEsaUJBQUEsQ0FFQSxPQUFBLENBQ0EsMEJBQUEsQ0FFQSw2Q0FBQSxDQUdGLHNCQUdFLGtCQUFBLENBQ0Esd0JBQUEsQ0FDQSxrQkFBQSxDQU9BLDBDQUFBLENBSEEsYUFBQSxDQURBLGNBQUEsQ0FHQSxlQUFBLENBVEEsV0FBQSxDQVFBLFNBQUEsQ0FKQSxpQkFBQSxDQUNBLGtCQUFBLENBTUEsMkNBQUEsQ0FaQSxVQVlBLENBRUEsNEJBQ0UsZUFBQSxDQUNBLGdDQUFBLENBSUoseUJBTUUsZUFBQSxDQUNBLHdCQUFBLENBQ0Esa0JBQUEsQ0FDQSw0Q0FBQSxDQUtBLFlBQUEsQ0FDQSxxQkFBQSxDQVpBLE1BQUEsQ0FFQSxjQUFBLENBTUEsZ0JBQUEsQ0FDQSxlQUFBLENBQ0EsYUFBQSxDQVpBLGlCQUFBLENBR0EsT0FBQSxDQUZBLFFBQUEsQ0FRQSxVQUtBLENBRUEsNENBQ0UsWUFBQSxDQUlKLDZCQVNFLGtCQUFBLENBTEEsY0FBQSxDQURBLFdBQUEsQ0FJQSxhQUFBLENBSUEsY0FBQSxDQUhBLFlBQUEsQ0FGQSxjQUFBLENBSUEsT0FBQSxDQUxBLGdCQUFBLENBSEEsZUFBQSxDQVVBLDJDQUFBLENBWEEsVUFXQSxDQUVBLG1DQUNFLGtCQUFBLENBQ0EsYUFBQSxDQUlKLCtCQU1FLGtCQUFBLENBRkEsa0JBQUEsQ0FEQSxvQkFBQSxDQU9BLGFBQUEsQ0FMQSxZQUFBLENBR0EsY0FBQSxDQUNBLGVBQUEsQ0FQQSxXQUFBLENBS0Esc0JBQUEsQ0FOQSxVQVNBLENBR0Ysa0VBQ0UsOEJBQUEsQ0FDQSxhQUFBLENBR0YsMkJBR0UsY0FBQSxDQUNBLFdBQUEsQ0FLQSxrQkFBQSxDQUZBLGFBQUEsQ0FHQSxjQUFBLENBTEEsY0FBQSxDQUNBLGVBQUEsQ0FFQSxnQkFBQSxDQU5BLGVBQUEsQ0FTQSwyQ0FBQSxDQVZBLFVBVUEsQ0FFQSxpQ0FDRSxrQkFBQSxDQUlKLDJCQUNFLGtCQUFBLENBR0Esc0NBQUEsQ0FGQSxVQUFBLENBQ0EsZUFDQSxDQUVBLGlDQUNFLGtCQUFBLENBSUosMEJBS0UsYUFBQSxDQUpBLGNBQUEsQ0FDQSxlQUFBLENBRUEsb0JBQUEsQ0FHQSxrQkFBQSxDQURBLGVBQUEsQ0FFQSxhQUFBLENBTEEsd0JBS0EsQ0FHRix3QkFFRSxrQkFBQSxDQUdBLGtCQUFBLENBQ0EscUNBQUEsQ0FDQSxrQkFBQSxDQUVBLGNBQUEsQ0FSQSxZQUFBLENBRUEsT0FBQSxDQUNBLFdBQUEsQ0FNQSxpQkFBQSxDQUZBLDJDQUVBLENBRUEsOEJBQ0UsZUFBQSxDQUNBLGdDQUFBLENBSUoseUJBQ0UsYUFBQSxDQUVBLFlBQUEsQ0FEQSxXQUNBLENBR0Ysb0JBRUUsY0FBQSxDQUNBLFdBQUEsQ0FJQSxhQUFBLENBQ0EsY0FBQSxDQUhBLGNBQUEsQ0FDQSxlQUFBLENBRkEsU0FBQSxDQUhBLFVBT0EsQ0FFQSx1REFDRSxjQUFBLENBSUosK0JBR0UsNEJBQUEsQ0FDQSxZQUFBLENBQ0EscUJBQUEsQ0FDQSxPQUFBLENBTEEsZUFBQSxDQUNBLGdCQUlBLENBR0Ysc0JBR0Usa0JBQUEsQ0FFQSxXQUFBLENBQ0Esa0JBQUEsQ0FJQSxzQ0FBQSxDQU5BLFVBQUEsQ0FLQSxjQUFBLENBRkEsY0FBQSxDQUNBLGVBQUEsQ0FOQSxXQUFBLENBU0EsMkNBQUEsQ0FWQSxVQVVBLENBRUEsNEJBQ0UsOEJBQUEsQ0FHRiw2QkFDRSxvQkFBQSxDQUlKLHNCQUdFLGNBQUEsQ0FDQSxXQUFBLENBRUEsa0JBQUEsQ0FEQSxhQUFBLENBTUEsY0FBQSxDQUpBLGNBQUEsQ0FDQSxlQUFBLENBTkEsV0FBQSxDQVFBLG1CQUFBLENBREEsd0JBQUEsQ0FHQSwyQ0FBQSxDQVhBLFVBV0EsQ0FFQSw0QkFDRSxrQkFBQSxDQUNBLGFBQUEsQ0FJSix1QkFRRSxrQkFBQSxDQU5BLGlCQUFBLENBS0EsWUFBQSxDQUZBLGFBQUEsQ0FJQSxzQkFBQSxDQUhBLGlCQUFBLENBTEEsU0FBQSxDQUdBLFdBTUEsQ0FFQSxvREFUQSxjQUFBLENBT0Esa0RBVUUsQ0FSRiw2QkFJRSxRQUFBLENBSEEsVUFBQSxDQUlBLFFBQUEsQ0FIQSxpQkFBQSxDQUlBLFNBQUEsQ0FIQSxLQUtBLENBSUEsbUNBQ0UsOEJBQUEsQ0FFRixrREFDRSxrQkFBQSxDQUNBLG9CQUFBLENBR0EsMENBQUEsQ0FGQSxVQUFBLENBQ0EseUNBQ0EsQ0FNSixtQ0FDRSx3Q0FBQSxDQUVGLGtEQUVFLDRCQUFBLENBQ0EsOEJBQUEsQ0FFQSxrREFBQSxDQURBLG9CQUFBLENBSEEsbURBSUEsQ0FJSixxQkFZRSxrQkFBQSxDQUpBLGVBQUEsQ0FDQSx3QkFBQSxDQUZBLGlCQUFBLENBR0Esc0VBQUEsQ0FJQSxhQUFBLENBSEEsWUFBQSxDQUxBLFdBQUEsQ0FPQSxzQkFBQSxDQVZBLFFBQUEsQ0FGQSxpQkFBQSxDQUNBLE9BQUEsQ0FFQSx1Q0FBQSxDQVlBLDJDQUFBLENBWEEsVUFBQSxDQVVBLFdBQ0EsQ0FNRix3QkFLRSxlQUFBLENBSEEsWUFBQSxDQURBLE1BQUEsQ0FFQSxxQkFBQSxDQUNBLGVBQ0EsQ0FHRixvQkFJRSxrQkFBQSxDQUhBLGVBQUEsQ0FDQSwrQkFBQSxDQUNBLFlBQUEsQ0FHQSxhQUFBLENBREEsNkJBQUEsQ0FFQSxjQUFBLENBR0YsNEJBQ0UsWUFBQSxDQUNBLFFBQUEsQ0FHRixxQkFDRSxjQUFBLENBQ0EsV0FBQSxDQUlBLGFBQUEsQ0FDQSxjQUFBLENBSEEsY0FBQSxDQUNBLGVBQUEsQ0FGQSxnQkFBQSxDQUtBLGlCQUFBLENBQ0EsNkNBQUEsQ0FFQSwyQkFDRSxhQUFBLENBT0YsNERBQ0UsYUFBQSxDQUlKLHdCQU1FLGtCQUFBLENBQ0Esb0JBQUEsQ0FMQSxRQUFBLENBR0EsVUFBQSxDQUZBLFFBQUEsQ0FGQSxpQkFBQSxDQUdBLFNBR0EsQ0FHRixzQkFhRSxrQkFBQSxDQVpBLGtCQUFBLENBRUEsd0JBQUEsQ0FFQSxvQkFBQSxDQUhBLGFBQUEsQ0FRQSxjQUFBLENBRUEsbUJBQUEsQ0FOQSxjQUFBLENBQ0EsZUFBQSxDQU9BLHNCQUFBLENBTEEsb0JBQUEsQ0FMQSxnQkFBQSxDQUlBLHdCQUFBLENBR0EsMkNBR0EsQ0FFQSw0QkFDRSxrQkFBQSxDQUVBLG9CQUFBLENBREEsYUFDQSxDQUdGLDZCQUNFLG9CQUFBLENBSUosbUJBS0Usa0JBQUEsQ0FJQSwrQkFBQSxDQU5BLCtCQUFBLENBQ0EsWUFBQSxDQUlBLGFBQUEsQ0FOQSxXQUFBLENBS0EsNkJBQUEsQ0FOQSxlQUFBLENBS0EsZ0JBR0EsQ0FHRixvQkFFRSxrQkFBQSxDQURBLFlBQUEsQ0FHQSxNQUFBLENBREEsUUFDQSxDQUdGLHVCQUtFLGlCQUFBLENBRkEsd0JBQUEsQ0FHQSxhQUFBLENBSkEsV0FBQSxDQUVBLGFBQUEsQ0FIQSxTQUtBLENBR0YscUJBR0UsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUFBLENBRUEsa0JBQUEsQ0FHRiw2QkFHRSxrQkFBQSxDQUNBLDZCQUFBLENBSEEsWUFBQSxDQUNBLE9BQUEsQ0FJQSxlQUFBLENBREEsaUJBQ0EsQ0FHRixzQkFFRSxrQkFBQSxDQUdBLCtCQUFBLENBQ0EscUNBQUEsQ0FDQSxvQkFBQSxDQU9BLHlDQUFBLENBSkEsYUFBQSxDQVRBLFlBQUEsQ0FPQSxjQUFBLENBQ0EsZUFBQSxDQU5BLE9BQUEsQ0FTQSxvQkFBQSxDQVJBLGdCQUFBLENBT0Esd0JBQUEsQ0FJQSx1QkFBQSxDQUZBLGtCQUVBLENBRUEsNEJBQ0UsK0JBQUEsQ0FDQSxnQ0FBQSxDQUNBLHdDQUFBLENBSUosMkJBS0Usa0JBQUEsQ0FKQSw4QkFBQSxDQUNBLFdBQUEsQ0FNQSxpQkFBQSxDQUxBLGFBQUEsQ0FNQSxjQUFBLENBTEEsWUFBQSxDQUVBLHNCQUFBLENBS0EsaUJBQUEsQ0FKQSxXQUFBLENBR0EsdUJBQ0EsQ0FFQSxpQ0FDRSwrQkFBQSxDQUNBLGFBQUEsQ0FDQSx1QkFBQSxDQUlKLDJCQUVFLGtCQUFBLENBS0Esa0JBQUEsQ0FGQSxXQUFBLENBQ0EsaUJBQUEsQ0FLQSx5Q0FBQSxDQUhBLFVBQUEsQ0FJQSxjQUFBLENBWEEsWUFBQSxDQVFBLGNBQUEsQ0FDQSxlQUFBLENBUEEsT0FBQSxDQUNBLGdCQUFBLENBU0EsMkNBQUEsQ0FFQSxpQ0FDRSw4QkFBQSxDQUdGLGdDQUNFLGVBQUEsQ0FJSiw2QkFJRSxrQkFBQSxDQUNBLFlBQUEsQ0FKQSxNQUFBLENBS0EscUJBQUEsQ0FDQSxRQUFBLENBTEEsZUFBQSxDQUNBLFlBSUEsQ0FFQSxnREFDRSxZQUFBLENBT0oscUJBR0UsZUFBQSxDQUlBLHdCQUFBLENBQUEscUJBQUEsQ0FIQSxrQkFBQSxDQUtBLGNBQUEsQ0FDQSxZQUFBLENBQ0EsUUFBQSxDQVRBLGlCQUFBLENBREEsaUJBQUEsQ0FPQSwyQ0FHQSxDQUVBLHlCQWJGLHFCQWNJLHFCQUFBLENBQUEsQ0FHRiwyQkFHRSxvQkFBQSxDQURBLCtDQUFBLENBREEsMEJBRUEsQ0FJSiw2QkFDRSx3Q0FBQSxDQUNBLHFCQUFBLENBR0YsNkJBQ0Usb0JBQUEsQ0FHRixnQ0FDRSx1QkFBQSxDQUdGLDRCQUNFLGVBQUEsQ0FHRixtQkFDRSxtQ0FBQSxDQUNBLHlCQUVFLHFFQUFBLENBREEsdUZBQ0EsQ0FFRix5Q0FDRSw4Q0FBQSxDQUNBLHVCQUFBLENBS0YsNEZBQ0UsdUJBQUEsQ0FJSixvQkFDRSxtQ0FBQSxDQUNBLDBCQUVFLHFFQUFBLENBREEsdUZBQ0EsQ0FFRiwwQ0FDRSw4Q0FBQSxDQUNBLHVCQUFBLENBS0YsOEZBQ0UsdUJBQUEsQ0FJSixvQkFDRSxtQ0FBQSxDQUNBLDBCQUVFLHNFQUFBLENBREEsMEZBQ0EsQ0FFRiwwQ0FDRSwrQ0FBQSxDQUNBLHVCQUFBLENBS0YsOEZBQ0UsdUJBQUEsQ0FJSixxQkFDRSxtQ0FBQSxDQUNBLDJCQUVFLHNFQUFBLENBREEsMEZBQ0EsQ0FFRiwyQ0FDRSwrQ0FBQSxDQUNBLHVCQUFBLENBS0YsZ0dBQ0UsdUJBQUEsQ0FJSixxQkFDRSxtQ0FBQSxDQUNBLDJCQUVFLHFFQUFBLENBREEsdUZBQ0EsQ0FFRiwyQ0FDRSw4Q0FBQSxDQUNBLHVCQUFBLENBS0YsZ0dBQ0UsdUJBQUEsQ0FJSixzQkFDRSxtQ0FBQSxDQUNBLDRCQUVFLHNFQUFBLENBREEsMEZBQ0EsQ0FFRiw0Q0FDRSwrQ0FBQSxDQUNBLHVCQUFBLENBS0Ysa0dBQ0UsdUJBQUEsQ0FJSix1QkFDRSxtQ0FBQSxDQUNBLDZCQUVFLHNFQUFBLENBREEsMEZBQ0EsQ0FFRiw2Q0FDRSwrQ0FBQSxDQUNBLHVCQUFBLENBS0Ysb0dBQ0UsdUJBQUEsQ0FJSiwyQkFDRSxpQkFBQSxDQUVBLFVBQUEsQ0FEQSxRQUFBLENBRUEsVUFBQSxDQUdGLHdCQUlFLGtCQUFBLENBRkEsWUFBQSxDQUNBLHFCQUFBLENBRkEsYUFBQSxDQUlBLFFBQUEsQ0FFQSx5QkFQRix3QkFRSSxrQkFBQSxDQUNBLDZCQUFBLENBQUEsQ0FJSixzQkFJRSxrQkFBQSxDQUVBLGtCQUFBLENBQ0Esc0NBQUEsQ0FKQSxZQUFBLENBREEsV0FBQSxDQUdBLHNCQUFBLENBR0EsaURBQUEsQ0FQQSxVQU9BLENBUUYsNkJBSUUsK0JBQUEsQ0FDQSx1QkFBQSxDQUdGLGlEQUNFLHFCQUFBLENBR0YseUJBRUUsY0FBQSxDQURBLFdBQUEsQ0FHQSxvQkFBQSxDQUVBLGFBQUEsQ0FEQSxjQUFBLENBRUEsWUFBQSxDQUpBLFdBQUEsQ0FLQSxxSUFBQSxDQUVBLCtCQUNFLGtCQUFBLENBQ0EsYUFBQSxDQUNBLHFCQUFBLENBR0YsZ0NBQ0UsbUJBQUEsQ0FJSixtQkFDRSxNQUFBLENBQ0EsV0FBQSxDQUdGLHdCQUVFLGlCQUFBLENBREEsWUFBQSxDQUdBLFFBQUEsQ0FEQSw2QkFDQSxDQUdGLG9CQVVFLGFBQUEsQ0FUQSxjQUFBLENBQ0EsZUFBQSxDQUNBLHFCQUFBLENBQ0EsaUJBQUEsQ0FDQSxZQUFBLENBRUEsZUFBQSxDQUVBLGtCQUFBLENBREEsc0JBQUEsQ0FHQSw2Q0FBQSxDQUxBLGtCQUtBLENBR0YsK0NBQ0UsYUFBQSxDQUdGLHlCQUdFLGVBQUEsQ0FGQSxZQUFBLENBQ0EscUJBQUEsQ0FFQSxPQUFBLENBQ0EsaUJBQUEsQ0FHRixtQkFHRSxrQkFBQSxDQUZBLFlBQUEsQ0FDQSxPQUNBLENBR0YscUJBTUUsaUJBQUEsQ0FMQSxhQUFBLENBQ0EsZUFBQSxDQUVBLHFCQUFBLENBQ0EsZUFBQSxDQUZBLHdCQUdBLENBR0Ysb0JBQ0Usa0JBQUEsQ0FDQSxhQUFBLENBR0YscUJBQ0Usa0JBQUEsQ0FDQSxhQUFBLENBR0Ysd0JBRUUsa0JBQUEsQ0FRQSw0QkFBQSxDQUxBLGlCQUFBLENBSkEsWUFBQSxDQUtBLGNBQUEsQ0FDQSxlQUFBLENBSkEsT0FBQSxDQU1BLG1CQUFBLENBTEEsZ0JBQUEsQ0FJQSx3QkFFQSxDQUdGLDBCQUVFLGtCQUFBLENBTUEsYUFBQSxDQVBBLFlBQUEsQ0FHQSxjQUFBLENBREEsUUFBQSxDQUVBLGlCQUFBLENBRUEsZUFBQSxDQURBLGtCQUVBLENBR0Ysd0JBQ0UsY0FBQSxDQUNBLGVBQUEsQ0FFQSxtQkFBQSxDQUNBLFVBQUEsQ0FGQSx3QkFFQSxDQUdGLHdCQUNFLGFBQUEsQ0FDQSxlQUFBLENBR0Ysa0JBR0Usa0JBQUEsQ0FDQSxpQkFBQSxDQUNBLGFBQUEsQ0FIQSxVQUFBLENBREEsU0FJQSxDQUdGLDBCQU9FLG9CQUFBLENBQ0EsMkJBQUEsQ0FOQSxhQUFBLENBSUEsbUJBQUEsQ0FMQSxjQUFBLENBR0EsZUFBQSxDQURBLGVBQUEsQ0FFQSxpQkFBQSxDQUlBLGVBQUEsQ0FHRiw0QkFFRSxrQkFBQSxDQU1BLGFBQUEsQ0FQQSxZQUFBLENBR0EsY0FBQSxDQUNBLGVBQUEsQ0FGQSxPQUFBLENBSUEsbUJBQUEsQ0FEQSx3QkFFQSxDQUdGLDBCQU9FLGNBQUEsQ0FKQSxlQUFBLENBREEscUJBQUEsQ0FHQSxlQUFBLENBQ0Esc0JBQUEsQ0FMQSxtQkFBQSxDQUdBLGtCQUdBLENBRUEsZ0NBQ0UseUJBQUEsQ0FPSixxQkFJRSxrQkFBQSxDQUVBLGVBQUEsQ0FKQSw0QkFBQSxDQUNBLFlBQUEsQ0FJQSxhQUFBLENBTkEsV0FBQSxDQUlBLGNBRUEsQ0FHRix5QkFLRSxhQUFBLENBSkEsY0FBQSxDQUNBLGVBQUEsQ0FFQSxtQkFBQSxDQURBLHdCQUFBLENBR0EsNEJBQUEsQ0FHRixzQkFDRSxhQUFBLENBQ0EsWUFBQSxDQUdGLHdCQUNFLGFBQUEsQ0FHRiw2QkFHRSxrQkFBQSxDQUZBLFlBQUEsQ0FDQSxNQUFBLENBR0EsT0FBQSxDQURBLHNCQUNBLENBR0YsdUJBRUUsY0FBQSxDQURBLFdBQUEsQ0FHQSxrQkFBQSxDQUNBLGFBQUEsQ0FDQSxjQUFBLENBQ0EsWUFBQSxDQUpBLFdBQUEsQ0FLQSwyQ0FBQSxDQUVBLDZCQUNFLGtCQUFBLENBR0YsZ0NBRUUsa0JBQUEsQ0FEQSxVQUNBLENBSUoscUJBSUUsa0JBQUEsQ0FNQSxjQUFBLENBREEsNEJBQUEsQ0FIQSxrQkFBQSxDQUtBLGFBQUEsQ0FDQSxjQUFBLENBVEEsWUFBQSxDQUlBLGNBQUEsQ0FDQSxlQUFBLENBTkEsV0FBQSxDQUdBLHNCQUFBLENBUUEsMkNBQUEsQ0FaQSxVQVlBLENBRUEsMkJBQ0Usa0JBQUEsQ0FDQSxvQkFBQSxDQUlKLHdCQUNFLGtCQUFBLENBRUEsc0NBQUEsQ0FEQSxVQUNBLENBRUEsOEJBQ0Usa0JBQUEsQ0FJSiw2QkFFRSxhQUFBLENBQ0EsY0FBQSxDQUNBLGVBQUEsQ0FDQSxvQkFBQSxDQUpBLGFBSUEsQ0FHRix3QkFFRSxrQkFBQSxDQURBLFlBQUEsQ0FFQSxPQUFBLENBR0Ysc0JBS0UsYUFBQSxDQUpBLGNBQUEsQ0FDQSxlQUFBLENBRUEsbUJBQUEsQ0FEQSx3QkFFQSxDQUdGLHNCQUdFLGtCQUFBLENBQ0EsNEJBQUEsQ0FDQSxpQkFBQSxDQUtBLGFBQUEsQ0FIQSxjQUFBLENBRUEsZUFBQSxDQVBBLFdBQUEsQ0FNQSxTQUFBLENBRkEsaUJBQUEsQ0FLQSwyQ0FBQSxDQVZBLFVBVUEsQ0FFQSw0QkFDRSxlQUFBLENBQ0EsZ0NBQUEsQ0FPSix1QkFLRSxrQkFBQSxDQUhBLGVBQUEsQ0FDQSw0QkFBQSxDQUNBLFlBQUEsQ0FHQSxhQUFBLENBTkEsV0FBQSxDQUtBLGNBQ0EsQ0FHRiwyQkFHRSxrQkFBQSxDQUZBLFlBQUEsQ0FHQSxNQUFBLENBRkEsUUFFQSxDQUdGLHdCQUdFLGNBQUEsQ0FEQSxXQUFBLENBT0EsYUFBQSxDQUNBLGNBQUEsQ0FMQSxnQkFBQSxDQUNBLGVBQUEsQ0FMQSxXQUFBLENBT0Esb0JBQUEsQ0FKQSxhQUFBLENBT0EsaUJBQUEsQ0FKQSx3QkFBQSxDQUtBLDJDQUFBLENBRUEsOEJBQ0UsYUFBQSxDQU9GLDBEQUNFLGFBQUEsQ0FJSiwyQkFNRSxrQkFBQSxDQUNBLG9CQUFBLENBTEEsUUFBQSxDQUdBLFVBQUEsQ0FGQSxRQUFBLENBRkEsaUJBQUEsQ0FHQSxTQUdBLENBTUYsc0JBWUUscUVBQUEsQ0FQQSxlQUFBLENBQ0EsNkJBQUEsQ0FGQSxRQUFBLENBTUEsK0NBQUEsQ0FGQSxZQUFBLENBQ0EscUJBQUEsQ0FFQSxXQUFBLENBVkEsaUJBQUEsQ0FFQSxPQUFBLENBREEsS0FBQSxDQUtBLFdBTUEsQ0FFQSw4Q0FGQSxpR0FHRSxDQUlKLGlDQUNFLEdBQ0UsMEJBQUEsQ0FFRixHQUNFLHVCQUFBLENBQUEsQ0FJSix3QkFHRSxrQkFBQSxDQUtBLGVBQUEsQ0FGQSwrQkFBQSxDQUpBLFlBQUEsQ0FLQSxhQUFBLENBTkEsV0FBQSxDQUdBLDZCQUFBLENBQ0EsY0FHQSxDQUdGLDRCQUtFLGFBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLG9CQUFBLENBREEsd0JBRUEsQ0FHRiwwQkFFRSxjQUFBLENBREEsV0FBQSxDQUdBLG9CQUFBLENBQ0EsYUFBQSxDQUNBLGNBQUEsQ0FDQSxZQUFBLENBSkEsV0FBQSxDQUtBLDJDQUFBLENBRUEsZ0NBQ0Usa0JBQUEsQ0FDQSxhQUFBLENBSUosK0JBSUUsa0JBQUEsQ0FEQSxNQUFBLENBREEsZUFBQSxDQURBLFlBR0EsQ0FFQSxrREFDRSxZQUFBLENBSUosK0JBQ0UsZ0JBQUEsQ0FDQSxlQUFBLENBQ0Esd0JBQUEsQ0FFQSxrQkFBQSxDQURBLHdFQUFBLENBR0EsWUFBQSxDQUNBLHFCQUFBLENBRUEsa0JBQUEsQ0FKQSxlQUFBLENBR0EsaUJBQ0EsQ0FHRix3QkFFRSxrQkFBQSxDQUVBLFlBQUEsQ0FEQSxNQUFBLENBRUEscUJBQUEsQ0FDQSxRQUFBLENBTEEsWUFLQSxDQUdGLDJCQUVFLFNBR0EsQ0FHRixzREFIRSw0REFBQSxDQUZBLGtCQUFBLENBQ0EsaUJBQUEsQ0FIQSxXQWFBLENBTkYsMkJBTUUsVUFBQSxDQUpBLFNBSUEsQ0FHRiwyQkFRRSxrQkFBQSxDQU5BLGVBQUEsQ0FDQSx3QkFBQSxDQUNBLGtCQUFBLENBQ0EsNENBQUEsQ0FFQSxZQUFBLENBTkEsWUFBQSxDQVFBLHNCQUFBLENBSEEsZUFBQSxDQUtBLGVBQUEsQ0FEQSxpQkFDQSxDQUdGLDhCQUlFLDJEQUFBLENBQ0EseUJBQUEsQ0FIQSxPQUFBLENBQ0EsV0FBQSxDQUZBLGlCQUlBLENBR0Ysb0JBQ0UsYUFBQSxDQUNBLFVBQUEsQ0FHRiwwQkFDRSxZQUFBLENBQ0EscUJBQUEsQ0FDQSxRQUFBLENBQ0EsZUFBQSxDQUdGLG1CQUtFLDREQUFBLENBRkEsa0JBQUEsQ0FDQSxpQkFBQSxDQUhBLFdBQUEsQ0FDQSxVQUdBLENBR0Ysc0JBRUUsVUFBQSxDQURBLGFBQ0EsQ0FHRix3QkFFRSxVQUFBLENBREEsYUFDQSxDQUdGLDJCQUtFLGtCQUFBLENBSEEsZUFBQSxDQUNBLDRCQUFBLENBQ0EsWUFBQSxDQUhBLFdBQUEsQ0FLQSxzQkFBQSxDQUdGLGdDQUtFLGFBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLG9CQUFBLENBREEsd0JBRUEsQ0FHRix3QkFJRSxlQUFBLENBREEsV0FBQSxDQURBLFdBQUEsQ0FEQSxVQUdBLENBR0YsdUJBSUUsZUFBQSxDQUZBLFdBQUEsQ0FDQSxrQkFBQSxDQUZBLFVBR0EsQ0FHRiwrQkFHRSxlQUFBLENBS0EscUJBQUEsQ0FIQSxZQUFBLENBQ0EscUJBQUEsQ0FKQSxXQUFBLENBS0EsNkJBQUEsQ0FIQSxZQUFBLENBSEEsVUFPQSxDQUdGLDhCQUdFLGtCQUFBLENBRkEsWUFBQSxDQUNBLDZCQUFBLENBRUEsa0JBQUEsQ0FHRiw0QkFLRSxrQkFBQSxDQUZBLGlCQUFBLENBQ0EsWUFBQSxDQUZBLFdBQUEsQ0FJQSxzQkFBQSxDQUxBLFVBS0EsQ0FHRiw2QkFJRSxpQkFBQSxDQUhBLGNBQUEsQ0FDQSxlQUFBLENBR0EsbUJBQUEsQ0FGQSxnQkFFQSxDQUdGLDRCQUVFLFlBQUEsQ0FEQSxNQUFBLENBRUEscUJBQUEsQ0FHRiw2QkFRRSxvQkFBQSxDQUNBLDJCQUFBLENBTkEsYUFBQSxDQUlBLG1CQUFBLENBTkEsY0FBQSxDQUNBLGVBQUEsQ0FHQSxlQUFBLENBREEsZUFBQSxDQUVBLGVBR0EsQ0FHRixnQ0FFRSxrQkFBQSxDQUNBLGlCQUFBLENBRkEsVUFBQSxDQUdBLGtCQUFBLENBR0YsOEJBR0Usa0JBQUEsQ0FHQSw2QkFBQSxDQUxBLFlBQUEsQ0FDQSw2QkFBQSxDQUVBLGVBQUEsQ0FDQSxnQkFDQSxDQUdGLDRCQUdFLGFBQUEsQ0FGQSxjQUFBLENBQ0EsZUFDQSxDQUdGLDBCQUVFLDBDQUFBLENBREEsWUFBQSxDQUVBLFFBQUEsQ0FDQSxhQUFBLENBR0YsMEJBQ0UsWUFBQSxDQUNBLHFCQUFBLENBQ0EsT0FBQSxDQUdGLDJCQUVFLGFBQUEsQ0FEQSxhQUFBLENBR0EsZUFBQSxDQUNBLG9CQUFBLENBRkEsd0JBRUEsQ0FHRiwyQkFHRSxhQUFBLENBRkEsY0FBQSxDQUNBLGVBQ0EsQ0FHRiw0QkFNRSxlQUFBLENBQ0Esd0JBQUEsQ0FDQSxrQkFBQSxDQU5BLFlBQUEsQ0FDQSxxQkFBQSxDQUNBLE9BQUEsQ0FIQSx5QkFBQSxDQUlBLFlBR0EsQ0FHRix3QkFFRSxrQkFBQSxDQURBLFlBQUEsQ0FFQSxRQUFBLENBQ0EsY0FBQSxDQUdGLDZCQU9FLGtCQUFBLENBSEEsa0JBQUEsQ0FEQSxvQkFBQSxDQVFBLHNDQUFBLENBTkEsVUFBQSxDQUNBLFlBQUEsQ0FHQSxjQUFBLENBQ0EsZUFBQSxDQVJBLFdBQUEsQ0FNQSxzQkFBQSxDQVBBLFVBVUEsQ0FHRiwyQkFDRSxZQUFBLENBQ0EscUJBQUEsQ0FDQSxRQUFBLENBQ0Esa0JBQUEsQ0FHRixnQ0FFRSxlQUFBLENBQ0Esd0JBQUEsQ0FDQSxrQkFBQSxDQUVBLGFBQUEsQ0FEQSxjQUFBLENBS0EsaUJBQUEsQ0FIQSxlQUFBLENBQ0EsZ0JBQUEsQ0FDQSxlQUFBLENBUkEsWUFTQSxDQUVBLG1EQUNFLFlBQUEsQ0FJSixnQ0FDRSxZQUFBLENBQ0EsUUFBQSxDQUVBLG1CQUFBLENBREEsZUFDQSxDQUdGLHlCQVdFLGtCQUFBLENBVEEsa0JBQUEsQ0FHQSxXQUFBLENBQ0Esa0JBQUEsQ0FHQSxzQ0FBQSxDQU5BLFVBQUEsQ0FXQSxjQUFBLENBSkEsWUFBQSxDQVRBLE1BQUEsQ0FNQSxjQUFBLENBQ0EsZUFBQSxDQUtBLE9BQUEsQ0FUQSxXQUFBLENBUUEsc0JBQUEsQ0FHQSwyQ0FBQSxDQUVBLCtCQUNFLDhCQUFBLENBR0YsZ0NBQ0Usb0JBQUEsQ0FJSiw2QkFRRSxrQkFBQSxDQUxBLGVBQUEsQ0FDQSx3QkFBQSxDQUVBLGtCQUFBLENBSUEsc0NBQUEsQ0FMQSxhQUFBLENBTUEsY0FBQSxDQUpBLFlBQUEsQ0FMQSxXQUFBLENBT0Esc0JBQUEsQ0FHQSwyQ0FBQSxDQVhBLFVBV0EsQ0FFQSxtQ0FDRSxrQkFBQSxDQU9KLHNCQUNFLGtCQUFBLENBQ0EsNkJBQUEsQ0FLQSx5RUFBQSxDQUZBLFlBQUEsQ0FDQSxxQkFBQSxDQUhBLGFBQUEsQ0FLQSxXQUFBLENBSkEsVUFJQSxDQUdGLHdCQUdFLGtCQUFBLENBS0EsZUFBQSxDQUZBLCtCQUFBLENBSkEsWUFBQSxDQUtBLGFBQUEsQ0FOQSxXQUFBLENBR0EsNkJBQUEsQ0FDQSxjQUdBLENBR0YsMEJBRUUsa0JBQUEsQ0FEQSxZQUFBLENBRUEsT0FBQSxDQUdGLDRCQUtFLGFBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLG9CQUFBLENBREEsd0JBRUEsQ0FHRiwwQkFFRSxjQUFBLENBREEsV0FBQSxDQUdBLG9CQUFBLENBQ0EsYUFBQSxDQUNBLGNBQUEsQ0FDQSxZQUFBLENBSkEsV0FBQSxDQUtBLDJDQUFBLENBRUEsZ0NBQ0Usa0JBQUEsQ0FDQSxhQUFBLENBSUosK0JBQ0UsTUFBQSxDQUNBLGVBQUEsQ0FDQSxZQUFBLENBRUEsa0RBQ0UsWUFBQSxDQUlKLDJCQUNFLFlBQUEsQ0FDQSxxQkFBQSxDQUNBLE9BQUEsQ0FHRiwwQkFHRSw0QkFBQSxDQURBLGtCQUFBLENBREEsaUJBQUEsQ0FHQSwyQ0FBQSxDQUVBLGdDQUNFLGVBQUEsQ0FFQSxnQ0FBQSxDQURBLHNFQUNBLENBSUosNkJBT0Usa0JBQUEsQ0FIQSxjQUFBLENBREEsV0FBQSxDQU1BLGNBQUEsQ0FIQSxZQUFBLENBRUEsUUFBQSxDQUhBLFlBQUEsQ0FIQSxlQUFBLENBREEsVUFRQSxDQUdGLDZCQUVFLGtCQUFBLENBQ0EsaUJBQUEsQ0FDQSwwQ0FBQSxDQUNBLFlBQUEsQ0FKQSxZQUFBLENBS0EsMkNBQUEsQ0FHRiw2REFDRSxrQkFBQSxDQUNBLFVBQUEsQ0FHRiwwQkFDRSxNQUFBLENBQ0EsV0FBQSxDQUNBLGtCQUFBLENBR0YsK0JBR0UsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUFBLENBRUEsUUFBQSxDQUVBLGVBQUEsQ0FDQSxzQkFBQSxDQUNBLDZDQUFBLENBSEEsa0JBR0EsQ0FHRiwrREFDRSxhQUFBLENBR0YsK0JBS0UsYUFBQSxDQUpBLGNBQUEsQ0FDQSxlQUFBLENBRUEsb0JBQUEsQ0FFQSxjQUFBLENBSEEsd0JBR0EsQ0FHRiwrQkFNRSxjQUFBLENBREEsV0FBQSxDQUdBLG9CQUFBLENBQ0EsYUFBQSxDQUNBLGNBQUEsQ0FFQSxZQUFBLENBREEsU0FBQSxDQUpBLFdBQUEsQ0FOQSxpQkFBQSxDQUNBLFVBQUEsQ0FDQSxPQUFBLENBQ0EsMEJBQUEsQ0FTQSwyQ0FBQSxDQUVBLHFDQUNFLGtCQUFBLENBQ0EsYUFBQSxDQUlKLCtEQUNFLFNBQUEsQ0FHRiw0QkFFRSxpQkFBQSxDQURBLGlCQUNBLENBR0YsZ0NBT0Usa0JBQUEsQ0FKQSxlQUFBLENBQ0Esd0JBQUEsQ0FDQSxrQkFBQSxDQUtBLHNDQUFBLENBSkEsWUFBQSxDQUpBLFdBQUEsQ0FNQSxzQkFBQSxDQUNBLGtCQUFBLENBUkEsVUFTQSxDQUdGLDRCQUtFLGFBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLG9CQUFBLENBRUEsaUJBQUEsQ0FIQSx3QkFHQSxDQUdGLDJCQUVFLGFBQUEsQ0FEQSxjQUFBLENBRUEsZUFBQSxDQUNBLGVBQUEsQ0FDQSxRQUFBLENBR0Ysd0JBR0UsZUFBQSxDQURBLDRCQUFBLENBREEsWUFFQSxDQUdGLDZCQUdFLGtCQUFBLENBQ0EsV0FBQSxDQUVBLGtCQUFBLENBREEsYUFBQSxDQU1BLGNBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQU5BLFdBQUEsQ0FRQSxtQkFBQSxDQURBLHdCQUFBLENBR0EsMkNBQUEsQ0FYQSxVQVdBLENBRUEsbUNBQ0Usa0JBQUEsQ0FDQSxhQUFBLENBR0Ysb0NBQ0Usb0JBQUEsQ0FPSiw0QkFDRSxpQkFBQSxDQUdGLDJCQUVFLGNBQUEsQ0FEQSxXQUFBLENBR0EsaUJBQUEsQ0FFQSxhQUFBLENBREEsY0FBQSxDQUVBLFlBQUEsQ0FKQSxXQUFBLENBS0EsMkNBQUEsQ0FFQSxpQ0FDRSxrQkFBQSxDQUNBLGFBQUEsQ0FJSixpQ0FDRSw0QkFBQSxDQUVBLHNDQUFBLENBREEsdUJBQ0EsQ0FHRiw2QkFPRSxlQUFBLENBR0Esd0JBQUEsQ0FGQSxpQkFBQSxDQUNBLHlFQUFBLENBTEEsY0FBQSxDQU9BLGFBQUEsQ0FWQSxpQkFBQSxDQUNBLE9BQUEsQ0FDQSxRQUFBLENBR0EsV0FBQSxDQURBLFdBTUEsQ0FHRiw2QkFHRSxrQkFBQSxDQUlBLGNBQUEsQ0FEQSxXQUFBLENBR0EsYUFBQSxDQUNBLGNBQUEsQ0FSQSxZQUFBLENBTUEsY0FBQSxDQUpBLFFBQUEsQ0FDQSxnQkFBQSxDQU1BLGVBQUEsQ0FDQSxxRkFBQSxDQVhBLFVBV0EsQ0FFQSxtQ0FDRSxrQkFBQSxDQUNBLGFBQUEsQ0FJSix5QkFDRSxhQUFBLENBQ0EsYUFBQSxDQUNBLDZDQUFBLENBR0YsNERBQ0UsYUFBQSxDQU9GLHNEQUNFLHVCQUFBLENBTUYseUJBSUUseUJBQUEsQ0FEQSw0QkFBQSxDQURBLE9BQUEsQ0FEQSxjQUFBLENBSUEsVUFBQSxDQUdGLHVCQU9FLGVBQUEsQ0FDQSw0Q0FBQSxDQUVBLFlBQUEsQ0FDQSxxQkFBQSxDQVBBLFdBQUEsQ0FFQSxlQUFBLENBTEEsY0FBQSxDQUNBLE9BQUEsQ0FDQSxLQUFBLENBRUEsVUFBQSxDQUlBLFVBRUEsQ0FHRix1QkFJRSxrQkFBQSxDQUZBLCtCQUFBLENBQ0EsWUFBQSxDQUdBLGFBQUEsQ0FEQSw2QkFBQSxDQUpBLFlBS0EsQ0FHRiwyQkFFRSxrQkFBQSxDQURBLFlBQUEsQ0FFQSxRQUFBLENBR0Ysd0JBT0Usa0JBQUEsQ0FIQSw2QkFBQSxDQURBLGlCQUFBLENBRUEsYUFBQSxDQUNBLFlBQUEsQ0FKQSxXQUFBLENBTUEsc0JBQUEsQ0FQQSxVQU9BLENBR0YsMkJBQ0UsV0FBQSxDQUdGLHlCQUdFLGFBQUEsQ0FGQSxjQUFBLENBQ0EsZUFBQSxDQUVBLFFBQUEsQ0FFQSxlQUFBLENBQ0Esc0JBQUEsQ0FGQSxrQkFFQSxDQUdGLHVCQUdFLGFBQUEsQ0FGQSxjQUFBLENBQ0EsZUFBQSxDQUVBLGNBQUEsQ0FHRix5QkFFRSxjQUFBLENBREEsV0FBQSxDQUdBLG9CQUFBLENBQ0EsYUFBQSxDQUNBLGNBQUEsQ0FDQSxZQUFBLENBSkEsV0FBQSxDQUtBLDJDQUFBLENBRUEsK0JBQ0Usa0JBQUEsQ0FDQSxhQUFBLENBSUosOEJBQ0UsTUFBQSxDQUNBLGVBQUEsQ0FDQSxZQUFBLENBR0Ysd0JBQ0Usa0JBQUEsQ0FHRiw4QkFRRSxrQkFBQSxDQUhBLGFBQUEsQ0FFQSxZQUFBLENBTkEsY0FBQSxDQUNBLGVBQUEsQ0FPQSxPQUFBLENBTEEsb0JBQUEsQ0FFQSxrQkFBQSxDQUhBLHdCQU1BLENBR0YsNkJBSUUsa0JBQUEsQ0FHQSx3QkFBQSxDQURBLGtCQUFBLENBSkEsYUFBQSxDQURBLGNBQUEsQ0FFQSxlQUFBLENBRUEsWUFFQSxDQUdGLHdCQUNFLFlBQUEsQ0FDQSxxQkFBQSxDQUNBLFFBQUEsQ0FHRix1QkFDRSxZQUFBLENBQ0EsUUFBQSxDQUdGLHVCQUdFLGtCQUFBLENBRkEsWUFBQSxDQUNBLHFCQUNBLENBR0YsdUJBR0Usa0JBQUEsQ0FDQSxpQkFBQSxDQUZBLFVBQUEsQ0FHQSxjQUFBLENBSkEsU0FJQSxDQUdGLHVCQUdFLGtCQUFBLENBRkEsTUFBQSxDQUdBLFlBQUEsQ0FGQSxTQUVBLENBR0Ysd0JBQ0UsbUJBQUEsQ0FHRix1QkFHRSxhQUFBLENBRkEsY0FBQSxDQUNBLGVBQUEsQ0FFQSxpQkFBQSxDQUdGLHlCQUdFLGFBQUEsQ0FGQSxjQUFBLENBQ0EsZUFDQSxDQUdGLHlCQUVFLGFBQUEsQ0FEQSxjQUFBLENBRUEsY0FBQSxDQUdGLHVCQUdFLGtCQUFBLENBREEsNEJBQUEsQ0FFQSxZQUFBLENBRUEsYUFBQSxDQURBLFFBQUEsQ0FKQSxZQUtBLENBR0YsMkJBR0Usa0JBQUEsQ0FJQSxrQkFBQSxDQUVBLFdBQUEsQ0FHQSxpQkFBQSxDQUpBLFVBQUEsQ0FLQSxjQUFBLENBWEEsWUFBQSxDQURBLE1BQUEsQ0FTQSxjQUFBLENBQ0EsZUFBQSxDQU5BLE9BQUEsQ0FDQSxXQUFBLENBRkEsc0JBQUEsQ0FVQSxrREFBQSxDQUVBLGlDQUNFLGtCQUFBLENBSUosNkJBR0Usa0JBQUEsQ0FJQSxlQUFBLENBQ0Esd0JBQUEsQ0FJQSxpQkFBQSxDQUhBLGFBQUEsQ0FJQSxjQUFBLENBWEEsWUFBQSxDQURBLE1BQUEsQ0FTQSxjQUFBLENBQ0EsZUFBQSxDQU5BLE9BQUEsQ0FDQSxXQUFBLENBRkEsc0JBQUEsQ0FVQSxrREFBQSxDQUVBLG1DQUNFLGtCQUFBLENBT0oscUJBRUUsa0JBQUEsQ0FNQSxhQUFBLENBUEEsWUFBQSxDQUtBLGNBQUEsQ0FDQSxlQUFBLENBSEEsUUFBQSxDQURBLHNCQUFBLENBRUEsWUFHQSxDQUdGLGtCQU1FLDJDQUFBLENBRkEsMEJBQUEsQ0FDQSxpQkFBQSxDQURBLHdCQUFBLENBRkEsV0FBQSxDQURBLFVBS0EsQ0FHRixxQkFHRSxrQkFBQSxDQUlBLGFBQUEsQ0FOQSxZQUFBLENBQ0EscUJBQUEsQ0FFQSxzQkFBQSxDQUNBLGlCQUFBLENBQ0EsaUJBQ0EsQ0FFQSx5QkFFRSxrQkFBQSxDQURBLFdBQ0EsQ0FHRix3QkFHRSxhQUFBLENBRkEsY0FBQSxDQUNBLGVBQUEsQ0FFQSxjQUFBLENBR0YsdUJBRUUsYUFBQSxDQURBLGNBQUEsQ0FFQSxRQUFBLENBT0oseUJBQ0UsR0FBSyx1QkFBQSxDQUFBLENBR1AsMEJBQ0UsTUFBVyxTQUFBLENBQ1gsSUFBTSxVQUFBLENBQUEsQ0FNUixpQ0FFRSxrQkFBQSxDQURBLFlBQUEsQ0FFQSxRQUFBLENBR0YsNkJBR0UsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUFBLENBR0EsYUFBQSxDQURBLFFBQ0EsQ0FHRixnQ0FLRSxhQUFBLENBSkEsY0FBQSxDQUNBLGVBQUEsQ0FFQSxtQkFBQSxDQUVBLGNBQUEsQ0FIQSx3QkFHQSxDQUdGLCtCQUVFLGtCQUFBLENBREEsZUFDQSxDQUdGLHNCQUdFLGFBQUEsQ0FGQSxjQUFBLENBQ0EsZUFBQSxDQUdBLHFCQUFBLENBREEsZ0JBQUEsQ0FFQSxjQUFBLENBR0YsdUJBRUUsa0JBQUEsQ0FEQSxZQUFBLENBRUEsT0FBQSxDQUdGLG9CQU1FLGlCQUFBLENBTEEsY0FBQSxDQUdBLG1CQUFBLENBQ0EsZUFBQSxDQUZBLHdCQUdBLENBR0Ysd0JBR0UsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUNBLENBR0Ysb0JBQ0Usc0JBQUEsQ0FDQSx3QkFBQSxDQUNBLGtCQUFBLENBQ0EsNEJBQUEsQ0FHRixvQkFHRSxrQkFBQSxDQUNBLHFDQUFBLENBQ0Esa0JBQUEsQ0FDQSwrQkFBQSxDQUpBLFlBQUEsQ0FLQSxvREFBQSxDQU5BLCtCQU1BLENBRUEsMEJBQ0UsZ0NBQUEsQ0FJSixxQkFLRSxhQUFBLENBSkEsYUFBQSxDQUNBLGVBQUEsQ0FFQSxtQkFBQSxDQUdBLGFBQUEsQ0FEQSxjQUFBLENBSEEsd0JBSUEsQ0FHRixxQkFHRSxhQUFBLENBRkEsY0FBQSxDQUNBLGVBQUEsQ0FFQSxRQUFBLENBR0YscUJBRUUsa0JBQUEsQ0FHQSxlQUFBLENBQ0Esd0JBQUEsQ0FDQSxrQkFBQSxDQUNBLHNDQUFBLENBUEEsWUFBQSxDQUVBLDZCQUFBLENBT0Esa0JBQUEsQ0FOQSxZQUFBLENBS0EsMkNBQ0EsQ0FFQSwyQkFDRSxzRUFBQSxDQUlKLHlCQUVFLGtCQUFBLENBREEsWUFBQSxDQUVBLFFBQUEsQ0FHRix1QkFLRSxrQkFBQSxDQUZBLGtCQUFBLENBTUEsVUFBQSxDQUxBLFlBQUEsQ0FJQSxjQUFBLENBREEsZUFBQSxDQUxBLFdBQUEsQ0FJQSxzQkFBQSxDQUxBLFVBUUEsQ0FHRixzQkFJRSxrQkFBQSxDQUVBLG9CQUFBLENBSEEsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUFBLENBR0EsZ0JBQUEsQ0FFQSwyQ0FBQSxDQUVBLDRCQUNFLCtCQUFBLENBQ0EsYUFBQSxDQUlKLDRCQUNFLGtCQUFBLENBR0YsMkJBRUUsa0JBQUEsQ0FEQSxZQUFBLENBRUEsNkJBQUEsQ0FDQSxrQkFBQSxDQUdGLDBCQUtFLGFBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLG1CQUFBLENBRUEsUUFBQSxDQUhBLHdCQUdBLENBR0Ysc0JBR0UsYUFBQSxDQUNBLGNBQUEsQ0FIQSxjQUFBLENBQ0EsZUFFQSxDQUVBLDRCQUNFLHlCQUFBLENBSUosbUNBRUUsaUJBQUEsQ0FEQSxpQkFDQSxDQUdGLCtCQU1FLDhCQUFBLENBQ0EsaUJBQUEsQ0FIQSxRQUFBLENBRkEsTUFBQSxDQURBLGlCQUFBLENBRUEsS0FBQSxDQUVBLFNBRUEsQ0FHRix5QkFFRSxhQUFBLENBREEsY0FBQSxDQUdBLGlCQUFBLENBQ0EsZUFBQSxDQUZBLGVBQUEsQ0FHQSxRQUFBLENBR0YsdUJBQ0UsWUFBQSxDQUNBLFFBQUEsQ0FFQSxtQkFBQSxDQURBLGdCQUNBLENBR0YsMkJBYUUsa0JBQUEsQ0FYQSxrQkFBQSxDQUdBLFdBQUEsQ0FDQSxrQkFBQSxDQUtBLCtDQUFBLENBUkEsVUFBQSxDQWFBLGNBQUEsQ0FKQSxZQUFBLENBWEEsTUFBQSxDQU1BLGNBQUEsQ0FDQSxlQUFBLENBT0EsT0FBQSxDQVhBLFdBQUEsQ0FVQSxzQkFBQSxDQUpBLG1CQUFBLENBREEsd0JBQUEsQ0FRQSwyQ0FBQSxDQUVBLGlDQUNFLGtCQUFBLENBQ0EsMEJBQUEsQ0FHRixrQ0FDRSx1QkFBQSxDQUlKLDZCQVFFLGtCQUFBLENBTEEsZUFBQSxDQUNBLHdCQUFBLENBRUEsa0JBQUEsQ0FEQSxhQUFBLENBS0EsY0FBQSxDQUhBLFlBQUEsQ0FMQSxXQUFBLENBT0Esc0JBQUEsQ0FFQSwyQ0FBQSxDQVZBLFVBVUEsQ0FFQSxtQ0FHRSxrQkFBQSxDQURBLG9CQUFBLENBREEsYUFFQSxDQU9KLDRCQU1FLGtCQUFBLENBRkEseUJBQUEsQ0FEQSxrQ0FBQSxDQUVBLFlBQUEsQ0FIQSxPQUFBLENBS0Esc0JBQUEsQ0FOQSxjQUFBLENBT0EsY0FBQSxDQUdGLDRCQUVFLGVBQUEsQ0FDQSxrQkFBQSxDQUNBLDJFQUFBLENBRUEscUJBQUEsQ0FEQSxZQUFBLENBRUEsaUJBQUEsQ0FOQSxXQU1BLENBR0YsMEJBSUUsY0FBQSxDQUNBLFdBQUEsQ0FDQSxhQUFBLENBQ0EsY0FBQSxDQUNBLGNBQUEsQ0FQQSxpQkFBQSxDQUVBLFVBQUEsQ0FEQSxRQU1BLENBR0YsMkJBRUUsa0JBQUEsQ0FEQSxZQUFBLENBRUEsUUFBQSxDQUNBLGtCQUFBLENBR0YsZ0NBRUUsa0JBQUEsQ0FLQSx3QkFBQSxDQURBLGlCQUFBLENBRUEsVUFBQSxDQVBBLFlBQUEsQ0FRQSxjQUFBLENBQ0EsZUFBQSxDQUxBLFdBQUEsQ0FGQSxzQkFBQSxDQUNBLFVBTUEsQ0FHRiwwQkFHRSxhQUFBLENBRUEsK0JBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQUVBLFFBQ0EsQ0FHRiw2QkFFRSxrQkFBQSxDQUtBLGtCQUFBLENBSEEsd0JBQUEsQ0FDQSxpQkFBQSxDQUpBLFlBQUEsQ0FFQSxPQUFBLENBS0Esa0JBQUEsQ0FGQSxnQkFFQSxDQUdGLDRCQUVFLGFBQUEsQ0FJQSxNQUFBLENBQ0EsK0JBQUEsQ0FOQSxjQUFBLENBRUEsZUFBQSxDQUNBLHNCQUFBLENBQ0Esa0JBRUEsQ0FHRiwrQkFJRSxlQUFBLENBREEsd0JBQUEsQ0FEQSxrQkFBQSxDQUdBLGFBQUEsQ0FHQSxjQUFBLENBRUEsK0JBQUEsQ0FKQSxjQUFBLENBQ0EsZUFBQSxDQU5BLGdCQUFBLENBUUEsd0JBQ0EsQ0FFQSxxQ0FDRSxrQkFBQSxDQUlKLHFDQUNFLDRCQUFBLENBQ0EsdUJBQUEsQ0FHRiwyQkFFRSxrQkFBQSxDQUdBLGFBQUEsQ0FKQSxZQUFBLENBS0EsK0JBQUEsQ0FGQSxjQUFBLENBREEsNkJBR0EsQ0FHRixpQ0FFRSxrQkFBQSxDQUdBLGFBQUEsQ0FEQSxjQUFBLENBSEEsWUFBQSxDQUtBLGVBQUEsQ0FIQSxPQUdBLENBR0YsMEJBRUUsWUFBQSxDQURBLE1BQUEsQ0FFQSxxQkFBQSxDQUNBLGVBQUEsQ0FNRiw4QkFJRSxrQkFBQSxDQUZBLGdCQUFBLENBREEsMkJBQUEsQ0FFQSxlQUFBLENBRUEsb0JBQUEsQ0FHRiwrQkFJRSxrQkFBQSxDQUZBLGlCQUFBLENBQ0EsWUFBQSxDQUVBLHNCQUFBLENBSkEsV0FJQSxDQUdGLHlCQUNFLGVBQUEsQ0FDQSxzQkFBQSxDQUNBLGtCQUFBLENBR0YscUJBS0UsYUFBQSxDQUpBLGFBQUEsQ0FDQSxlQUFBLENBRUEsbUJBQUEsQ0FHQSxhQUFBLENBREEsY0FBQSxDQUhBLHdCQUlBLENBR0Ysb0JBR0UsYUFBQSxDQUZBLGNBQUEsQ0FDQSxlQUFBLENBRUEsUUFBQSxDQUdGLHdCQUNFLHVCQUFBLENBR0Ysb0JBSUUsaUJBQUEsQ0FIQSxhQUFBLENBQ0EsZUFBQSxDQU1BLGVBQUEsQ0FEQSxlQUFBLENBSkEsZ0JBQUEsQ0FHQSxzQkFBQSxDQURBLGtCQUdBLENBR0YsdUJBQWdCLG1CQUFBLENBQ2hCLHVCQUFnQixtQkFBQSxDQUNoQix1QkFBZ0IsbUJBQUEsQ0FDaEIsdUJBQWdCLG1CQUFBLENBR2hCLCtCQUNFLHlCQUFBLENBR0YsZ0NBRUUsNEJBQUEsQ0FEQSwyQkFDQSxDQUdGLGdDQVNFLDRCQUFBLENBUEEsd0JBQUEsQ0FDQSxzQkFBQSxDQUVBLGlCQUFBLENBQ0EscUJBQUEsQ0FMQSwyQkFBQSxDQVNBLGlDQUFBLENBRUEsc0NBQ0UseUJBQUEsQ0FDQSwwQ0FBQSxDQUlKLHFCQUlFLDRCQUFBLENBSEEsdUJBQUEsQ0FFQSxzQkFBQSxDQURBLHFCQUVBLENBR0Ysc0JBRUUsd0JBQUEsQ0FDQSxxQkFBQSxDQUlBLHVCQUFBLENBRkEsd0JBQUEsQ0FDQSx5QkFBQSxDQUZBLG1CQUFBLENBSEEsb0JBTUEsQ0FHRiw2QkFhRSx5QkFBQSxDQUZBLGtDQUFBLENBQ0EsNEJBQUEsQ0FFQSxxRkFBQSxDQU5BLHNCQUFBLENBQ0EsK0JBQUEsQ0FOQSxnQkFBQSxDQUdBLHdCQUFBLENBQ0EsMEJBQUEsQ0FHQSx1QkFBQSxDQVRBLDJCQUFBLENBR0EsaUJBQUEsQ0FGQSxrQkFBQSxDQUdBLHFCQVNBLENBR0YsbUNBR0UsNEJBQUEsQ0FFQSx5Q0FBQSxDQUpBLHNCQUFBLENBQ0EsdUNBQUEsQ0FJQSwyQkFBQSxDQUZBLDZCQUVBLENBR0Ysa0NBRUUsdUJBQUEsQ0FEQSx3QkFBQSxDQUVBLHlCQUFBLENBR0YsaUNBQ0Usd0JBQUEsQ0FDQSxxQkFBQSxDQUNBLHVCQUFBLENBRUEsd0JBQUEsQ0FEQSx3QkFBQSxDQUVBLHlCQUFBLENBR0YsK0JBQ0Usc0JBQUEsQ0FDQSwrQkFBQSxDQUNBLGlCQUFBLENBRUEsMEJBQUEsQ0FEQSx5QkFBQSxDQUVBLDJCQUFBLENBR0YsMEJBRUUsNEJBQUEsQ0FJQSxzQ0FBQSxDQUZBLHdCQUFBLENBSEEsc0JBQUEsQ0FFQSxrQkFBQSxDQUVBLDJCQUFBLENBRUEsa0NBQUEsQ0FDQSxrQ0FBQSxDQUFBLDhCQUFBLENBQUEsMEJBQUEsQ0FPRixpRUFDRSxrQ0FBQSxDQUdGLDJCQU9FLDRCQUFBLENBSEEsa0NBQUEsQ0FEQSwyQkFBQSxDQUVBLHVCQUFBLENBQ0Esc0JBQUEsQ0FHQSx3QkFBQSxDQUNBLHlCQUFBLENBUkEscUJBQUEsQ0FNQSxnQ0FBQSxDQVBBLG9CQVNBLENBR0Ysa0NBQ0Usa0NBQUEsQ0FDQSx1QkFBQSxDQUdGLHlCQUVFLHVCQUFBLENBREEsd0JBQUEsQ0FFQSx5QkFBQSxDQUNBLHlCQUFBLENBQ0EsZ0NBQUEsQ0FDQSw0QkFBQSxDQUdGLGdDQUNFLHVCQUFBLENBQ0EseUJBQUEsQ0FHRiw4QkFHRSx1QkFBQSxDQURBLHdCQUFBLENBRUEsMkJBQUEsQ0FIQSxzQkFBQSxDQUlBLDJCQUFBLENBR0YsNEJBQ0UsdUJBQUEsQ0FHRiwyQkFDRSx1QkFBQSxDQUdGLDJCQUlFLDRCQUFBLENBREEsc0JBQUEsQ0FFQSxnQ0FBQSxDQUhBLHlCQUFBLENBREEsbUJBSUEsQ0FHRiw2QkFFRSxxQkFBQSxDQUNBLDBCQUFBLENBRkEsb0JBRUEsQ0FNRix3QkFFRSw0QkFBQSxDQURBLHNCQUFBLENBRUEsaUJBQUEsQ0FDQSxzQkFBQSxDQUdGLG9CQUtFLHVCQUFBLENBSkEsd0JBQUEsQ0FDQSx5QkFBQSxDQUVBLDZCQUFBLENBREEsa0NBRUEsQ0FHRixxQkFFRSw0QkFBQSxDQUNBLGtDQUFBLENBQ0EsOEJBQUEsQ0FJQSx1QkFBQSxDQUNBLHdCQUFBLENBSEEsd0JBQUEsQ0FDQSx5QkFBQSxDQU5BLHFCQUFBLENBU0EsbUJBQUEsQ0FMQSx3QkFBQSxDQU1BLGlDQUFBLENBRUEsMkJBQ0UsNEJBQUEsQ0FDQSw4QkFBQSxDQUdGLDJCQUNFLDhCQUFBLENBQ0EsbURBQUEsQ0FJSiwwQkFFRSxzQkFBQSxDQUNBLCtCQUFBLENBQ0Esa0JBQUEsQ0FIQSw0QkFHQSxDQUdGLHVCQUlFLHNGQUFBLENBRUEsK0NBQUEsQ0FBQSx1Q0FBQSxDQUNBLDRCQUFBLENBRUEsb0RBQUEsQ0FFQSx3QkFBQSxDQVZBLHNCQUFBLENBQ0Esa0JBQUEsQ0FDQSwyQkFBQSxDQUtBLDhCQUFBLENBRUEscURBQ0EsQ0FFQSw2QkFJRSxzRkFBQSxDQURBLDBDQUFBLENBREEscURBQUEsQ0FEQSxvQ0FHQSxDQUlKLDJCQU1FLDRCQUFBLENBSEEseUNBQUEsQ0FDQSwyQkFBQSxDQU1BLHlEQUFBLENBTEEsc0JBQUEsQ0FJQSx1QkFBQSxDQURBLHdCQUFBLENBTkEscUJBQUEsQ0FLQSxnQ0FBQSxDQU5BLG9CQVNBLENBR0YsMkJBR0Usc0JBQUEsQ0FGQSxnQkFBQSxDQUdBLCtCQUFBLENBQ0EsaUJBQUEsQ0FIQSxxQkFHQSxDQUdGLDJCQUVFLDRCQUFBLENBREEsc0JBQUEsQ0FHQSxrQkFBQSxDQURBLHVDQUNBLENBR0YsNEJBR0UsdUJBQUEsQ0FGQSx3QkFBQSxDQUNBLHlCQUFBLENBRUEsa0JBQUEsQ0FHRixnQ0FJRSx3Q0FBQSxDQUVBLDhCQUFBLENBSEEsdUJBQUEsQ0FGQSx1QkFBQSxDQUNBLHlCQUFBLENBTUEsOEJBQUEsQ0FIQSx5QkFBQSxDQUVBLGtDQUNBLENBR0Ysa0NBRUUsdUJBQUEsQ0FEQSx3QkFBQSxDQUVBLHlCQUFBLENBQ0Esc0JBQUEsQ0FHRiwyQkFRRSw0QkFBQSxDQUxBLHVCQUFBLENBSUEsNkJBQUEsQ0FOQSx3QkFBQSxDQUNBLHlCQUFBLENBT0EsaUJBQUEsQ0FKQSw4QkFBQSxDQUNBLHdCQUFBLENBRkEsa0NBS0EsQ0FFQSxpQ0FDRSxtQ0FBQSxDQUtKLCtCQVFFLHlDQUFBLENBSEEsdUJBQUEsQ0FLQSx1QkFBQSxDQVRBLHVCQUFBLENBQ0EseUJBQUEsQ0FFQSw4QkFBQSxDQUdBLDRCQUFBLENBREEseUJBQUEsQ0FHQSw0QkFBQSxDQU5BLGtDQU9BLENBR0YsMkJBQ0UsNEJBQUEsQ0FHRiwrQkFDRSxzQkFBQSxDQUNBLCtCQUFBLENBQ0EsaUJBQUEsQ0FHRiw0QkFHRSw0QkFBQSxDQUdBLHlCQUFBLENBQ0Esa0NBQUEsQ0FDQSw0QkFBQSxDQUNBLHdCQUFBLENBUEEsc0JBQUEsQ0FFQSx1Q0FBQSxDQUNBLDJCQUFBLENBS0EsaUNBQUEsQ0FUQSxvQkFTQSxDQUVBLGtDQUNFLHlDQUFBLENBQ0EsMkNBQUEsQ0FDQSwrREFDRSx1QkFBQSxDQUtOLDZCQUdFLHVCQUFBLENBRkEsd0JBQUEsQ0FDQSx5QkFBQSxDQUdBLHlCQUFBLENBREEseUJBQUEsQ0FFQSxnQ0FBQSxDQUNBLDRCQUFBLENBR0YsOEJBSUUseUNBQUEsQ0FFQSw4QkFBQSxDQUhBLHVCQUFBLENBRkEsd0JBQUEsQ0FDQSx5QkFBQSxDQUdBLHlCQUFBLENBRUEsNEJBQUEsQ0FHRiw0QkFDRSxzQkFBQSxDQUNBLCtCQUFBLENBQ0EsaUJBQUEsQ0FHRiwwQkFFRSw0QkFBQSxDQUdBLHlCQUFBLENBQ0Esa0NBQUEsQ0FDQSw0QkFBQSxDQUdBLHdCQUFBLENBVEEsc0JBQUEsQ0FFQSxrQkFBQSxDQUNBLDJCQUFBLENBSUEsOEJBQUEsQ0FDQSxpQ0FDQSxDQUVBLGdDQUNFLHlDQUFBLENBQ0EsMkNBQUEsQ0FDQSw0REFDRSx1QkFBQSxDQUtOLDJCQUVFLHVCQUFBLENBREEsd0JBQ0EsQ0FHRiwyQkFDRSxnQkFBQSxDQUNBLHFCQUFBLENBR0YsNEJBR0UsdUJBQUEsQ0FGQSx3QkFBQSxDQUNBLHlCQUFBLENBRUEsa0JBQUEsQ0FDQSx5QkFBQSxDQUNBLGdDQUFBLENBQ0EsNEJBQUEsQ0FHRiw2QkFHRSx1QkFBQSxDQUZBLHdCQUFBLENBQ0EseUJBQUEsQ0FFQSx3QkFBQSIsImZpbGUiOiJQcmVtaXVtU2VhcmNoLm1vZHVsZS5jc3MifQ== */", true);


/***/ }),

/***/ 2883:
/*!********************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/Common/Pagination.module.scss.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* tslint:disable */
__webpack_require__(/*! ./Pagination.module.css */ 746);
var styles = {
    paginationContainer: 'paginationContainer_0ede9947',
    pagination: 'pagination_0ede9947',
    pageItem: 'pageItem_0ede9947',
    pageLink: 'pageLink_0ede9947',
    activePage: 'activePage_0ede9947',
    disabledPage: 'disabledPage_0ede9947'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);
/* tslint:enable */ 


/***/ }),

/***/ 7129:
/*!*****************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/Common/PaginationComponent.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaginationComponent: () => (/* binding */ PaginationComponent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-paginate */ 3869);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_paginate__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lucide-react */ 1695);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lucide-react */ 7263);
/* harmony import */ var _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Pagination.module.scss */ 2883);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};




var PaginationComponent = function (_a) {
    var totalCount = _a.totalCount, pageSize = _a.pageSize, from = _a.from, onPageChange = _a.onPageChange;
    var pageCount = Math.ceil(totalCount / pageSize);
    var currentPage = Math.floor(from / pageSize);
    var handlePageClick = function (event) {
        onPageChange(event.selected * pageSize);
    };
    if (pageCount <= 1)
        return null;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].paginationContainer }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_paginate__WEBPACK_IMPORTED_MODULE_1___default()), { breakLabel: "...", nextLabel: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 16, strokeWidth: 2.5 }), onPageChange: handlePageClick, pageRangeDisplayed: 3, marginPagesDisplayed: 1, pageCount: pageCount, previousLabel: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 16, strokeWidth: 2.5 }), renderOnZeroPageCount: null, forcePage: currentPage, containerClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pagination, pageClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageItem, pageLinkClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageLink, previousClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageItem, previousLinkClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageLink, nextClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageItem, nextLinkClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageLink, breakClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageItem, breakLinkClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pageLink, activeClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].activePage, disabledClassName: _Pagination_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].disabledPage }) })));
};


/***/ }),

/***/ 1478:
/*!************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/Common/SkeletonLoader.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SkeletonLoader: () => (/* binding */ SkeletonLoader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};


var SkeletonLoader = function (_a) {
    var _b = _a.count, count = _b === void 0 ? 4 : _b;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ style: { display: 'flex', flexDirection: 'column', gap: '16px', width: '100%', padding: '4px' } }, { children: Array.from({ length: count }).map(function (_, i) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].resultCard, style: { opacity: 0.6, pointerEvents: 'none', borderLeftColor: '#cbd5e1' } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardLeftBlock }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardIconBox, style: { backgroundColor: '#e2e8f0', width: '48px', height: '48px' } }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardBody, style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '4px 0' } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { style: { height: '20px', width: '50%', backgroundColor: '#e2e8f0', borderRadius: '4px' } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { style: { height: '14px', width: '35%', backgroundColor: '#f1f5f9', borderRadius: '4px', marginTop: '4px' } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { style: { height: '14px', width: '90%', backgroundColor: '#f1f5f9', borderRadius: '4px', marginTop: '8px' } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { style: { height: '14px', width: '80%', backgroundColor: '#f1f5f9', borderRadius: '4px' } })] }))] }), i)); }) })));
};


/***/ }),

/***/ 6458:
/*!*************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/DetailPanel.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailPanel: () => (/* binding */ DetailPanel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lucide-react */ 7826);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lucide-react */ 298);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lucide-react */ 4365);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lucide-react */ 5220);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
/* harmony import */ var _utils_SearchHelpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils/SearchHelpers */ 1170);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};





var DetailPanel = function (_a) {
    var selectedFile = _a.selectedFile, searchQuery = _a.searchQuery;
    var _b = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(false), 2), imageError = _b[0], setImageError = _b[1];
    var _c = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(false), 2), isUrlPopupOpen = _c[0], setIsUrlPopupOpen = _c[1];
    var _d = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(false), 2), copied = _d[0], setCopied = _d[1];
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(function () {
        setImageError(false);
    }, [selectedFile.id]);
    var getActionUrl = function (url, forceDownload) {
        if (!url)
            return '';
        try {
            var isSharePoint = url.includes('.sharepoint.com') || url.includes('/sites/') || url.includes('sharepoint.intel');
            if (isSharePoint) {
                var finalUrl = url;
                if (forceDownload) {
                    // Append SharePoint direct stream download parameter
                    if (finalUrl.includes('download=')) {
                        finalUrl = finalUrl.replace(/download=\d/, 'download=1');
                    }
                    else {
                        var separator = finalUrl.includes('?') ? '&' : '?';
                        finalUrl = "".concat(finalUrl).concat(separator, "download=1");
                    }
                    // Set web=0 to bypass opening in the online editor
                    if (finalUrl.includes('web=')) {
                        finalUrl = finalUrl.replace(/web=\d/, 'web=0');
                    }
                    else {
                        finalUrl = "".concat(finalUrl, "&web=0");
                    }
                }
                else {
                    // Full preview - open in online reader
                    if (finalUrl.includes('web=')) {
                        finalUrl = finalUrl.replace(/web=\d/, 'web=1');
                    }
                    else {
                        var separator = finalUrl.includes('?') ? '&' : '?';
                        finalUrl = "".concat(finalUrl).concat(separator, "web=1");
                    }
                }
                return finalUrl;
            }
        }
        catch (e) {
            // fallback
        }
        return url;
    };
    var isRealSharePoint = selectedFile.url && (selectedFile.url.includes('.sharepoint.com') || selectedFile.url.includes('/sites/'));
    var getSharePointPreviewUrl = function (url, title) {
        return (0,_utils_SearchHelpers__WEBPACK_IMPORTED_MODULE_3__.getSharePointThumbnailUrl)(url, title, 3);
    };
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].previewContentScroll }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].previewDocVisualCard }, { children: isRealSharePoint && !imageError ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", { src: getSharePointPreviewUrl(selectedFile.url, selectedFile.title), className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].previewImage, onError: function () { return setImageError(true); }, alt: selectedFile.title })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailWrapper, style: { borderTop: "4px solid ".concat(selectedFile.color) } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailHeader }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailIcon, style: { backgroundColor: selectedFile.color + '15', color: selectedFile.color } }, { children: selectedFile.type === 'FOLDER' ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 20 }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], { size: 20 }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailBadge, style: { backgroundColor: selectedFile.color + '20', color: selectedFile.color } }, { children: selectedFile.type }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailBody }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailTitle }, { children: selectedFile.title })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailTextLine, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].skeleton_w90) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailTextLine, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].skeleton_w80) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailTextLine, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].skeleton_w95) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailTextLine, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].skeleton_w60) })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailFooter }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailMeta }, { children: ["BY: ", selectedFile.author] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mockThumbnailMeta }, { children: selectedFile.size }))] }))] }))) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].visualIdentityHeader }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].visualTitle }, { children: selectedFile.title })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].visualSubRow }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].siteBadge, style: {
                                            backgroundColor: selectedFile.color + '10',
                                            color: selectedFile.color,
                                            cursor: 'pointer',
                                            display: 'inline-block',
                                            maxWidth: '100%'
                                        }, onClick: function () {
                                            setIsUrlPopupOpen(true);
                                            setCopied(false);
                                        }, title: "Click to view full URL" }, { children: selectedFile.url ? selectedFile.url : 'SHAREPOINT SITE' })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].metaDot }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].verifiedLabel }, { children: "Verified Source" }))] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoGrid }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoItem }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoLabel }, { children: "Format" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoValue }, { children: selectedFile.type }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoItem }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoLabel }, { children: "File Size" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoValue }, { children: selectedFile.size || '1.2 MB' }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoItem }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoLabel }, { children: "Last Sync" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoValue }, { children: selectedFile.date || 'Today' }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoItem }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoLabel }, { children: "Security" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bentoValue, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].statusSuccess) }, { children: "Encrypted" }))] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorCard }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorCardLeft }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorAvatar, style: { backgroundColor: selectedFile.color } }, { children: selectedFile.author ? selectedFile.author.charAt(0).toUpperCase() : 'U' })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].ownerTitle }, { children: "Document Owner" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].ownerName }, { children: selectedFile.author || 'SharePoint User' }))] })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorBadge }, { children: "Profile" }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].highlightsSection }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].highlightsHeader }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].highlightsTitle }, { children: "Content Highlight" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copySnippet, onClick: function () {
                                            navigator.clipboard.writeText(selectedFile.description || '');
                                        } }, { children: "Copy snippet" }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].highlightsContentWrapper }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].highlightsLineAccent, style: { backgroundColor: selectedFile.color + '40' } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].highlightsText }, { children: ["\"", (0,_utils_SearchHelpers__WEBPACK_IMPORTED_MODULE_3__.renderFormattedSummary)(selectedFile.description, searchQuery, selectedFile.color), "\""] }))] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionFooter }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionPrimaryBtn, style: { backgroundColor: selectedFile.color, boxShadow: "0 10px 20px -5px ".concat(selectedFile.color, "40") }, onClick: function () { return window.open(getActionUrl(selectedFile.url, false), '_blank'); } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_6__["default"], { size: 14 }), "Full Preview"] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionSecondaryBtn, title: "Download Asset", onClick: function () {
                                    if (!selectedFile.url)
                                        return;
                                    var downloadUrl = getActionUrl(selectedFile.url, true);
                                    var link = document.createElement('a');
                                    link.href = downloadUrl;
                                    link.setAttribute('download', selectedFile.title || 'download');
                                    link.setAttribute('target', '_self');
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
                                } }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_7__["default"], { size: 18 }) }))] }))] }), isUrlPopupOpen && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ style: {
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(15, 23, 42, 0.6)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 99999,
                    backdropFilter: 'blur(4px)'
                }, onClick: function () { return setIsUrlPopupOpen(false); } }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ style: {
                        backgroundColor: '#ffffff',
                        borderRadius: '16px',
                        padding: '24px',
                        maxWidth: '500px',
                        width: '90%',
                        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
                        border: '1px solid #e2e8f0',
                        fontFamily: 'Segoe UI, system-ui, sans-serif'
                    }, onClick: function (e) { return e.stopPropagation(); } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", __assign({ style: { margin: 0, fontSize: '16px', fontWeight: 700, color: '#0f172a' } }, { children: "Full Document URL" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setIsUrlPopupOpen(false); }, style: {
                                        background: 'none',
                                        border: 'none',
                                        fontSize: '18px',
                                        cursor: 'pointer',
                                        color: '#64748b',
                                        padding: '4px'
                                    } }, { children: "\u2715" }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ style: {
                                backgroundColor: '#f8fafc',
                                border: '1px solid #e2e8f0',
                                borderRadius: '8px',
                                padding: '12px 16px',
                                wordBreak: 'break-all',
                                fontSize: '13px',
                                color: '#334155',
                                lineHeight: 1.5,
                                maxHeight: '200px',
                                overflowY: 'auto',
                                marginBottom: '20px',
                                fontFamily: 'Consolas, Monaco, monospace'
                            } }, { children: selectedFile.url })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ style: { display: 'flex', justifyContent: 'flex-end', gap: '8px' } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return __awaiter(void 0, void 0, void 0, function () {
                                        var e_1;
                                        return __generator(this, function (_a) {
                                            switch (_a.label) {
                                                case 0:
                                                    _a.trys.push([0, 2, , 3]);
                                                    return [4 /*yield*/, navigator.clipboard.writeText(selectedFile.url)];
                                                case 1:
                                                    _a.sent();
                                                    setCopied(true);
                                                    setTimeout(function () { return setCopied(false); }, 2000);
                                                    return [3 /*break*/, 3];
                                                case 2:
                                                    e_1 = _a.sent();
                                                    console.error(e_1);
                                                    return [3 /*break*/, 3];
                                                case 3: return [2 /*return*/];
                                            }
                                        });
                                    }); }, style: {
                                        backgroundColor: copied ? '#10b981' : selectedFile.color,
                                        color: '#ffffff',
                                        border: 'none',
                                        borderRadius: '8px',
                                        padding: '8px 16px',
                                        fontSize: '13px',
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'background-color 0.2s ease'
                                    } }, { children: copied ? 'Copied!' : 'Copy Link' })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setIsUrlPopupOpen(false); }, style: {
                                        backgroundColor: '#f1f5f9',
                                        color: '#334155',
                                        border: 'none',
                                        borderRadius: '8px',
                                        padding: '8px 16px',
                                        fontSize: '13px',
                                        fontWeight: 600,
                                        cursor: 'pointer'
                                    } }, { children: "Close" }))] }))] })) })))] })));
};


/***/ }),

/***/ 8400:
/*!****************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/FileActionMenu.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileActionMenu: () => (/* binding */ FileActionMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lucide-react */ 4365);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lucide-react */ 4828);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lucide-react */ 5220);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lucide-react */ 6246);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lucide-react */ 7805);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lucide-react */ 8167);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};




var FileActionMenu = function (_a) {
    var file = _a.file, onOpenChange = _a.onOpenChange;
    var _b = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), isOpen = _b[0], setIsOpen = _b[1];
    var menuRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // Close menu when clicking outside
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        var handleClickOutside = function (event) {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setIsOpen(false);
                onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(false);
            }
        };
        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        }
        return function () {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpen, onOpenChange]);
    var toggleMenu = function (e) {
        e.stopPropagation(); // Prevent card selection when clicking menu
        var nextState = !isOpen;
        setIsOpen(nextState);
        onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(nextState);
    };
    // Helper: Parse directory location of the file in SharePoint
    var getFolderUrl = function (fileUrl) {
        if (!fileUrl)
            return '';
        try {
            var parts = fileUrl.split('/');
            parts.pop(); // Remove filename
            return parts.join('/');
        }
        catch (e) {
            return fileUrl;
        }
    };
    // Helper: Format SharePoint web URL to enforce browser viewing (web=1) or direct download (web=0)
    var getBrowserOpenUrl = function (url, forceDownload) {
        if (!url)
            return '';
        try {
            var isSharePoint = url.includes('.sharepoint.com') || url.includes('/sites/') || url.includes('sharepoint.intel');
            if (isSharePoint) {
                var finalUrl = url;
                if (forceDownload) {
                    // Append SharePoint direct stream download parameter
                    if (finalUrl.includes('download=')) {
                        finalUrl = finalUrl.replace(/download=\d/, 'download=1');
                    }
                    else {
                        var separator = finalUrl.includes('?') ? '&' : '?';
                        finalUrl = "".concat(finalUrl).concat(separator, "download=1");
                    }
                    // Set web=0 to bypass opening in the online editor
                    if (finalUrl.includes('web=')) {
                        finalUrl = finalUrl.replace(/web=\d/, 'web=0');
                    }
                    else {
                        finalUrl = "".concat(finalUrl, "&web=0");
                    }
                }
                else {
                    // Full preview - open in online reader
                    if (finalUrl.includes('web=')) {
                        finalUrl = finalUrl.replace(/web=\d/, 'web=1');
                    }
                    else {
                        var separator = finalUrl.includes('?') ? '&' : '?';
                        finalUrl = "".concat(finalUrl).concat(separator, "web=1");
                    }
                }
                return finalUrl;
            }
        }
        catch (e) {
            // fallback
        }
        return url;
    };
    // Helper: Determine application type
    var getAppName = function (fileType) {
        var type = (fileType || '').toLowerCase();
        if (['xls', 'xlsx'].includes(type))
            return { name: 'Excel', protocol: 'ms-excel:ofe|u|' };
        if (['doc', 'docx'].includes(type))
            return { name: 'Word', protocol: 'ms-word:ofe|u|' };
        if (['ppt', 'pptx'].includes(type))
            return { name: 'PowerPoint', protocol: 'ms-powerpoint:ofe|u|' };
        if (['pdf'].includes(type))
            return { name: 'Acrobat', protocol: 'pdf:' };
        return { name: 'App', protocol: 'ms-word:ofe|u|' };
    };
    var appInfo = getAppName(file.fileType || '');
    var menuItems = [
        {
            label: 'Open in browser',
            icon: lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"],
            onClick: function (e) {
                e.stopPropagation();
                window.open(getBrowserOpenUrl(file.webUrl, false), '_blank');
                setIsOpen(false);
                onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(false);
            }
        },
        {
            label: 'Open in app',
            icon: lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"],
            onClick: function (e) {
                e.stopPropagation();
                var launchUrl = "".concat(appInfo.protocol).concat(file.webUrl);
                window.open(launchUrl, '_blank');
                setIsOpen(false);
                onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(false);
            }
        },
        {
            label: 'Download',
            icon: lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"],
            onClick: function (e) {
                e.stopPropagation();
                if (!file.webUrl)
                    return;
                var downloadUrl = getBrowserOpenUrl(file.webUrl, true);
                var link = document.createElement('a');
                link.href = downloadUrl;
                link.setAttribute('download', file.title || 'download');
                link.setAttribute('target', '_self');
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                setIsOpen(false);
                onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(false);
            }
        },
        {
            label: 'Open file location',
            icon: lucide_react__WEBPACK_IMPORTED_MODULE_6__["default"],
            onClick: function (e) {
                e.stopPropagation();
                var folderUrl = getFolderUrl(file.webUrl);
                window.open(folderUrl || file.siteUrl || '#', '_blank');
                setIsOpen(false);
                onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(false);
            }
        },
        {
            label: 'Copy link',
            icon: lucide_react__WEBPACK_IMPORTED_MODULE_7__["default"],
            onClick: function (e) {
                e.stopPropagation();
                window.dispatchEvent(new CustomEvent('trivandi-copy-link', { detail: file }));
                setIsOpen(false);
                onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(false);
            }
        },
    ];
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionMenuWrapper, ref: menuRef }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ type: "button", onClick: toggleMenu, "aria-label": "More actions", "aria-expanded": isOpen, "aria-haspopup": "true", className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionTriggerBtn, " ").concat(isOpen ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionTriggerBtnActive : '') }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_8__["default"], { size: 18, strokeWidth: 2.5 }) })), isOpen && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionDropdownList }, { children: menuItems.map(function (item, index) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: item.onClick, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionDropdownItem }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(item.icon, { size: 16, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionItemIcon, strokeWidth: 2 }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionItemText }, { children: item.label }))] }), index)); }) })))] })));
};


/***/ }),

/***/ 9474:
/*!********************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/Header.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Header: () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lucide-react */ 9843);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lucide-react */ 2035);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};



var Header = function (_a) {
    var searchQuery = _a.searchQuery, setSearchQuery = _a.setSearchQuery, handleSearch = _a.handleSearch, isSearchFocused = _a.isSearchFocused, setIsSearchFocused = _a.setIsSearchFocused, searchHistory = _a.searchHistory, totalCountToRender = _a.totalCountToRender, onDismiss = _a.onDismiss;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].header }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].logoWrapper }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", { src: __webpack_require__(/*! ../Assets/moreyeahLogo.png */ 3126), alt: "Moreyeahs Logo", className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].logoImage }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].searchBarContainer }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].searchBarWrapper }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].searchIcon }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_2__["default"], { size: 18, strokeWidth: 2.5 }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "text", placeholder: "Search documents, pages, files...", value: searchQuery, onFocus: function () { return setIsSearchFocused(true); }, onBlur: function () { return setTimeout(function () { return setIsSearchFocused(false); }, 200); }, onChange: function (e) { return setSearchQuery(e.target.value); }, onKeyDown: function (e) { return e.key === 'Enter' && handleSearch(searchQuery); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].searchInput }), searchQuery && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () {
                                setSearchQuery('');
                                handleSearch('');
                            }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].searchClearBtn, title: "Clear search", "aria-label": "Clear search" }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 14, strokeWidth: 2.5 }) }))), isSearchFocused && searchHistory.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].searchSuggestionBox }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].suggestionHeader }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "Recent Searches" }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { children: searchHistory === null || searchHistory === void 0 ? void 0 : searchHistory.slice(0, 5).map(function (historyItem, idx) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: function () { return handleSearch(historyItem); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].suggestionItem }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_2__["default"], { size: 14, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].suggestionIcon }), historyItem] }), idx)); }) })] })))] })) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].headerMeta }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].metaTextContainer }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].metaResultsCount }, { children: [totalCountToRender.toLocaleString(), " results"] })) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].metaDivider }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].closeBtn, onClick: onDismiss, "aria-label": "Close search" }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 20 }) }))] }))] })));
};


/***/ }),

/***/ 702:
/*!*************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/HistoryPane.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HistoryPane: () => (/* binding */ HistoryPane)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lucide-react */ 1461);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lucide-react */ 2035);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lucide-react */ 9843);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};



var HistoryPane = function (_a) {
    var isHistoryOpen = _a.isHistoryOpen, setIsHistoryOpen = _a.setIsHistoryOpen, previewWidth = _a.previewWidth, searchHistory = _a.searchHistory, handleSearch = _a.handleSearch, setSearchHistory = _a.setSearchHistory, removeHistoryItem = _a.removeHistoryItem, isResizingPreview = _a.isResizingPreview, startResizingPreview = _a.startResizingPreview, topQueries = _a.topQueries, topClickedDocs = _a.topClickedDocs, onClearAnalytics = _a.onClearAnalytics;
    if (!isHistoryOpen)
        return null;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { onMouseDown: startResizingPreview, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].resizeHandle, " ").concat(isResizingPreview ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].resizeHandleActive : '') }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyPane, style: { width: previewWidth } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyHeader }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyTitleBox }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_2__["default"], { size: 18, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyHeaderIcon, strokeWidth: 2 }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyTitleLabel }, { children: ["Search History (", searchHistory.length, ")"] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setIsHistoryOpen(false); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyCloseBtn }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 20 }) }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyScrollContent }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historySectionHeader }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "RECENT SEARCH HISTORY" }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyListGroup }, { children: searchHistory.length > 0 ? (searchHistory.slice(0, 8).map(function (item, idx) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyItemCard }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: function () {
                                                handleSearch(item);
                                                setIsHistoryOpen(false);
                                            }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyItemTrigger }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyItemIconBox }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 14, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].suggestionIcon }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyItemInfo }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyItemQueryText }, { children: item })) }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function (e) {
                                                e.stopPropagation();
                                                removeHistoryItem(item);
                                            }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyItemRemoveBtn, title: "Remove history item" }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 14 }) }))] }), idx)); })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyEmptyState }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyEmptyIconFrame }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_2__["default"], { size: 24, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyEmptyIcon }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyEmptyTitle }, { children: "No Recent Searches" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyEmptyDesc }, { children: "Your search terms will be archived here for instant retrieval." }))] }))) })), topQueries && topQueries.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsWrapper }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historySectionHeader }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "YOUR TOP SEARCH QUERIES" }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsQueriesList }, { children: topQueries.map(function (item, idx) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: function () {
                                                handleSearch(item.query);
                                                setIsHistoryOpen(false);
                                            }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsQueryRow, title: "Search for ".concat(item.query, " again") }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsQueryText }, { children: item.query })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsCountBadge }, { children: [item.count, " ", item.count === 1 ? 'search' : 'searches'] }))] }), idx)); }) }))] }))), topClickedDocs && topClickedDocs.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsWrapper }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historySectionHeader }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "FREQUENTLY VISITED DOCUMENTS" }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsDocsList }, { children: topClickedDocs.map(function (doc, idx) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", __assign({ href: doc.url, target: "_blank", rel: "noopener noreferrer", className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsDocRow, title: "Open ".concat(doc.title, " in a new tab") }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsDocIcon }, { children: "\uD83D\uDCC4" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsDocInfo }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsDocTitle }, { children: doc.title })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].analyticsDocClicks }, { children: [doc.clickCount, " ", doc.clickCount === 1 ? 'view' : 'views'] }))] }))] }), idx)); }) }))] })))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].historyFooter }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () {
                                setSearchHistory([]);
                                if (onClearAnalytics)
                                    onClearAnalytics();
                            }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].clearHistoryButton }, { children: "Reset Analytics & History" })) }))] }))] }));
};


/***/ }),

/***/ 9062:
/*!*************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/PreviewPane.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PreviewPane: () => (/* binding */ PreviewPane)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lucide-react */ 9054);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lucide-react */ 298);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lucide-react */ 2035);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
/* harmony import */ var _DetailPanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DetailPanel */ 6458);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};




var PreviewPane = function (_a) {
    var selectedFile = _a.selectedFile, setSelectedFile = _a.setSelectedFile, previewWidth = _a.previewWidth, searchQuery = _a.searchQuery, isResizingPreview = _a.isResizingPreview, startResizingPreview = _a.startResizingPreview;
    if (!selectedFile)
        return null;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewPane, style: { width: previewWidth } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ onMouseDown: startResizingPreview, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].resizeHandle, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewResizeHandle, " ").concat(isResizingPreview ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].resizeHandleActive : '') }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].resizeGrip }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 12, strokeWidth: 2.5 }) })) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewHeader }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewHeaderContainer }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewHeaderIconBox, style: {
                                    color: selectedFile.color,
                                    backgroundColor: selectedFile.color + '15'
                                } }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 20 }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewHeaderTitle }, { children: "Document Preview" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewHeaderSubtitle }, { children: "Deep Analysis Mode" }))] })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setSelectedFile(null); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].previewCloseBtn, title: "Close preview", "aria-label": "Close preview" }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], { size: 18 }) }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_DetailPanel__WEBPACK_IMPORTED_MODULE_2__.DetailPanel, { selectedFile: selectedFile, searchQuery: searchQuery })] })));
};


/***/ }),

/***/ 9941:
/*!*************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/SearchModal.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SearchModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
/* harmony import */ var _services_GraphSearchService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/GraphSearchService */ 3618);
/* harmony import */ var _hooks_useSearch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hooks/useSearch */ 3242);
/* harmony import */ var use_debounce__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! use-debounce */ 8436);
/* harmony import */ var _store_useSearchStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../store/useSearchStore */ 6232);
/* harmony import */ var _services_PromotedResultsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/PromotedResultsService */ 4330);
/* harmony import */ var _services_SearchAnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/SearchAnalyticsService */ 8706);
/* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Sidebar */ 8750);
/* harmony import */ var _SearchTabs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./SearchTabs */ 6984);
/* harmony import */ var _PreviewPane__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./PreviewPane */ 9062);
/* harmony import */ var _HistoryPane__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./HistoryPane */ 702);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Header */ 9474);
/* harmony import */ var _SearchResultsList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./SearchResultsList */ 1314);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};







// Import services


// Import modular subcomponents






// File type design mapping helper
var getFileColor = function (fileType) {
    var ft = fileType ? fileType.toLowerCase() : '';
    if (ft === 'pdf')
        return { color: '#00acc1', bg: '#e0f7fa' };
    if (['xls', 'xlsx'].includes(ft))
        return { color: '#00796b', bg: '#e0f2f1' };
    if (['ppt', 'pptx'].includes(ft))
        return { color: '#e52592', bg: '#fce4ec' };
    if (['png', 'jpg', 'jpeg', 'gif', 'svg'].includes(ft))
        return { color: '#9334e6', bg: '#f3e5f5' };
    if (['mp4', 'mov', 'avi', 'wmv', 'mkv', 'flv', 'webm'].includes(ft))
        return { color: '#ea4335', bg: '#fce8e6' };
    if (ft === 'folder')
        return { color: '#f5b041', bg: '#fef5e7' };
    return { color: '#1a73e8', bg: '#e8f0fe' };
};
function SearchModal(_a) {
    var _this = this;
    var context = _a.context, isOpen = _a.isOpen, onDismiss = _a.onDismiss;
    if (!isOpen)
        return null;
    // --- Unified Column Widths & Resizing States ---
    var _b = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(240), 2), sidebarWidth = _b[0], setSidebarWidth = _b[1];
    var _c = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), isResizingSidebar = _c[0], setIsResizingSidebar = _c[1];
    var _d = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(380), 2), previewWidth = _d[0], setPreviewWidth = _d[1];
    var _e = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), isResizingPreview = _e[0], setIsResizingPreview = _e[1];
    // --- Search Query & Filter states ---
    var _f = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(''), 2), searchQuery = _f[0], setSearchQuery = _f[1];
    var _g = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), isSearchFocused = _g[0], setIsSearchFocused = _g[1];
    var _h = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        fileTypes: ['All'],
        selectedAuthors: [],
        date: ''
    }), 2), filters = _h[0], setFilters = _h[1];
    var _j = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('All'), 2), activeTopTab = _j[0], setActiveTopTab = _j[1];
    var _k = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('Search Results'), 2), bottomTab = _k[0], setBottomTab = _k[1];
    var _l = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null), 2), selectedFileId = _l[0], setSelectedFileId = _l[1];
    var _m = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), isHistoryOpen = _m[0], setIsHistoryOpen = _m[1];
    // --- Inline state replacing zustand store ---
    var _o = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(function () {
        try {
            var saved = sessionStorage.getItem('trivandi_recent_files_data');
            return saved ? JSON.parse(saved) : [];
        }
        catch (e) {
            return [];
        }
    }), 2), recentlyViewedFiles = _o[0], setRecentlyViewedFiles = _o[1];
    var _p = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(function () {
        try {
            var saved = localStorage.getItem('trivandi_starred_files_data');
            return saved ? JSON.parse(saved) : [];
        }
        catch (e) {
            return [];
        }
    }), 2), starredFiles = _p[0], setStarredFiles = _p[1];
    var _q = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(function () {
        try {
            var saved = localStorage.getItem('trivandi_starred_files_data');
            var arr = saved ? JSON.parse(saved) : [];
            return new Set(arr.map(function (f) { return f.id; }));
        }
        catch (e) {
            return new Set();
        }
    }), 2), starredIds = _q[0], setStarredIds = _q[1];
    var addRecentFile = function (file) {
        setRecentlyViewedFiles(function (prev) {
            var filtered = prev.filter(function (f) { return f.id !== file.id; });
            var updated = __spreadArray([file], __read(filtered), false);
            try {
                sessionStorage.setItem('trivandi_recent_files_data', JSON.stringify(updated));
            }
            catch (e) { /* ignored */ }
            return updated;
        });
    };
    var toggleStar = function (file) {
        setStarredIds(function (prev) {
            var hasStar = prev.has(file.id);
            var next = new Set(prev);
            if (hasStar) {
                next.delete(file.id);
            }
            else {
                next.add(file.id);
            }
            return next;
        });
        setStarredFiles(function (prev) {
            var hasStar = prev.some(function (f) { return f.id === file.id; });
            var next = hasStar ? prev.filter(function (f) { return f.id !== file.id; }) : __spreadArray(__spreadArray([], __read(prev), false), [__assign(__assign({}, file), { isStarred: true })], false);
            try {
                localStorage.setItem('trivandi_starred_files_data', JSON.stringify(next));
            }
            catch (e) { /* ignored */ }
            return next;
        });
        setRecentlyViewedFiles(function (prev) {
            return prev.map(function (f) { return f.id === file.id ? __assign(__assign({}, f), { isStarred: !starredIds.has(file.id) }) : f; });
        });
    };
    // Top-level modal states for loose-coupling Copy link sharing dialog
    var _r = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null), 2), copyFileDialogFile = _r[0], setCopyFileDialogFile = _r[1];
    var _s = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), appCopyCopied = _s[0], setAppCopyCopied = _s[1];
    // --- Zustand Store for Search History ---
    var _t = (0,_store_useSearchStore__WEBPACK_IMPORTED_MODULE_5__.useSearchStore)(), searchHistory = _t.searchHistory, addHistoryItem = _t.addHistoryItem, removeHistoryItem = _t.removeHistoryItem, clearHistory = _t.clearHistory;
    // --- Graph Service Setup ---
    var searchService = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        if (context && context.msGraphClientFactory) {
            return new _services_GraphSearchService__WEBPACK_IMPORTED_MODULE_3__.GraphSearchService(context.msGraphClientFactory);
        }
        return null;
    }, [context]);
    // Handle drag mousemove event
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        var handleMouseMove = function (e) {
            if (isResizingSidebar) {
                var newWidth = Math.max(180, Math.min(400, e.clientX));
                setSidebarWidth(newWidth);
            }
            if (isResizingPreview) {
                var newWidth = Math.max(280, Math.min(600, window.innerWidth - e.clientX));
                setPreviewWidth(newWidth);
            }
        };
        var handleMouseUp = function () {
            setIsResizingSidebar(false);
            setIsResizingPreview(false);
        };
        if (isResizingSidebar || isResizingPreview) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }
        return function () {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isResizingSidebar, isResizingPreview]);
    // --- Hook Execution for Live Data ---
    var _u = (0,_hooks_useSearch__WEBPACK_IMPORTED_MODULE_4__.useSearch)({
        service: searchService,
        initialQuery: '',
        pageSize: 10
    }), liveResults = _u.results, liveTotalCount = _u.totalCount, liveLoading = _u.loading, setQuery = _u.setQuery, setFileTypes = _u.setFileTypes, hookSetActiveTopTab = _u.setActiveTopTab, setDate = _u.setDate, hookSetSelectedAuthors = _u.setSelectedAuthors, from = _u.from, setFrom = _u.setFrom, sortBy = _u.sortBy, setSortBy = _u.setSortBy;
    // Debounce search query changes using standard 'use-debounce' React library
    var _v = __read((0,use_debounce__WEBPACK_IMPORTED_MODULE_14__.useDebounce)(searchQuery, 450), 1), debouncedSearchQuery = _v[0];
    // Track search query changes to synchronize hook with debounce
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        setQuery(debouncedSearchQuery);
    }, [debouncedSearchQuery, setQuery]);
    // Track fileTypes filter changes to synchronize hook
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        setFileTypes(filters.fileTypes);
    }, [filters.fileTypes, setFileTypes]);
    // Track activeTopTab changes to synchronize hook
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        hookSetActiveTopTab(activeTopTab);
    }, [activeTopTab, hookSetActiveTopTab]);
    // Track date filter changes to synchronize hook
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        setDate(filters.date);
    }, [filters.date, setDate]);
    // Track selectedAuthors changes to synchronize hook
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        hookSetSelectedAuthors(filters.selectedAuthors);
    }, [filters.selectedAuthors, hookSetSelectedAuthors]);
    // Helper to generate deterministic, realistic file sizes for visual excellence when size is missing
    var getDeterministicSize = function (id, fileType) {
        var ft = fileType ? fileType.toLowerCase() : '';
        if (ft === 'folder')
            return 0;
        // Simple deterministic hash from the unique file ID
        var hash = 0;
        for (var i = 0; i < id.length; i++) {
            hash = id.charCodeAt(i) + ((hash << 5) - hash);
        }
        hash = Math.abs(hash);
        // Generate a size between 120 KB and 9.4 MB
        var minBytes = 120 * 1024;
        var maxBytes = 9.4 * 1024 * 1024;
        return minBytes + (hash % (maxBytes - minBytes));
    };
    // Convert raw Graph Search results into our formatted UI result cards
    var mappedLiveResults = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        return liveResults.map(function (res) {
            var isStarred = starredIds.has(res.id);
            var cleanType = res.fileType || 'docx';
            return {
                id: res.id,
                title: res.title,
                author: res.author || 'SharePoint User',
                lastModified: res.lastModified || new Date().toISOString(),
                size: res.size || getDeterministicSize(res.id, cleanType),
                summary: res.summary || 'No description preview available.',
                webUrl: res.webUrl,
                fileType: cleanType,
                siteName: res.siteName || 'SharePoint Site',
                siteUrl: res.siteUrl || '',
                isStarred: isStarred
            };
        });
    }, [liveResults, starredIds]);
    // Listen to the custom copy-link event from any card's Action Menu to display the top-level overlay
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        var handleCopyEvent = function (e) {
            setCopyFileDialogFile(e.detail);
        };
        window.addEventListener('trivandi-copy-link', handleCopyEvent);
        return function () {
            window.removeEventListener('trivandi-copy-link', handleCopyEvent);
        };
    }, []);
    // Dynamic unique list of authors alphabetically sorted
    var authorsList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        var collected = new Set();
        // Live loaded search authors
        mappedLiveResults.forEach(function (r) {
            if (r.author && r.author.trim() !== 'SharePoint User' && r.author.trim() !== 'SharePoint Portal') {
                collected.add(r.author.trim());
            }
        });
        var uniqueNames = Array.from(collected);
        var alphabetic = uniqueNames.filter(function (name) { return /^[a-zA-Z]/.test(name.trim().charAt(0)); });
        var nonAlphabetic = uniqueNames.filter(function (name) { return !/^[a-zA-Z]/.test(name.trim().charAt(0)); });
        alphabetic.sort(function (a, b) { return a.localeCompare(b); });
        nonAlphabetic.sort(function (a, b) { return a.localeCompare(b); });
        return __spreadArray(__spreadArray([], __read(alphabetic), false), __read(nonAlphabetic), false);
    }, [mappedLiveResults]);
    // Robust live results are filtered on the server side natively, with client-side safeguards
    var filteredLiveResults = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        if (activeTopTab === 'Folders') {
            return mappedLiveResults.filter(function (r) { return r.fileType === 'folder'; });
        }
        if (activeTopTab === 'Files') {
            return mappedLiveResults.filter(function (r) { return r.fileType !== 'folder'; });
        }
        if (activeTopTab === 'Images') {
            return mappedLiveResults.filter(function (r) { var _a; return ['png', 'jpg', 'jpeg', 'gif', 'svg'].includes((_a = r.fileType) === null || _a === void 0 ? void 0 : _a.toLowerCase()); });
        }
        if (activeTopTab === 'Videos') {
            return mappedLiveResults.filter(function (r) { var _a; return ['mp4', 'mov', 'avi', 'wmv', 'mkv', 'flv', 'webm'].includes((_a = r.fileType) === null || _a === void 0 ? void 0 : _a.toLowerCase()); });
        }
        return mappedLiveResults;
    }, [mappedLiveResults, activeTopTab]);
    // Set the final target results and states based on current Mode (Live vs Mock)
    var resultsToRender = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        if (bottomTab === 'Recent Activities') {
            return recentlyViewedFiles.map(function (f) { return (__assign(__assign({}, f), { isStarred: starredIds.has(f.id) })); });
        }
        if (bottomTab === 'Starred Assets') {
            return starredFiles.map(function (f) { return (__assign(__assign({}, f), { isStarred: true })); });
        }
        return filteredLiveResults;
    }, [bottomTab, recentlyViewedFiles, starredFiles, filteredLiveResults, starredIds]);
    // Track selectedFileId change to push clicked files into recentlyViewedFiles via store action and register clicks in analytics
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
        if (selectedFileId) {
            var fileObj = resultsToRender.find(function (f) { return f.id === selectedFileId; });
            if (fileObj) {
                addRecentFile(fileObj);
                // Track the click in analytics
                _services_SearchAnalyticsService__WEBPACK_IMPORTED_MODULE_7__.SearchAnalyticsService.trackCardClick(fileObj.id, fileObj.title, fileObj.webUrl);
                setAnalyticsTrigger(function (prev) { return prev + 1; });
            }
        }
    }, [selectedFileId, resultsToRender, addRecentFile]);
    // Search Analytics state triggers and queries derivation
    var _w = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0), 2), analyticsTrigger = _w[0], setAnalyticsTrigger = _w[1];
    var topQueries = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        return _services_SearchAnalyticsService__WEBPACK_IMPORTED_MODULE_7__.SearchAnalyticsService.getTopQueries(5);
    }, [analyticsTrigger, searchQuery]);
    var topClickedDocs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        return _services_SearchAnalyticsService__WEBPACK_IMPORTED_MODULE_7__.SearchAnalyticsService.getTopClickedDocuments(5);
    }, [analyticsTrigger, selectedFileId]);
    var promotedResults = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        return _services_PromotedResultsService__WEBPACK_IMPORTED_MODULE_6__.PromotedResultsService.getPromotedResults(searchQuery);
    }, [searchQuery]);
    var totalCountToRender = bottomTab === 'Search Results'
        ? liveTotalCount
        : resultsToRender.length;
    var isLoading = liveLoading;
    // Selected File Object derivation
    var selectedFile = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        var _a;
        if (!selectedFileId)
            return null;
        var file = resultsToRender.find(function (f) { return f.id === selectedFileId; });
        if (!file)
            return null;
        var colors = getFileColor(file.fileType);
        // Format sizes cleanly supporting MB, KB, and Folder labels
        var sizeInMB = ((_a = file.fileType) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === 'folder'
            ? 'Folder'
            : (file.size ? (file.size >= 1024 * 1024
                ? "".concat((file.size / (1024 * 1024)).toFixed(1), " MB")
                : "".concat(Math.round(file.size / 1024), " KB"))
                : '---');
        return {
            id: file.id,
            title: file.title,
            author: file.author,
            date: file.lastModified ? new Date(file.lastModified).toLocaleDateString() : 'Today',
            size: sizeInMB,
            description: file.summary || 'No description extracted.',
            url: file.webUrl,
            type: file.fileType.toUpperCase(),
            starred: !!file.isStarred,
            color: colors.color,
            badgeColor: colors.color,
            summary: file.summary,
            siteName: file.siteName,
            siteUrl: file.siteUrl,
            webUrl: file.webUrl,
            lastModified: file.lastModified
        };
    }, [selectedFileId, resultsToRender]);
    // --- Drag Column trigger handlers ---
    var startResizingSidebar = function (e) {
        e.preventDefault();
        setIsResizingSidebar(true);
    };
    var startResizingPreview = function (e) {
        e.preventDefault();
        setIsResizingPreview(true);
    };
    // --- File Starring Handler ---
    var handleToggleStar = function (e, id) {
        e.stopPropagation();
        var fileObj = mappedLiveResults.find(function (f) { return f.id === id; }) || recentlyViewedFiles.find(function (f) { return f.id === id; }) || starredFiles.find(function (f) { return f.id === id; });
        if (fileObj) {
            toggleStar(fileObj);
        }
    };
    // --- Sidebar Type Filter checkbox handler ---
    var toggleFileType = function (type) {
        setFilters(function (prev) {
            if (type === 'All') {
                return __assign(__assign({}, prev), { fileTypes: ['All'] });
            }
            var updated = prev.fileTypes.filter(function (t) { return t !== 'All'; });
            if (updated.includes(type)) {
                updated = updated.filter(function (t) { return t !== type; });
            }
            else {
                updated.push(type);
            }
            if (updated.length === 0) {
                updated = ['All'];
            }
            return __assign(__assign({}, prev), { fileTypes: updated });
        });
    };
    // --- Execute search instantly and save query to searchHistory ---
    var handleSearch = function (query) {
        var trimmed = query.trim();
        if (trimmed) {
            addHistoryItem(trimmed);
            // Track the search query in analytics
            _services_SearchAnalyticsService__WEBPACK_IMPORTED_MODULE_7__.SearchAnalyticsService.trackSearchQuery(trimmed);
            setAnalyticsTrigger(function (prev) { return prev + 1; });
        }
        setSearchQuery(trimmed);
        setQuery(trimmed); // Trigger instantly!
        setIsHistoryOpen(false);
    };
    // --- Clear all applied filters ---
    var handleClearAllFilters = function () {
        setFilters({
            fileTypes: ['All'],
            selectedAuthors: [],
            date: ''
        });
        setActiveTopTab('All');
        setFrom(0);
    };
    var _x = __read((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null), 2), openMenuId = _x[0], setOpenMenuId = _x[1];
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].overlay }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].modal }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Header__WEBPACK_IMPORTED_MODULE_12__.Header, { searchQuery: searchQuery, setSearchQuery: setSearchQuery, handleSearch: handleSearch, isSearchFocused: isSearchFocused, setIsSearchFocused: setIsSearchFocused, searchHistory: searchHistory, totalCountToRender: totalCountToRender, onDismiss: onDismiss }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].body }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mainLayout }, { children: [bottomTab === 'Search Results' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Sidebar__WEBPACK_IMPORTED_MODULE_8__.Sidebar, { sidebarWidth: sidebarWidth, fileTypes: filters.fileTypes, selectedAuthors: filters.selectedAuthors, date: filters.date, setFilters: setFilters, toggleFileType: toggleFileType, startResizingSidebar: startResizingSidebar, isResizingSidebar: isResizingSidebar, authorsList: authorsList, searchService: searchService })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].centerContainer }, { children: [bottomTab === 'Search Results' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_SearchTabs__WEBPACK_IMPORTED_MODULE_9__.SearchTabs, { activeTab: activeTopTab, onTabChange: function (tab) {
                                                setActiveTopTab(tab);
                                                setFrom(0);
                                            }, onClearAll: handleClearAllFilters })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_SearchResultsList__WEBPACK_IMPORTED_MODULE_13__.SearchResultsList, { resultsToRender: resultsToRender, totalCountToRender: totalCountToRender, isLoading: isLoading, selectedFileId: selectedFileId, setSelectedFileId: setSelectedFileId, starredIds: starredIds, toggleStar: handleToggleStar, from: from, setFrom: setFrom, bottomTab: bottomTab, setBottomTab: setBottomTab, setIsHistoryOpen: setIsHistoryOpen, isHistoryOpen: isHistoryOpen, handleClearAllFilters: handleClearAllFilters, activeTopTab: activeTopTab, setActiveTopTab: setActiveTopTab, filters: filters, setFilters: setFilters, setOpenMenuId: setOpenMenuId, openMenuId: openMenuId, searchHistory: searchHistory, sortBy: sortBy, setSortBy: setSortBy, promotedResults: promotedResults })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_PreviewPane__WEBPACK_IMPORTED_MODULE_10__.PreviewPane, { selectedFile: selectedFile, setSelectedFile: function (file) { return setSelectedFileId(file ? file.id : null); }, previewWidth: previewWidth, searchQuery: searchQuery, isResizingPreview: isResizingPreview, startResizingPreview: startResizingPreview }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_HistoryPane__WEBPACK_IMPORTED_MODULE_11__.HistoryPane, { isHistoryOpen: isHistoryOpen, setIsHistoryOpen: setIsHistoryOpen, previewWidth: previewWidth, searchHistory: searchHistory, handleSearch: handleSearch, setSearchHistory: function () { return clearHistory(); }, removeHistoryItem: removeHistoryItem, isResizingPreview: isResizingPreview, startResizingPreview: startResizingPreview, topQueries: topQueries, topClickedDocs: topClickedDocs, onClearAnalytics: function () {
                                        _services_SearchAnalyticsService__WEBPACK_IMPORTED_MODULE_7__.SearchAnalyticsService.clearAnalytics();
                                        setAnalyticsTrigger(function (prev) { return prev + 1; });
                                    } })] })) }))] })), copyFileDialogFile && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogOverlay, onClick: function (e) {
                    e.stopPropagation();
                    setCopyFileDialogFile(null);
                } }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogContent, onClick: function (e) { return e.stopPropagation(); } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setCopyFileDialogFile(null); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogClose }, { children: "\u2715" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogHeader }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogCheckCircle }, { children: "\u2713" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogTitle }, { children: "Link created" }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogInputRow }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogUrlText }, { children: copyFileDialogFile.webUrl || "https://sharepoint.trivandi.com/Shared%20Documents/".concat(copyFileDialogFile.title) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return __awaiter(_this, void 0, void 0, function () {
                                        var url, err_1;
                                        return __generator(this, function (_a) {
                                            switch (_a.label) {
                                                case 0:
                                                    _a.trys.push([0, 2, , 3]);
                                                    url = copyFileDialogFile.webUrl || "https://sharepoint.trivandi.com/Shared%20Documents/".concat(copyFileDialogFile.title);
                                                    return [4 /*yield*/, navigator.clipboard.writeText(url)];
                                                case 1:
                                                    _a.sent();
                                                    setAppCopyCopied(true);
                                                    setTimeout(function () {
                                                        setAppCopyCopied(false);
                                                        setCopyFileDialogFile(null);
                                                    }, 1500);
                                                    return [3 /*break*/, 3];
                                                case 2:
                                                    err_1 = _a.sent();
                                                    console.error('Failed to copy', err_1);
                                                    return [3 /*break*/, 3];
                                                case 3: return [2 /*return*/];
                                            }
                                        });
                                    }); }, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogCopyButton, " ").concat(appCopyCopied ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogCopyButtonCopied : '') }, { children: appCopyCopied ? 'Copied!' : 'Copy' }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogFooter }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "People in your organization with the link can view" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].copyDialogSettingsLink }, { children: "\u2699 Settings" }))] }))] })) })))] })));
}


/***/ }),

/***/ 1314:
/*!*******************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/SearchResultsList.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchResultsList: () => (/* binding */ SearchResultsList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lucide-react */ 6329);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lucide-react */ 9119);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lucide-react */ 298);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lucide-react */ 3521);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lucide-react */ 2035);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lucide-react */ 1461);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lucide-react */ 5244);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lucide-react */ 7401);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
/* harmony import */ var _FileActionMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FileActionMenu */ 8400);
/* harmony import */ var _utils_SearchHelpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../utils/SearchHelpers */ 1170);
/* harmony import */ var _Common_SkeletonLoader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Common/SkeletonLoader */ 1478);
/* harmony import */ var _Common_PaginationComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Common/PaginationComponent */ 7129);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};








var SearchResultThumbnail = function (_a) {
    var _b;
    var result = _a.result;
    var _c = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(false), 2), imageError = _c[0], setImageError = _c[1];
    var isImage = ['png', 'jpg', 'jpeg', 'gif', 'svg'].includes(((_b = result.fileType) === null || _b === void 0 ? void 0 : _b.toLowerCase()) || '');
    if (isImage && !imageError) {
        var thumbUrl = (0,_utils_SearchHelpers__WEBPACK_IMPORTED_MODULE_4__.getSharePointThumbnailUrl)(result.webUrl, result.title);
        if (thumbUrl) {
            return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", { src: thumbUrl, alt: result.title, onError: function () { return setImageError(true); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardThumbnailImage }));
        }
    }
    // Fallback to standard icons
    var ft = result.fileType ? result.fileType.toLowerCase() : '';
    if (isImage) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_7__["default"], { size: 22, strokeWidth: 2 });
    }
    if (['xls', 'xlsx'].includes(ft)) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_8__["default"], { size: 22, strokeWidth: 2 });
    }
    if (['pdf'].includes(ft)) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_9__["default"], { size: 22, strokeWidth: 2 });
    }
    if (['doc', 'docx'].includes(ft)) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_9__["default"], { size: 22, strokeWidth: 2 });
    }
    if (['mp4', 'mov', 'avi', 'wmv', 'mkv', 'flv', 'webm'].includes(ft)) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_10__["default"], { size: 22, strokeWidth: 2 });
    }
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_9__["default"], { size: 22, strokeWidth: 2 });
};
var SearchResultsList = function (_a) {
    var resultsToRender = _a.resultsToRender, totalCountToRender = _a.totalCountToRender, isLoading = _a.isLoading, selectedFileId = _a.selectedFileId, setSelectedFileId = _a.setSelectedFileId, starredIds = _a.starredIds, toggleStar = _a.toggleStar, from = _a.from, setFrom = _a.setFrom, bottomTab = _a.bottomTab, setBottomTab = _a.setBottomTab, setIsHistoryOpen = _a.setIsHistoryOpen, isHistoryOpen = _a.isHistoryOpen, handleClearAllFilters = _a.handleClearAllFilters, activeTopTab = _a.activeTopTab, setActiveTopTab = _a.setActiveTopTab, filters = _a.filters, setFilters = _a.setFilters, setOpenMenuId = _a.setOpenMenuId, openMenuId = _a.openMenuId, searchHistory = _a.searchHistory, sortBy = _a.sortBy, setSortBy = _a.setSortBy, promotedResults = _a.promotedResults;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mainContainer }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].statsBar }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].statsLeft }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].statsLabel }, { children: ["Showing ", resultsToRender.length, " of ", totalCountToRender.toLocaleString(), " results"] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadgeWrapper }, { children: [activeTopTab !== 'All' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadge }, { children: ["Tab: ", activeTopTab, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setActiveTopTab('All'); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadgeClose }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_11__["default"], { size: 12 }) }))] }))), filters.fileTypes.length > 0 && !filters.fileTypes.includes('All') && (filters.fileTypes.map(function (type) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadge }, { children: ["Type: ", type, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () {
                                                    var updated = filters.fileTypes.filter(function (t) { return t !== type; });
                                                    setFilters(__assign(__assign({}, filters), { fileTypes: updated.length === 0 ? ['All'] : updated }));
                                                }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadgeClose }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_11__["default"], { size: 12 }) }))] }), type)); })), filters.date && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadge }, { children: ["Date: ", filters.date, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setFilters(__assign(__assign({}, filters), { date: '' })); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadgeClose }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_11__["default"], { size: 12 }) }))] }))), filters.selectedAuthors && filters.selectedAuthors.length > 0 && (filters.selectedAuthors.map(function (authorName) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadge }, { children: ["Author: ", authorName, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () {
                                                    setFilters(__assign(__assign({}, filters), { selectedAuthors: filters.selectedAuthors.filter(function (a) { return a !== authorName; }) }));
                                                }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].filterBadgeClose }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_11__["default"], { size: 12 }) }))] }), authorName)); }))] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].statsDivider }), bottomTab === 'Search Results' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sortContainer }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sortLabel }, { children: "SORT BY" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", __assign({ value: sortBy, onChange: function (e) { return setSortBy(e.target.value); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sortSelect, title: "Change search ranking criteria" }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", __assign({ value: "relevance" }, { children: "Relevance Tuning" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", __assign({ value: "dateDesc" }, { children: "Newest Modified" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", __assign({ value: "dateAsc" }, { children: "Oldest Modified" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", __assign({ value: "sizeDesc" }, { children: "Largest Assets" }))] }))] }))), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].statsDivider }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: function () {
                            setIsHistoryOpen(!isHistoryOpen);
                            setSelectedFileId(null);
                        }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].historyNavButton }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_12__["default"], { size: 12, strokeWidth: 2.5 }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { children: ["History (", (searchHistory === null || searchHistory === void 0 ? void 0 : searchHistory.length) || 0, ")"] })] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resultsListWrapper }, { children: [!isLoading && bottomTab === 'Search Results' && promotedResults && promotedResults.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedSection }, { children: promotedResults.map(function (promo) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", __assign({ href: promo.url, target: "_blank", rel: "noopener noreferrer", className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedCard }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedCrownBox }, { children: "\uD83D\uDC51" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedCardBody }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedTitleRow }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedCardTitle }, { children: promo.title })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedCategoryBadge }, { children: promo.category }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedCardDescription }, { children: promo.description })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].promotedUrlLabel }, { children: "Explore Official Portal \u2197" }))] }))] }), promo.id)); }) }))), isLoading ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Common_SkeletonLoader__WEBPACK_IMPORTED_MODULE_5__.SkeletonLoader, { count: 4 })) : resultsToRender.length === 0 ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].emptyState }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_13__["default"], { size: 40 }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", { children: "No results found" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { children: "Try broadening your terms or resetting filters." })] }))) : (resultsToRender.map(function (result, idx) {
                        var _a;
                        var isSelected = selectedFileId === result.id;
                        var isStarred = starredIds.has(result.id);
                        var formatBytes = function (bytes) {
                            if (!bytes)
                                return '---';
                            var k = 1024;
                            var sizes = ['Bytes', 'KB', 'MB', 'GB'];
                            var i = Math.floor(Math.log(bytes) / Math.log(k));
                            return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
                        };
                        var sizeLabel = result.fileType === 'folder'
                            ? 'Folder'
                            : (result.size ? formatBytes(result.size) : '---');
                        var dateLabel = result.lastModified ? new Date(result.lastModified).toLocaleDateString() : 'Today';
                        var isMenuOpen = openMenuId === result.id;
                        var ft = result.fileType ? result.fileType.toLowerCase() : '';
                        var typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_default;
                        var accentColor = '#1a73e8';
                        if (ft === 'pdf') {
                            typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_pdf;
                            accentColor = '#00acc1';
                        }
                        else if (['xls', 'xlsx'].includes(ft)) {
                            typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_xlsx;
                            accentColor = '#00796b';
                        }
                        else if (['ppt', 'pptx'].includes(ft)) {
                            typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_pptx;
                            accentColor = '#e52592';
                        }
                        else if (['png', 'jpg', 'jpeg', 'gif', 'svg'].includes(ft)) {
                            typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_image;
                            accentColor = '#9334e6';
                        }
                        else if (['mp4', 'mov', 'avi', 'wmv', 'mkv', 'flv', 'webm'].includes(ft)) {
                            typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_video;
                            accentColor = '#ea4335';
                        }
                        else if (ft === 'folder') {
                            typeClass = _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].type_folder;
                            accentColor = '#f5b041';
                        }
                        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resultCard, " ").concat(typeClass, " ").concat(isSelected ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resultCardSelected : '', " ").concat(isMenuOpen ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resultCardMenuOpen : ''), onClick: function () { return setSelectedFileId(isSelected ? null : result.id); } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].actionMenuAnchor }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_FileActionMenu__WEBPACK_IMPORTED_MODULE_3__.FileActionMenu, { file: result, onOpenChange: function (open) { return setOpenMenuId(open ? result.id : null); } }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardLeftBlock }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardIconBox, " ").concat(['png', 'jpg', 'jpeg', 'gif', 'svg'].includes((_a = result.fileType) === null || _a === void 0 ? void 0 : _a.toLowerCase()) ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardIconBoxImage : '') }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SearchResultThumbnail, { result: result }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function (e) { return toggleStar(e, result.id); }, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].starIconButton, " ").concat(isStarred ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].starIconButtonStarred : '') }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_14__["default"], { size: 16, fill: isStarred ? '#FBBF24' : 'transparent' }) }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardBody }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardHeaderRow }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitle, " ").concat(isSelected ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitleSelected : '') }, { children: result.title })) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardMetadataRow }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].metaBoldLabel }, { children: ["BY: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].metaValueDark }, { children: result.author }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].metaDot }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: dateLabel }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].metaDot }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: sizeLabel })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardDescription }, { children: (0,_utils_SearchHelpers__WEBPACK_IMPORTED_MODULE_4__.renderFormattedSummary)(result.summary, '', accentColor) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardProjectHubRow }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "PROJECT HUB: " }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].projectHubValue }, { children: result.siteName }))] }))] }))] }), result.id));
                    }))] })), !isLoading && resultsToRender.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].pagination }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].paginationInfo }, { children: ["PAGE ", Math.floor(from / 10) + 1, " ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].infoDivider }, { children: "|" })), " SHOWING ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].infoHighlight }, { children: [from + 1, "-", from + resultsToRender.length] })), " OF ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].infoHighlight }, { children: totalCountToRender }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Common_PaginationComponent__WEBPACK_IMPORTED_MODULE_6__.PaginationComponent, { totalCount: totalCountToRender, pageSize: 10, from: from, onPageChange: function (newFrom) {
                            setFrom(newFrom);
                        } })] }))), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("nav", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bottomTabNav }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bottomTabWrapper }, { children: ['Search Results', 'Recent Activities', 'Starred Assets'].map(function (tab) {
                        var isActive = bottomTab === tab;
                        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: function () {
                                setBottomTab(tab);
                                setIsHistoryOpen(false);
                            }, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bottomTabItem, " ").concat(isActive ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bottomTabActive : '') }, { children: [tab, isActive && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].bottomActiveLine }))] }), tab));
                    }) })) }))] })));
};


/***/ }),

/***/ 6984:
/*!************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/SearchTabs.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchTabs: () => (/* binding */ SearchTabs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};


var TABS = ['All', 'Folders', 'Files', 'Images', 'Videos'];
var SearchTabs = function (_a) {
    var activeTab = _a.activeTab, onTabChange = _a.onTabChange, onClearAll = _a.onClearAll;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topTabBar }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tabButtonsWrapper }, { children: TABS.map(function (tab) { return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", __assign({ onClick: function () { return onTabChange(tab); }, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topTabItem, " ").concat(activeTab === tab ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topTabItemActive : '') }, { children: [tab, activeTab === tab && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeTabLine }))] }), tab)); }) })), onClearAll && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: onClearAll, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].clearAllBtn }, { children: "Clear All" })))] })));
};


/***/ }),

/***/ 8750:
/*!*********************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/components/Sidebar.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sidebar: () => (/* binding */ Sidebar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lucide-react */ 8735);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lucide-react */ 3278);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lucide-react */ 9054);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/PremiumSearch.module.scss */ 545);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};




var FILE_TYPE_OPTIONS = ['All', 'PDF', 'DOC', 'XLS', 'PPT'];
var DATE_OPTIONS = ['Today', 'Yesterday', 'This Week', 'This Month', 'This Year'];
var Sidebar = function (_a) {
    var sidebarWidth = _a.sidebarWidth, fileTypes = _a.fileTypes, selectedAuthors = _a.selectedAuthors, date = _a.date, setFilters = _a.setFilters, toggleFileType = _a.toggleFileType, startResizingSidebar = _a.startResizingSidebar, isResizingSidebar = _a.isResizingSidebar, authorsList = _a.authorsList, searchService = _a.searchService;
    var _b = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(''), 2), authorSearchQuery = _b[0], setAuthorSearchQuery = _b[1];
    var _c = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(false), 2), isDropdownOpen = _c[0], setIsDropdownOpen = _c[1];
    var dropdownRef = react__WEBPACK_IMPORTED_MODULE_1__.useRef(null);
    var _d = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState([]), 2), apiAuthors = _d[0], setApiAuthors = _d[1];
    var _e = __read(react__WEBPACK_IMPORTED_MODULE_1__.useState(false), 2), isLoadingAuthors = _e[0], setIsLoadingAuthors = _e[1];
    // Fetch authors dynamically from Graph API with debounce
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(function () {
        if (!searchService) {
            setApiAuthors([]);
            return;
        }
        setIsLoadingAuthors(true);
        var delayDebounceFn = setTimeout(function () { return __awaiter(void 0, void 0, void 0, function () {
            var fetched, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, 3, 4]);
                        return [4 /*yield*/, searchService.getAuthors(authorSearchQuery)];
                    case 1:
                        fetched = _a.sent();
                        setApiAuthors(fetched);
                        return [3 /*break*/, 4];
                    case 2:
                        e_1 = _a.sent();
                        console.error('Error fetching authors from API:', e_1);
                        return [3 /*break*/, 4];
                    case 3:
                        setIsLoadingAuthors(false);
                        return [7 /*endfinally*/];
                    case 4: return [2 /*return*/];
                }
            });
        }); }, 350);
        return function () { return clearTimeout(delayDebounceFn); };
    }, [authorSearchQuery, searchService]);
    // Combine selected authors, API authors, and fallback authors
    var filteredAuthors = react__WEBPACK_IMPORTED_MODULE_1__.useMemo(function () {
        var set = new Set();
        // Always include currently selected authors so they don't disappear from the UI list
        selectedAuthors.forEach(function (a) { return set.add(a); });
        // Add API fetched authors
        apiAuthors.forEach(function (a) { return set.add(a); });
        // Fallback to offline authors if API isn't present or returned nothing
        if (apiAuthors.length === 0) {
            authorsList.forEach(function (a) {
                if (!authorSearchQuery || a.toLowerCase().includes(authorSearchQuery.toLowerCase())) {
                    set.add(a);
                }
            });
        }
        var uniqueNames = Array.from(set);
        var alphabetic = uniqueNames.filter(function (name) { return /^[a-zA-Z]/.test(name.trim().charAt(0)); });
        var nonAlphabetic = uniqueNames.filter(function (name) { return !/^[a-zA-Z]/.test(name.trim().charAt(0)); });
        alphabetic.sort(function (a, b) { return a.localeCompare(b); });
        nonAlphabetic.sort(function (a, b) { return a.localeCompare(b); });
        return __spreadArray(__spreadArray([], __read(alphabetic), false), __read(nonAlphabetic), false);
    }, [apiAuthors, selectedAuthors, authorsList, authorSearchQuery]);
    var toggleAuthor = function (name) {
        var updated = selectedAuthors.includes(name)
            ? selectedAuthors.filter(function (a) { return a !== name; })
            : __spreadArray(__spreadArray([], __read(selectedAuthors), false), [name], false);
        setFilters({ fileTypes: fileTypes, selectedAuthors: updated, date: date });
    };
    // Close dropdown when clicking outside
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(function () {
        var handleOutsideClick = function (e) {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setIsDropdownOpen(false);
            }
        };
        document.addEventListener('mousedown', handleOutsideClick);
        return function () {
            document.removeEventListener('mousedown', handleOutsideClick);
        };
    }, []);
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("aside", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebar, style: { width: sidebarWidth } }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarInner }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarTitle }, { children: "Filter by Type" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarOptionList }, { children: FILE_TYPE_OPTIONS.map(function (type) {
                                        var isActive = fileTypes.includes(type);
                                        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].checkboxLabel, " ").concat(isActive ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].checkboxActive : '') }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "checkbox", checked: isActive, onChange: function () { return toggleFileType(type); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].checkboxInput }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: type })] }), type));
                                    }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarSectionHeader, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownHeader) }, { children: ["Author ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].countLabel }, { children: ["(", selectedAuthors.length, " selected)"] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ ref: dropdownRef, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorInputWrapper, " ").concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownWrapper) }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownTrigger, onClick: function () { return setIsDropdownOpen(true); } }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"], { className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorIcon, size: 16 }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "text", placeholder: "Find an author...", value: authorSearchQuery, onFocus: function () { return setIsDropdownOpen(true); }, onChange: function (e) {
                                                        setAuthorSearchQuery(e.target.value);
                                                        setIsDropdownOpen(true);
                                                    }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorInput })] })), isDropdownOpen && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownMenu }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownScroll }, { children: [isLoadingAuthors && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownEmpty }, { children: "Searching authors..." }))), !isLoadingAuthors && filteredAuthors.map(function (name) {
                                                        var isChecked = selectedAuthors.includes(name);
                                                        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ onClick: function (e) {
                                                                e.stopPropagation();
                                                                toggleAuthor(name);
                                                            }, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorItemLabel, " ").concat(isChecked ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorItemLabelChecked : '') }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorItemAvatar, " ").concat(isChecked ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorItemAvatarChecked : '') }, { children: name.charAt(0).toUpperCase() })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorItemName, " ").concat(isChecked ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorItemNameChecked : '') }, { children: name }))] }), name));
                                                    }), !isLoadingAuthors && filteredAuthors.length === 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].authorDropdownEmpty }, { children: "No authors found" })))] })) })))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarSectionHeader }, { children: "Modified" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarOptionList }, { children: [DATE_OPTIONS.map(function (opt) {
                                            var isActive = date === opt;
                                            return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setFilters({ fileTypes: fileTypes, selectedAuthors: selectedAuthors, date: isActive ? '' : opt }); }, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].dateFilterButton, " ").concat(isActive ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].dateFilterActive : '') }, { children: opt }), opt));
                                        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].datePickerLabel }, { children: "Or pick a specific date" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].datePickerBox }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].datePickerIcon }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 18, strokeWidth: 2.5 }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "date", value: date && !DATE_OPTIONS.includes(date) ? date : '', onChange: function (e) { return setFilters({ fileTypes: fileTypes, selectedAuthors: selectedAuthors, date: e.target.value }); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].dateInput })] }))] }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sidebarActionWrapper }, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", __assign({ onClick: function () { return setFilters({ fileTypes: ['All'], selectedAuthors: [], date: '' }); }, className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].applyButton }, { children: "Reset All Filters" })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ style: { textAlign: 'center', fontSize: '9px', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginTop: '2px' } }, { children: "Filters Applied Instantly" }))] }))] })) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ onMouseDown: startResizingSidebar, className: "".concat(_styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resizeHandle, " ").concat(isResizingSidebar ? _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resizeHandleActive : '') }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", __assign({ className: _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].resizeGrip }, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], { size: 12, strokeWidth: 2.5 }) })) }))] }));
};


/***/ }),

/***/ 3242:
/*!******************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/hooks/useSearch.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useSearch: () => (/* binding */ useSearch)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};

function useSearch(_a) {
    var _this = this;
    var service = _a.service, _b = _a.initialQuery, initialQuery = _b === void 0 ? '' : _b, _c = _a.pageSize, pageSize = _c === void 0 ? 20 : _c;
    var _d = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialQuery), 2), query = _d[0], setQuery = _d[1];
    var _e = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['All']), 2), fileTypes = _e[0], setFileTypes = _e[1];
    var _f = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('All'), 2), activeTopTab = _f[0], setActiveTopTab = _f[1];
    var _g = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(''), 2), date = _g[0], setDate = _g[1];
    var _h = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), 2), selectedAuthors = _h[0], setSelectedAuthors = _h[1];
    var _j = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), 2), results = _j[0], setResults = _j[1];
    var _k = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0), 2), totalCount = _k[0], setTotalCount = _k[1];
    var _l = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), 2), loading = _l[0], setLoading = _l[1];
    var _m = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), 2), error = _m[0], setError = _m[1];
    var _o = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0), 2), from = _o[0], setFrom = _o[1];
    var _p = __read((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('relevance'), 2), sortBy = _p[0], setSortBy = _p[1];
    // Keep track of the latest active parameters to prevent asynchronous race conditions
    var activeParamsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)({ query: query, pageSize: pageSize, from: from, fileTypes: fileTypes, activeTopTab: activeTopTab, date: date, selectedAuthors: selectedAuthors, sortBy: sortBy });
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        activeParamsRef.current = { query: query, pageSize: pageSize, from: from, fileTypes: fileTypes, activeTopTab: activeTopTab, date: date, selectedAuthors: selectedAuthors, sortBy: sortBy };
    }, [query, pageSize, from, fileTypes, activeTopTab, date, selectedAuthors, sortBy]);
    var executeSearch = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function () { return __awaiter(_this, void 0, void 0, function () {
        var currentParams, res, latest, isStale, err_1, latest, isStale;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!service) {
                        setError('Search service is not initialized.');
                        return [2 /*return*/];
                    }
                    currentParams = { query: query, pageSize: pageSize, from: from, fileTypes: fileTypes, activeTopTab: activeTopTab, date: date, selectedAuthors: selectedAuthors, sortBy: sortBy };
                    console.log('--- [DEBUG hook] Triggering executeSearch in useSearch ---', currentParams);
                    setLoading(true);
                    setError(null);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, service.search(query, pageSize, from, fileTypes, activeTopTab, date, selectedAuthors, sortBy)];
                case 2:
                    res = _a.sent();
                    latest = activeParamsRef.current;
                    isStale = latest.query !== currentParams.query ||
                        latest.pageSize !== currentParams.pageSize ||
                        latest.from !== currentParams.from ||
                        latest.date !== currentParams.date ||
                        latest.sortBy !== currentParams.sortBy ||
                        latest.activeTopTab !== currentParams.activeTopTab ||
                        JSON.stringify(latest.selectedAuthors) !== JSON.stringify(currentParams.selectedAuthors) ||
                        JSON.stringify(latest.fileTypes) !== JSON.stringify(currentParams.fileTypes);
                    if (isStale) {
                        console.warn('--- [DEBUG hook] Stale search results discarded for query:', query);
                        return [2 /*return*/];
                    }
                    console.log('--- [DEBUG hook] Successful search response ---', {
                        resultsLength: res.results.length,
                        totalCount: res.totalCount
                    });
                    setResults(res.results);
                    setTotalCount(res.totalCount);
                    return [3 /*break*/, 5];
                case 3:
                    err_1 = _a.sent();
                    console.error('--- [DEBUG hook] Error executing Graph Search in hook ---', err_1);
                    if ((err_1 === null || err_1 === void 0 ? void 0 : err_1.statusCode) === 429 || ((err_1 === null || err_1 === void 0 ? void 0 : err_1.message) && err_1.message.includes('429'))) {
                        setError('Too many requests. Please wait a moment before searching again.');
                    }
                    else {
                        setError((err_1 === null || err_1 === void 0 ? void 0 : err_1.message) || 'Failed to fetch search results from Microsoft Graph API.');
                    }
                    return [3 /*break*/, 5];
                case 4:
                    latest = activeParamsRef.current;
                    isStale = latest.query !== currentParams.query ||
                        latest.pageSize !== currentParams.pageSize ||
                        latest.from !== currentParams.from ||
                        latest.date !== currentParams.date ||
                        latest.sortBy !== currentParams.sortBy ||
                        latest.activeTopTab !== currentParams.activeTopTab ||
                        JSON.stringify(latest.selectedAuthors) !== JSON.stringify(currentParams.selectedAuthors) ||
                        JSON.stringify(latest.fileTypes) !== JSON.stringify(currentParams.fileTypes);
                    if (!isStale) {
                        setLoading(false);
                    }
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); }, [service, query, pageSize, from, fileTypes, activeTopTab, date, selectedAuthors]);
    // Reset pagination offset to 0 whenever the query, activeTopTab, sortBy or filters change
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setFrom(0);
    }, [query, fileTypes, activeTopTab, date, selectedAuthors, sortBy]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        if (service) {
            executeSearch();
        }
    }, [executeSearch, service]);
    return {
        query: query,
        setQuery: setQuery,
        fileTypes: fileTypes,
        setFileTypes: setFileTypes,
        activeTopTab: activeTopTab,
        setActiveTopTab: setActiveTopTab,
        date: date,
        setDate: setDate,
        selectedAuthors: selectedAuthors,
        setSelectedAuthors: setSelectedAuthors,
        results: results,
        totalCount: totalCount,
        loading: loading,
        error: error,
        from: from,
        setFrom: setFrom,
        sortBy: sortBy,
        setSortBy: setSortBy,
        pageSize: pageSize,
        refresh: executeSearch
    };
}


/***/ }),

/***/ 3618:
/*!******************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/services/GraphSearchService.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GraphSearchService: () => (/* binding */ GraphSearchService)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var GraphSearchService = /** @class */ (function () {
    function GraphSearchService(msGraphClientFactory) {
        this._msGraphClientFactory = msGraphClientFactory;
    }
    GraphSearchService.prototype.search = function (query, pageSize, from, fileTypes, activeTopTab, date, selectedAuthors, sortBy) {
        var _a, _b;
        if (pageSize === void 0) { pageSize = 20; }
        if (from === void 0) { from = 0; }
        if (fileTypes === void 0) { fileTypes = []; }
        if (activeTopTab === void 0) { activeTopTab = 'All'; }
        if (date === void 0) { date = ''; }
        if (selectedAuthors === void 0) { selectedAuthors = []; }
        if (sortBy === void 0) { sortBy = 'relevance'; }
        return __awaiter(this, void 0, void 0, function () {
            var client, rawQuery, boostedQuery, queryString, imgFilter, vidFilter, actualTypes, typeQueries, now, formatKQLDate, dYesterday, dWeek, dMonth, dYear, formattedDate, authorQueries, searchPayload, sortField, desc, response, error_1, searchResponse, hitsContainer, totalCount, hits, results;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0: return [4 /*yield*/, this._msGraphClientFactory.getClient('3')];
                    case 1:
                        client = _c.sent();
                        rawQuery = query.trim();
                        boostedQuery = '';
                        if (rawQuery) {
                            if (rawQuery.includes(' ')) {
                                boostedQuery = "(".concat(rawQuery, " XRANK(cb=10000) Title:\"").concat(rawQuery, "*\")");
                            }
                            else {
                                boostedQuery = "(".concat(rawQuery, " XRANK(cb=10000) Title:").concat(rawQuery, "*)");
                            }
                        }
                        queryString = boostedQuery || 'IsDocument:1';
                        if (activeTopTab === 'Folders') {
                            queryString = boostedQuery ? "(".concat(boostedQuery, ") AND (IsContainer:true OR contentclass:STS_Folder)") : '(IsContainer:true OR contentclass:STS_Folder)';
                        }
                        else if (activeTopTab === 'Files') {
                            queryString = boostedQuery ? "(".concat(boostedQuery, ") AND IsContainer:false AND NOT contentclass:STS_Folder") : 'IsContainer:false AND NOT contentclass:STS_Folder';
                        }
                        else if (activeTopTab === 'Images') {
                            imgFilter = '(filetype:png OR filetype:jpg OR filetype:jpeg OR filetype:gif OR filetype:svg) AND IsContainer:false AND NOT contentclass:STS_Folder';
                            queryString = boostedQuery ? "(".concat(boostedQuery, ") AND (").concat(imgFilter, ")") : imgFilter;
                        }
                        else if (activeTopTab === 'Videos') {
                            vidFilter = '(filetype:mp4 OR filetype:mov OR filetype:avi) AND IsContainer:false AND NOT contentclass:STS_Folder';
                            queryString = boostedQuery ? "(".concat(boostedQuery, ") AND (").concat(vidFilter, ")") : vidFilter;
                        }
                        actualTypes = fileTypes.filter(function (t) { return t !== 'All'; });
                        if (actualTypes.length > 0 && activeTopTab !== 'Folders') {
                            typeQueries = actualTypes.map(function (t) { return "filetype:".concat(t.toLowerCase()); });
                            queryString += " AND (".concat(typeQueries.join(' OR '), ")");
                        }
                        // Add native SharePoint KQL date filters using standard KQL colon syntax
                        if (date) {
                            now = new Date();
                            formatKQLDate = function (d) {
                                return d.toISOString().split('T')[0];
                            };
                            if (date === 'Today') {
                                queryString += " AND LastModifiedTime:>=".concat(formatKQLDate(now));
                            }
                            else if (date === 'Yesterday') {
                                dYesterday = new Date(now);
                                dYesterday.setDate(dYesterday.getDate() - 1);
                                queryString += " AND LastModifiedTime:".concat(formatKQLDate(dYesterday));
                            }
                            else if (date === 'This Week') {
                                dWeek = new Date(now);
                                dWeek.setDate(dWeek.getDate() - 7);
                                queryString += " AND LastModifiedTime:>=".concat(formatKQLDate(dWeek));
                            }
                            else if (date === 'This Month') {
                                dMonth = new Date(now);
                                dMonth.setDate(dMonth.getDate() - 30);
                                queryString += " AND LastModifiedTime:>=".concat(formatKQLDate(dMonth));
                            }
                            else if (date === 'This Year') {
                                dYear = new Date(now);
                                dYear.setDate(dYear.getDate() - 365);
                                queryString += " AND LastModifiedTime:>=".concat(formatKQLDate(dYear));
                            }
                            else if (date.match(/^\d{4}-\d{2}-\d{2}$/)) {
                                queryString += " AND LastModifiedTime:".concat(date);
                            }
                            else {
                                try {
                                    formattedDate = new Date(date).toISOString().split('T')[0];
                                    queryString += " AND LastModifiedTime:".concat(formattedDate);
                                }
                                catch (e) {
                                    // ignore invalid date formats
                                }
                            }
                        }
                        // Add native SharePoint KQL author filters
                        if (selectedAuthors && selectedAuthors.length > 0) {
                            authorQueries = selectedAuthors.map(function (a) { return "(Author:\"".concat(a, "\" OR AuthorOWSUSER:\"").concat(a, "\")"); });
                            queryString += " AND (".concat(authorQueries.join(' OR '), ")");
                        }
                        searchPayload = {
                            requests: [
                                {
                                    entityTypes: ['driveItem'],
                                    query: {
                                        queryString: queryString
                                    },
                                    from: from,
                                    size: pageSize,
                                    fields: [
                                        'id',
                                        'name',
                                        'size',
                                        'webUrl',
                                        'lastModifiedDateTime',
                                        'createdBy',
                                        'parentReference',
                                        'file',
                                        'folder'
                                    ]
                                }
                            ]
                        };
                        if (sortBy && sortBy !== 'relevance') {
                            sortField = 'lastModifiedDateTime';
                            desc = true;
                            if (sortBy === 'dateAsc') {
                                desc = false;
                            }
                            else if (sortBy === 'sizeDesc') {
                                sortField = 'size';
                                desc = true;
                            }
                            searchPayload.requests[0].sortProperties = [
                                {
                                    name: sortField,
                                    isDescending: desc
                                }
                            ];
                        }
                        console.log('--- [DEBUG] Raw Search Query input ---', query);
                        console.log('--- [DEBUG] Active Top Tab ---', activeTopTab);
                        console.log('--- [DEBUG] File Type Filters ---', fileTypes);
                        console.log('--- [DEBUG] Date Filter ---', date);
                        console.log('--- [DEBUG] Final Constructed KQL QueryString ---', queryString);
                        console.log('--- [DEBUG] Full MS Graph Search Request Payload ---');
                        console.log(JSON.stringify(searchPayload, null, 2));
                        _c.label = 2;
                    case 2:
                        _c.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, client
                                .api('/search/query')
                                .version('v1.0')
                                .post(searchPayload)];
                    case 3:
                        response = _c.sent();
                        console.log('--- [DEBUG] Raw MS Graph Search Response ---');
                        console.log(JSON.stringify(response, null, 2));
                        return [3 /*break*/, 5];
                    case 4:
                        error_1 = _c.sent();
                        console.error('--- [DEBUG] Error in MS Graph API Call ---', error_1);
                        throw error_1;
                    case 5:
                        searchResponse = (_a = response.value) === null || _a === void 0 ? void 0 : _a[0];
                        hitsContainer = (_b = searchResponse === null || searchResponse === void 0 ? void 0 : searchResponse.hitsContainers) === null || _b === void 0 ? void 0 : _b[0];
                        totalCount = (hitsContainer === null || hitsContainer === void 0 ? void 0 : hitsContainer.total) || 0;
                        hits = (hitsContainer === null || hitsContainer === void 0 ? void 0 : hitsContainer.hits) || [];
                        console.log('--- [DEBUG] Parsed Hits Count from MS Graph ---', hits.length);
                        console.log('--- [DEBUG] Total Results Count from MS Graph Index ---', totalCount);
                        results = hits.map(function (hit) {
                            var _a, _b, _c, _d, _e, _f, _g, _h, _j;
                            var resource = hit.resource || {};
                            // Determine file extension cleanly
                            var fileType = 'doc';
                            var name = resource.name || '';
                            var rawUrl = resource.webUrl || '';
                            var hasExtension = name.includes('.') && ((_a = name.split('.').pop()) === null || _a === void 0 ? void 0 : _a.toLowerCase()) !== name.toLowerCase();
                            var ext = hasExtension ? (_b = name.split('.').pop()) === null || _b === void 0 ? void 0 : _b.toLowerCase() : '';
                            var isFolder = !!resource.folder ||
                                rawUrl.includes('/:f:/') ||
                                !hasExtension; // No extension means it is a folder
                            if (isFolder) {
                                fileType = 'folder';
                            }
                            else if (ext) {
                                if (ext === 'pdf')
                                    fileType = 'pdf';
                                else if (['xls', 'xlsx'].includes(ext))
                                    fileType = 'xlsx';
                                else if (['ppt', 'pptx'].includes(ext))
                                    fileType = 'pptx';
                                else if (['png', 'jpg', 'jpeg', 'gif', 'svg'].includes(ext))
                                    fileType = 'png';
                                else if (['mp4', 'mov', 'avi', 'wmv', 'mkv', 'flv', 'webm'].includes(ext))
                                    fileType = 'mp4';
                                else
                                    fileType = ext;
                            }
                            else if ((_c = resource.file) === null || _c === void 0 ? void 0 : _c.mimeType) {
                                var mime = resource.file.mimeType.toLowerCase();
                                if (mime.includes('pdf'))
                                    fileType = 'pdf';
                                else if (mime.includes('excel') || mime.includes('spreadsheet'))
                                    fileType = 'xlsx';
                                else if (mime.includes('presentation') || mime.includes('powerpoint'))
                                    fileType = 'pptx';
                                else if (mime.includes('image'))
                                    fileType = 'png';
                                else if (mime.includes('video'))
                                    fileType = 'mp4';
                            }
                            var getCleanSharePointUrl = function (webUrl, title) {
                                var _a;
                                if (!webUrl)
                                    return '';
                                try {
                                    var cleaned = webUrl;
                                    if (cleaned.includes('/Forms/DispForm.aspx')) {
                                        cleaned = cleaned.replace(/\/Forms\/DispForm\.aspx.*/i, "/".concat(title));
                                    }
                                    cleaned = cleaned.replace(/\/:[a-z]:\/[a-z]\//i, '/');
                                    cleaned = cleaned.replace(/\/:[a-z]:\/r\//i, '/');
                                    cleaned = cleaned.replace(/\/:[a-z]:\/g\//i, '/');
                                    cleaned = cleaned.split('?')[0]; // Strip query parameters
                                    // Force files to open in the browser instead of downloading by appending ?web=1
                                    var parts = title.split('.');
                                    if (parts.length > 1) {
                                        var ext_1 = (_a = parts.pop()) === null || _a === void 0 ? void 0 : _a.toLowerCase();
                                        if (ext_1 && ext_1 !== 'folder') {
                                            cleaned = "".concat(cleaned, "?web=1");
                                        }
                                    }
                                    return cleaned;
                                }
                                catch (e) {
                                    return webUrl;
                                }
                            };
                            return {
                                id: resource.id || hit.hitId || Math.random().toString(),
                                title: resource.name || 'Untitled Document',
                                webUrl: getCleanSharePointUrl(resource.webUrl || '', resource.name || ''),
                                fileType: fileType,
                                lastModified: resource.lastModifiedDateTime || new Date().toISOString(),
                                author: ((_e = (_d = resource.createdBy) === null || _d === void 0 ? void 0 : _d.user) === null || _e === void 0 ? void 0 : _e.displayName) || 'SharePoint User',
                                size: resource.size || 0,
                                summary: hit.summary || resource.description || 'No description preview available.',
                                siteUrl: ((_f = resource.parentReference) === null || _f === void 0 ? void 0 : _f.siteId) || '',
                                siteName: ((_j = (_h = (_g = resource.parentReference) === null || _g === void 0 ? void 0 : _g.sharepointIds) === null || _h === void 0 ? void 0 : _h.siteUrl) === null || _j === void 0 ? void 0 : _j.split('/').pop()) || 'SharePoint Portal'
                            };
                        });
                        console.log('--- [DEBUG] Mapped results array returning to caller ---');
                        console.log(JSON.stringify(results.map(function (r) { return ({ id: r.id, title: r.title, fileType: r.fileType }); }), null, 2));
                        return [2 /*return*/, { results: results, totalCount: totalCount }];
                }
            });
        });
    };
    GraphSearchService.prototype.sortAuthorsList = function (names) {
        var uniqueNames = Array.from(new Set(names));
        var alphabetic = uniqueNames.filter(function (name) { return /^[a-zA-Z]/.test(name.trim().charAt(0)); });
        var nonAlphabetic = uniqueNames.filter(function (name) { return !/^[a-zA-Z]/.test(name.trim().charAt(0)); });
        alphabetic.sort(function (a, b) { return a.localeCompare(b); });
        nonAlphabetic.sort(function (a, b) { return a.localeCompare(b); });
        return __spreadArray(__spreadArray([], __read(alphabetic), false), __read(nonAlphabetic), false);
    };
    GraphSearchService.prototype.getAuthors = function (query) {
        var _a, _b, _c, _d;
        if (query === void 0) { query = ''; }
        return __awaiter(this, void 0, void 0, function () {
            var client, url, cleanQuery, response, users, names, error_2, client, searchPayload, response, hits, names, e_1;
            return __generator(this, function (_e) {
                switch (_e.label) {
                    case 0:
                        _e.trys.push([0, 3, , 9]);
                        return [4 /*yield*/, this._msGraphClientFactory.getClient('3')];
                    case 1:
                        client = _e.sent();
                        url = '/users?$select=displayName&$top=999';
                        if (query.trim()) {
                            cleanQuery = query.trim().replace(/'/g, "''");
                            url += "&$filter=startsWith(displayName,'".concat(cleanQuery, "') or startsWith(givenName,'").concat(cleanQuery, "') or startsWith(surname,'").concat(cleanQuery, "')");
                        }
                        return [4 /*yield*/, client.api(url).version('v1.0').get()];
                    case 2:
                        response = _e.sent();
                        users = response.value || [];
                        names = users
                            .map(function (u) { return u.displayName; })
                            .filter(function (name) { return name && name.trim().length > 0; });
                        return [2 /*return*/, this.sortAuthorsList(names)];
                    case 3:
                        error_2 = _e.sent();
                        console.error('Error fetching authors from Graph:', error_2);
                        _e.label = 4;
                    case 4:
                        _e.trys.push([4, 7, , 8]);
                        return [4 /*yield*/, this._msGraphClientFactory.getClient('3')];
                    case 5:
                        client = _e.sent();
                        searchPayload = {
                            requests: [
                                {
                                    entityTypes: ['person'],
                                    query: {
                                        queryString: query.trim() ? "".concat(query.trim(), "*") : '*'
                                    },
                                    size: 500
                                }
                            ]
                        };
                        return [4 /*yield*/, client.api('/search/query').version('v1.0').post(searchPayload)];
                    case 6:
                        response = _e.sent();
                        hits = ((_d = (_c = (_b = (_a = response.value) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.hitsContainers) === null || _c === void 0 ? void 0 : _c[0]) === null || _d === void 0 ? void 0 : _d.hits) || [];
                        names = hits
                            .map(function (hit) { var _a; return (_a = hit.resource) === null || _a === void 0 ? void 0 : _a.displayName; })
                            .filter(function (name) { return name && name.trim().length > 0; });
                        return [2 /*return*/, this.sortAuthorsList(names)];
                    case 7:
                        e_1 = _e.sent();
                        console.error('Fallback author search failed:', e_1);
                        return [2 /*return*/, []];
                    case 8: return [3 /*break*/, 9];
                    case 9: return [2 /*return*/];
                }
            });
        });
    };
    return GraphSearchService;
}());



/***/ }),

/***/ 4330:
/*!**********************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/services/PromotedResultsService.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PromotedResultsService: () => (/* binding */ PromotedResultsService)
/* harmony export */ });
var PromotedResultsService = /** @class */ (function () {
    function PromotedResultsService() {
    }
    /**
     * Matches a search query against keyword arrays and returns matches
     */
    PromotedResultsService.getPromotedResults = function (query) {
        var clean = query.trim().toLowerCase();
        if (!clean)
            return [];
        return this.promotedList.filter(function (item) {
            return item.keywordMatches.some(function (keyword) {
                // Direct matching or checks if query contains the keyword
                return clean.includes(keyword) || keyword.includes(clean);
            });
        });
    };
    PromotedResultsService.promotedList = [
        {
            id: 'promo_hr_portal',
            keywordMatches: ['hr', 'policy', 'leave', 'vacation', 'hr policy', 'benefits', 'medical', 'insurance'],
            title: 'Trivandi Corporate HR Portal',
            description: 'Official corporate human resources gateway. Apply for leaves, view health benefits coverage, submit claims, and view global HR policies.',
            url: 'https://sharepoint.trivandi.com/sites/hr/SitePages/HR-Home.aspx',
            category: 'Human Resources',
            type: 'portal'
        },
        {
            id: 'promo_holiday_calendar',
            keywordMatches: ['holiday', 'calendar', 'holidays', 'leaves', 'off', 'offices', 'festivals', '2026'],
            title: 'Trivandi Global Holiday Calendar 2026',
            description: 'Corporate holiday calendar for all international Trivandi office locations. Plan your leaves and check regional off-days.',
            url: 'https://sharepoint.trivandi.com/sites/hr/Shared%20Documents/Trivandi-Holiday-Calendar-2026.pdf?web=1',
            category: 'Company Info',
            type: 'pdf'
        },
        {
            id: 'promo_brand_guidelines',
            keywordMatches: ['brand', 'logo', 'style', 'guide', 'styleguide', 'design', 'assets', 'powerpoint', 'templates'],
            title: 'Trivandi Brand Identity & Style Guidelines',
            description: 'Access official vector logos, standard typography packages, visual brand guidelines, and approved PowerPoint templates.',
            url: 'https://sharepoint.trivandi.com/sites/marketing/Assets/Brand-Identity-Guidelines.pdf?web=1',
            category: 'Marketing',
            type: 'styleguide'
        },
        {
            id: 'promo_partnership_agreements',
            keywordMatches: ['partnership', 'contract', 'agreement', 'partner', 'vendor', 'legal', 'collaboration'],
            title: 'Approved Partnership Agreement Templates',
            description: 'Legal-approved master templates for corporate partnership agreements, NDA agreements, and vendor contracts.',
            url: 'https://sharepoint.trivandi.com/sites/legal/Templates/Master-Partnership-Agreement-2026.docx?web=1',
            category: 'Legal',
            type: 'template'
        }
    ];
    return PromotedResultsService;
}());



/***/ }),

/***/ 8706:
/*!**********************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/services/SearchAnalyticsService.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchAnalyticsService: () => (/* binding */ SearchAnalyticsService)
/* harmony export */ });
var SearchAnalyticsService = /** @class */ (function () {
    function SearchAnalyticsService() {
    }
    /**
     * Tracks a successful search query by incrementing its count
     */
    SearchAnalyticsService.trackSearchQuery = function (query) {
        var clean = query.trim();
        if (!clean)
            return;
        try {
            var stored = localStorage.getItem(this.QUERIES_KEY);
            var list = stored ? JSON.parse(stored) : [];
            var existingIndex = list.findIndex(function (item) { return item.query.toLowerCase() === clean.toLowerCase(); });
            if (existingIndex !== -1) {
                list[existingIndex].count += 1;
                list[existingIndex].lastSearched = new Date().toISOString();
                // Keep correct casing if newer
                list[existingIndex].query = clean;
            }
            else {
                list.push({
                    query: clean,
                    count: 1,
                    lastSearched: new Date().toISOString()
                });
            }
            // Sort by count descending
            list.sort(function (a, b) { return b.count - a.count; });
            localStorage.setItem(this.QUERIES_KEY, JSON.stringify(list));
        }
        catch (e) {
            console.error('Failed to track search query in analytics:', e);
        }
    };
    /**
     * Tracks a clicked search result card
     */
    SearchAnalyticsService.trackCardClick = function (resultId, resultTitle, webUrl) {
        if (!resultId || !resultTitle)
            return;
        try {
            var stored = localStorage.getItem(this.CLICKS_KEY);
            var list = stored ? JSON.parse(stored) : [];
            var existingIndex = list.findIndex(function (item) { return item.id === resultId; });
            if (existingIndex !== -1) {
                list[existingIndex].clickCount += 1;
                list[existingIndex].lastClicked = new Date().toISOString();
            }
            else {
                list.push({
                    id: resultId,
                    title: resultTitle,
                    url: webUrl,
                    clickCount: 1,
                    lastClicked: new Date().toISOString()
                });
            }
            // Sort by clickCount descending
            list.sort(function (a, b) { return b.clickCount - a.clickCount; });
            localStorage.setItem(this.CLICKS_KEY, JSON.stringify(list));
        }
        catch (e) {
            console.error('Failed to track result card click in analytics:', e);
        }
    };
    /**
     * Gets top search queries sorted by count
     */
    SearchAnalyticsService.getTopQueries = function (limit) {
        if (limit === void 0) { limit = 5; }
        try {
            var stored = localStorage.getItem(this.QUERIES_KEY);
            var list = stored ? JSON.parse(stored) : [];
            return list.slice(0, limit);
        }
        catch (e) {
            return [];
        }
    };
    /**
     * Gets top clicked documents
     */
    SearchAnalyticsService.getTopClickedDocuments = function (limit) {
        if (limit === void 0) { limit = 5; }
        try {
            var stored = localStorage.getItem(this.CLICKS_KEY);
            var list = stored ? JSON.parse(stored) : [];
            return list.slice(0, limit);
        }
        catch (e) {
            return [];
        }
    };
    /**
     * Clears all search analytics databases
     */
    SearchAnalyticsService.clearAnalytics = function () {
        try {
            localStorage.removeItem(this.QUERIES_KEY);
            localStorage.removeItem(this.CLICKS_KEY);
        }
        catch (e) {
            console.error('Failed to clear analytics databases:', e);
        }
    };
    SearchAnalyticsService.QUERIES_KEY = 'trivandi_search_analytics_queries';
    SearchAnalyticsService.CLICKS_KEY = 'trivandi_search_analytics_clicks';
    return SearchAnalyticsService;
}());



/***/ }),

/***/ 6232:
/*!***********************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/store/useSearchStore.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useSearchStore: () => (/* binding */ useSearchStore)
/* harmony export */ });
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! zustand */ 3445);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! zustand/middleware */ 782);
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};


var useSearchStore = (0,zustand__WEBPACK_IMPORTED_MODULE_0__.create)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_1__.persist)(function (set) { return ({
    searchHistory: [],
    addHistoryItem: function (query) { return set(function (state) {
        var cleaned = query.trim();
        if (!cleaned)
            return state;
        var filtered = state.searchHistory.filter(function (item) { return item.toLowerCase() !== cleaned.toLowerCase(); });
        return { searchHistory: __spreadArray([cleaned], __read(filtered), false) }; // Keeps ALL history items indefinitely!
    }); },
    removeHistoryItem: function (query) { return set(function (state) { return ({
        searchHistory: state.searchHistory.filter(function (item) { return item !== query; })
    }); }); },
    clearHistory: function () { return set({ searchHistory: [] }); }
}); }, {
    name: 'trivandi_search_history_store_v2' // Incremented key to automatically clear stale browser cache!
}));


/***/ }),

/***/ 545:
/*!*************************************************!*\
  !*** ./lib/styles/PremiumSearch.module.scss.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* tslint:disable */
__webpack_require__(/*! ./PremiumSearch.module.css */ 7395);
var styles = {
    overlay: 'overlay_fffcc516',
    modal: 'modal_fffcc516',
    modalFadeIn: 'modalFadeIn_fffcc516',
    body: 'body_fffcc516',
    mainLayout: 'mainLayout_fffcc516',
    header: 'header_fffcc516',
    logoWrapper: 'logoWrapper_fffcc516',
    logoSvg: 'logoSvg_fffcc516',
    logoText: 'logoText_fffcc516',
    closeBtn: 'closeBtn_fffcc516',
    searchBarContainer: 'searchBarContainer_fffcc516',
    searchBarWrapper: 'searchBarWrapper_fffcc516',
    searchIcon: 'searchIcon_fffcc516',
    searchInput: 'searchInput_fffcc516',
    logoImage: 'logoImage_fffcc516',
    searchClearBtn: 'searchClearBtn_fffcc516',
    searchSuggestionBox: 'searchSuggestionBox_fffcc516',
    slideDownFade: 'slideDownFade_fffcc516',
    suggestionHeader: 'suggestionHeader_fffcc516',
    suggestionItem: 'suggestionItem_fffcc516',
    suggestionIcon: 'suggestionIcon_fffcc516',
    headerMeta: 'headerMeta_fffcc516',
    metaTextContainer: 'metaTextContainer_fffcc516',
    metaResultsCount: 'metaResultsCount_fffcc516',
    metaSubTitle: 'metaSubTitle_fffcc516',
    metaDivider: 'metaDivider_fffcc516',
    sidebar: 'sidebar_fffcc516',
    sidebarInner: 'sidebarInner_fffcc516',
    sidebarTitle: 'sidebarTitle_fffcc516',
    sidebarOptionList: 'sidebarOptionList_fffcc516',
    checkboxLabel: 'checkboxLabel_fffcc516',
    checkboxActive: 'checkboxActive_fffcc516',
    checkboxInput: 'checkboxInput_fffcc516',
    checkboxBadge: 'checkboxBadge_fffcc516',
    sidebarSectionHeader: 'sidebarSectionHeader_fffcc516',
    countLabel: 'countLabel_fffcc516',
    authorInputWrapper: 'authorInputWrapper_fffcc516',
    authorIcon: 'authorIcon_fffcc516',
    authorInput: 'authorInput_fffcc516',
    authorDropdown: 'authorDropdown_fffcc516',
    authorDropdownItem: 'authorDropdownItem_fffcc516',
    authorInitialsAvatar: 'authorInitialsAvatar_fffcc516',
    dateFilterButton: 'dateFilterButton_fffcc516',
    dateFilterActive: 'dateFilterActive_fffcc516',
    datePickerLabel: 'datePickerLabel_fffcc516',
    datePickerBox: 'datePickerBox_fffcc516',
    datePickerIcon: 'datePickerIcon_fffcc516',
    dateInput: 'dateInput_fffcc516',
    sidebarActionWrapper: 'sidebarActionWrapper_fffcc516',
    applyButton: 'applyButton_fffcc516',
    resetButton: 'resetButton_fffcc516',
    resizeHandle: 'resizeHandle_fffcc516',
    resizeGrip: 'resizeGrip_fffcc516',
    resizeHandleActive: 'resizeHandleActive_fffcc516',
    mainContainer: 'mainContainer_fffcc516',
    topTabBar: 'topTabBar_fffcc516',
    tabButtonsWrapper: 'tabButtonsWrapper_fffcc516',
    topTabItem: 'topTabItem_fffcc516',
    topTabItemActive: 'topTabItemActive_fffcc516',
    activeTabLine: 'activeTabLine_fffcc516',
    clearAllBtn: 'clearAllBtn_fffcc516',
    statsBar: 'statsBar_fffcc516',
    statsLeft: 'statsLeft_fffcc516',
    statsDivider: 'statsDivider_fffcc516',
    statsLabel: 'statsLabel_fffcc516',
    filterBadgeWrapper: 'filterBadgeWrapper_fffcc516',
    filterBadge: 'filterBadge_fffcc516',
    filterBadgeClose: 'filterBadgeClose_fffcc516',
    historyNavButton: 'historyNavButton_fffcc516',
    resultsListWrapper: 'resultsListWrapper_fffcc516',
    resultCard: 'resultCard_fffcc516',
    resultCardSelected: 'resultCardSelected_fffcc516',
    resultCardMenuOpen: 'resultCardMenuOpen_fffcc516',
    starIconButtonStarred: 'starIconButtonStarred_fffcc516',
    cardTitleSelected: 'cardTitleSelected_fffcc516',
    type_pdf: 'type_pdf_fffcc516',
    cardIconBox: 'cardIconBox_fffcc516',
    projectHubValue: 'projectHubValue_fffcc516',
    type_xlsx: 'type_xlsx_fffcc516',
    type_pptx: 'type_pptx_fffcc516',
    type_image: 'type_image_fffcc516',
    type_video: 'type_video_fffcc516',
    type_folder: 'type_folder_fffcc516',
    type_default: 'type_default_fffcc516',
    actionMenuAnchor: 'actionMenuAnchor_fffcc516',
    cardLeftBlock: 'cardLeftBlock_fffcc516',
    cardIconBoxImage: 'cardIconBoxImage_fffcc516',
    cardThumbnailImage: 'cardThumbnailImage_fffcc516',
    starIconButton: 'starIconButton_fffcc516',
    cardBody: 'cardBody_fffcc516',
    cardHeaderRow: 'cardHeaderRow_fffcc516',
    cardTitle: 'cardTitle_fffcc516',
    scoreContainer: 'scoreContainer_fffcc516',
    scoreRow: 'scoreRow_fffcc516',
    scoreBadge: 'scoreBadge_fffcc516',
    scoreBM25: 'scoreBM25_fffcc516',
    scoreTFIDF: 'scoreTFIDF_fffcc516',
    fileTypeBadge: 'fileTypeBadge_fffcc516',
    cardMetadataRow: 'cardMetadataRow_fffcc516',
    metaBoldLabel: 'metaBoldLabel_fffcc516',
    metaValueDark: 'metaValueDark_fffcc516',
    metaDot: 'metaDot_fffcc516',
    cardDescription: 'cardDescription_fffcc516',
    cardProjectHubRow: 'cardProjectHubRow_fffcc516',
    pagination: 'pagination_fffcc516',
    paginationInfo: 'paginationInfo_fffcc516',
    infoDivider: 'infoDivider_fffcc516',
    infoHighlight: 'infoHighlight_fffcc516',
    pageNumberControls: 'pageNumberControls_fffcc516',
    pageArrowBtn: 'pageArrowBtn_fffcc516',
    pageNumBtn: 'pageNumBtn_fffcc516',
    pageNumActive: 'pageNumActive_fffcc516',
    paginationEllipsis: 'paginationEllipsis_fffcc516',
    jumpToWrapper: 'jumpToWrapper_fffcc516',
    jumpToLabel: 'jumpToLabel_fffcc516',
    jumpToInput: 'jumpToInput_fffcc516',
    bottomTabNav: 'bottomTabNav_fffcc516',
    bottomTabWrapper: 'bottomTabWrapper_fffcc516',
    bottomTabItem: 'bottomTabItem_fffcc516',
    bottomTabActive: 'bottomTabActive_fffcc516',
    bottomActiveLine: 'bottomActiveLine_fffcc516',
    previewPane: 'previewPane_fffcc516',
    slideInRight: 'slideInRight_fffcc516',
    previewHeader: 'previewHeader_fffcc516',
    previewTitleLabel: 'previewTitleLabel_fffcc516',
    previewCloseBtn: 'previewCloseBtn_fffcc516',
    previewContentScroll: 'previewContentScroll_fffcc516',
    previewDocVisualCard: 'previewDocVisualCard_fffcc516',
    visualCardTop: 'visualCardTop_fffcc516',
    visualPulseLine1: 'visualPulseLine1_fffcc516',
    pulse: 'pulse_fffcc516',
    visualPulseLine2: 'visualPulseLine2_fffcc516',
    visualInnerFrame: 'visualInnerFrame_fffcc516',
    frameGripBackground: 'frameGripBackground_fffcc516',
    frameIcon: 'frameIcon_fffcc516',
    visualPulseList: 'visualPulseList_fffcc516',
    pulseRow: 'pulseRow_fffcc516',
    pulseRowMid: 'pulseRowMid_fffcc516',
    pulseRowShort: 'pulseRowShort_fffcc516',
    visualCardBottom: 'visualCardBottom_fffcc516',
    visualRestrictedLabel: 'visualRestrictedLabel_fffcc516',
    previewIframe: 'previewIframe_fffcc516',
    previewImage: 'previewImage_fffcc516',
    mockThumbnailWrapper: 'mockThumbnailWrapper_fffcc516',
    mockThumbnailHeader: 'mockThumbnailHeader_fffcc516',
    mockThumbnailIcon: 'mockThumbnailIcon_fffcc516',
    mockThumbnailBadge: 'mockThumbnailBadge_fffcc516',
    mockThumbnailBody: 'mockThumbnailBody_fffcc516',
    mockThumbnailTitle: 'mockThumbnailTitle_fffcc516',
    mockThumbnailTextLine: 'mockThumbnailTextLine_fffcc516',
    mockThumbnailFooter: 'mockThumbnailFooter_fffcc516',
    mockThumbnailMeta: 'mockThumbnailMeta_fffcc516',
    previewMetaGrid: 'previewMetaGrid_fffcc516',
    previewMetaItem: 'previewMetaItem_fffcc516',
    previewMetaLabel: 'previewMetaLabel_fffcc516',
    previewMetaValue: 'previewMetaValue_fffcc516',
    primaryAuthorCard: 'primaryAuthorCard_fffcc516',
    authorCardRow: 'authorCardRow_fffcc516',
    authorAvatarSphere: 'authorAvatarSphere_fffcc516',
    extractedSection: 'extractedSection_fffcc516',
    extractedContentBlock: 'extractedContentBlock_fffcc516',
    previewActionsWrapper: 'previewActionsWrapper_fffcc516',
    previewFullBtn: 'previewFullBtn_fffcc516',
    previewDownloadBtn: 'previewDownloadBtn_fffcc516',
    historyPane: 'historyPane_fffcc516',
    historyHeader: 'historyHeader_fffcc516',
    historyTitleBox: 'historyTitleBox_fffcc516',
    historyTitleLabel: 'historyTitleLabel_fffcc516',
    historyCloseBtn: 'historyCloseBtn_fffcc516',
    historyScrollContent: 'historyScrollContent_fffcc516',
    historyListGroup: 'historyListGroup_fffcc516',
    historyItemCard: 'historyItemCard_fffcc516',
    historyItemTrigger: 'historyItemTrigger_fffcc516',
    historyItemIconBox: 'historyItemIconBox_fffcc516',
    historyItemInfo: 'historyItemInfo_fffcc516',
    historyItemQueryText: 'historyItemQueryText_fffcc516',
    historyItemTimeLabel: 'historyItemTimeLabel_fffcc516',
    historyItemRemoveBtn: 'historyItemRemoveBtn_fffcc516',
    historyEmptyState: 'historyEmptyState_fffcc516',
    historyEmptyIconFrame: 'historyEmptyIconFrame_fffcc516',
    historyEmptyTitle: 'historyEmptyTitle_fffcc516',
    historyEmptyDesc: 'historyEmptyDesc_fffcc516',
    historyFooter: 'historyFooter_fffcc516',
    clearHistoryButton: 'clearHistoryButton_fffcc516',
    actionMenuWrapper: 'actionMenuWrapper_fffcc516',
    actionTriggerBtn: 'actionTriggerBtn_fffcc516',
    actionTriggerBtnActive: 'actionTriggerBtnActive_fffcc516',
    actionDropdownList: 'actionDropdownList_fffcc516',
    actionDropdownItem: 'actionDropdownItem_fffcc516',
    actionItemIcon: 'actionItemIcon_fffcc516',
    actionItemCopied: 'actionItemCopied_fffcc516',
    actionIconCopied: 'actionIconCopied_fffcc516',
    detailBackdrop: 'detailBackdrop_fffcc516',
    detailDrawer: 'detailDrawer_fffcc516',
    detailHeader: 'detailHeader_fffcc516',
    detailHeaderLeft: 'detailHeaderLeft_fffcc516',
    detailIconBox: 'detailIconBox_fffcc516',
    detailHeadingBox: 'detailHeadingBox_fffcc516',
    detailDocTitle: 'detailDocTitle_fffcc516',
    detailDocSub: 'detailDocSub_fffcc516',
    detailCloseBtn: 'detailCloseBtn_fffcc516',
    detailScrollContent: 'detailScrollContent_fffcc516',
    detailSection: 'detailSection_fffcc516',
    detailSectionHeader: 'detailSectionHeader_fffcc516',
    detailContentBlock: 'detailContentBlock_fffcc516',
    timelineGroup: 'timelineGroup_fffcc516',
    timelineItem: 'timelineItem_fffcc516',
    timelineLeft: 'timelineLeft_fffcc516',
    timelineNode: 'timelineNode_fffcc516',
    timelineLine: 'timelineLine_fffcc516',
    timelineRight: 'timelineRight_fffcc516',
    timelineDate: 'timelineDate_fffcc516',
    timelineAuthor: 'timelineAuthor_fffcc516',
    timelineAction: 'timelineAction_fffcc516',
    detailFooter: 'detailFooter_fffcc516',
    footerPrimaryBtn: 'footerPrimaryBtn_fffcc516',
    footerSecondaryBtn: 'footerSecondaryBtn_fffcc516',
    loadingRow: 'loadingRow_fffcc516',
    spinner: 'spinner_fffcc516',
    spin: 'spin_fffcc516',
    emptyState: 'emptyState_fffcc516',
    previewHeaderContainer: 'previewHeaderContainer_fffcc516',
    previewHeaderTitle: 'previewHeaderTitle_fffcc516',
    previewHeaderSubtitle: 'previewHeaderSubtitle_fffcc516',
    visualIdentityHeader: 'visualIdentityHeader_fffcc516',
    visualTitle: 'visualTitle_fffcc516',
    visualSubRow: 'visualSubRow_fffcc516',
    siteBadge: 'siteBadge_fffcc516',
    verifiedLabel: 'verifiedLabel_fffcc516',
    bentoGrid: 'bentoGrid_fffcc516',
    bentoItem: 'bentoItem_fffcc516',
    bentoLabel: 'bentoLabel_fffcc516',
    bentoValue: 'bentoValue_fffcc516',
    authorCard: 'authorCard_fffcc516',
    authorCardLeft: 'authorCardLeft_fffcc516',
    authorAvatar: 'authorAvatar_fffcc516',
    authorBadge: 'authorBadge_fffcc516',
    highlightsSection: 'highlightsSection_fffcc516',
    highlightsHeader: 'highlightsHeader_fffcc516',
    highlightsTitle: 'highlightsTitle_fffcc516',
    copySnippet: 'copySnippet_fffcc516',
    highlightsContentWrapper: 'highlightsContentWrapper_fffcc516',
    highlightsLineAccent: 'highlightsLineAccent_fffcc516',
    highlightsText: 'highlightsText_fffcc516',
    actionFooter: 'actionFooter_fffcc516',
    actionPrimaryBtn: 'actionPrimaryBtn_fffcc516',
    actionSecondaryBtn: 'actionSecondaryBtn_fffcc516',
    copyDialogOverlay: 'copyDialogOverlay_fffcc516',
    copyDialogContent: 'copyDialogContent_fffcc516',
    copyDialogClose: 'copyDialogClose_fffcc516',
    copyDialogHeader: 'copyDialogHeader_fffcc516',
    copyDialogCheckCircle: 'copyDialogCheckCircle_fffcc516',
    copyDialogTitle: 'copyDialogTitle_fffcc516',
    copyDialogInputRow: 'copyDialogInputRow_fffcc516',
    copyDialogUrlText: 'copyDialogUrlText_fffcc516',
    copyDialogCopyButton: 'copyDialogCopyButton_fffcc516',
    copyDialogCopyButtonCopied: 'copyDialogCopyButtonCopied_fffcc516',
    copyDialogFooter: 'copyDialogFooter_fffcc516',
    copyDialogSettingsLink: 'copyDialogSettingsLink_fffcc516',
    centerContainer: 'centerContainer_fffcc516',
    previewResizeHandle: 'previewResizeHandle_fffcc516',
    previewHeaderIconBox: 'previewHeaderIconBox_fffcc516',
    actionItemText: 'actionItemText_fffcc516',
    ownerTitle: 'ownerTitle_fffcc516',
    ownerName: 'ownerName_fffcc516',
    statusSuccess: 'statusSuccess_fffcc516',
    skeleton_w90: 'skeleton_w90_fffcc516',
    skeleton_w80: 'skeleton_w80_fffcc516',
    skeleton_w95: 'skeleton_w95_fffcc516',
    skeleton_w60: 'skeleton_w60_fffcc516',
    authorDropdownHeader: 'authorDropdownHeader_fffcc516',
    authorDropdownWrapper: 'authorDropdownWrapper_fffcc516',
    authorDropdownTrigger: 'authorDropdownTrigger_fffcc516',
    authorDropdownMenu: 'authorDropdownMenu_fffcc516',
    authorDropdownMenuHeader: 'authorDropdownMenuHeader_fffcc516',
    authorDropdownMenuTitle: 'authorDropdownMenuTitle_fffcc516',
    authorDropdownMenuDone: 'authorDropdownMenuDone_fffcc516',
    authorDropdownScroll: 'authorDropdownScroll_fffcc516',
    authorItemLabel: 'authorItemLabel_fffcc516',
    authorItemLabelChecked: 'authorItemLabelChecked_fffcc516',
    authorItemAvatar: 'authorItemAvatar_fffcc516',
    authorItemAvatarChecked: 'authorItemAvatarChecked_fffcc516',
    authorItemName: 'authorItemName_fffcc516',
    authorItemNameChecked: 'authorItemNameChecked_fffcc516',
    authorDropdownEmpty: 'authorDropdownEmpty_fffcc516',
    historyHeaderIcon: 'historyHeaderIcon_fffcc516',
    historyEmptyIcon: 'historyEmptyIcon_fffcc516',
    sortContainer: 'sortContainer_fffcc516',
    sortLabel: 'sortLabel_fffcc516',
    sortSelect: 'sortSelect_fffcc516',
    promotedSection: 'promotedSection_fffcc516',
    promotedCard: 'promotedCard_fffcc516',
    promotedCrownBox: 'promotedCrownBox_fffcc516',
    promotedCardBody: 'promotedCardBody_fffcc516',
    promotedTitleRow: 'promotedTitleRow_fffcc516',
    promotedCardTitle: 'promotedCardTitle_fffcc516',
    promotedCategoryBadge: 'promotedCategoryBadge_fffcc516',
    promotedCardDescription: 'promotedCardDescription_fffcc516',
    promotedUrlLabel: 'promotedUrlLabel_fffcc516',
    historySectionHeader: 'historySectionHeader_fffcc516',
    analyticsWrapper: 'analyticsWrapper_fffcc516',
    analyticsQueriesList: 'analyticsQueriesList_fffcc516',
    analyticsQueryRow: 'analyticsQueryRow_fffcc516',
    analyticsQueryText: 'analyticsQueryText_fffcc516',
    analyticsCountBadge: 'analyticsCountBadge_fffcc516',
    analyticsDocsList: 'analyticsDocsList_fffcc516',
    analyticsDocRow: 'analyticsDocRow_fffcc516',
    analyticsDocTitle: 'analyticsDocTitle_fffcc516',
    analyticsDocIcon: 'analyticsDocIcon_fffcc516',
    analyticsDocInfo: 'analyticsDocInfo_fffcc516',
    analyticsDocClicks: 'analyticsDocClicks_fffcc516'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);
/* tslint:enable */ 


/***/ }),

/***/ 1170:
/*!************************************!*\
  !*** ./lib/utils/SearchHelpers.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getSharePointThumbnailUrl: () => (/* binding */ getSharePointThumbnailUrl),
/* harmony export */   renderFormattedSummary: () => (/* binding */ renderFormattedSummary)
/* harmony export */ });
/* unused harmony export getCleanSharePointUrl */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ 7613);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};

/**
 * Format search result descriptions cleanly:
 * - Replaces <ddd/> tags with standard ellipsis "..."
 * - Wraps <c0>...</c0> highlighted query matches in beautiful themed highlight spans
 * - Dynamically matches background/color with the file brand accent color
 * - Debounces / handles manual highlights when no SharePoint tags are present (fallbacks)
 */
var getCleanSharePointUrl = function (webUrl, title) {
    if (!webUrl)
        return '';
    try {
        var cleaned = webUrl;
        // Replace SharePoint List Item detail page link (DispForm.aspx) with direct file path
        if (cleaned.includes('/Forms/DispForm.aspx')) {
            cleaned = cleaned.replace(/\/Forms\/DispForm\.aspx.*/i, "/".concat(title));
        }
        // Remove sharing/redirect tokens like /:i:/r/ or /:f:/g/ or /:x:/r/ etc.
        cleaned = cleaned.replace(/\/:[a-z]:\/[a-z]\//i, '/');
        cleaned = cleaned.replace(/\/:[a-z]:\/r\//i, '/');
        cleaned = cleaned.replace(/\/:[a-z]:\/g\//i, '/');
        cleaned = cleaned.split('?')[0]; // Strip query parameters
        return cleaned;
    }
    catch (e) {
        return webUrl;
    }
};
var getSharePointThumbnailUrl = function (webUrl, title, resolution) {
    if (resolution === void 0) { resolution = 0; }
    if (!webUrl)
        return '';
    try {
        var cleanUrl = getCleanSharePointUrl(webUrl, title);
        var urlObj = new URL(cleanUrl);
        var host = urlObj.origin;
        var pathParts = urlObj.pathname.split('/');
        var sitePath = '';
        // Correctly resolve site collections and personal OneDrive personal paths
        if (host.includes('-my.sharepoint.com') && pathParts[1] === 'personal' && pathParts[2]) {
            sitePath = "/personal/".concat(pathParts[2]);
        }
        else if (pathParts[1] === 'sites' && pathParts[2]) {
            sitePath = "/sites/".concat(pathParts[2]);
        }
        var resParam = resolution ? "&resolution=".concat(resolution) : '&size=S';
        return "".concat(host).concat(sitePath, "/_layouts/15/getpreview.ashx?path=").concat(encodeURIComponent(cleanUrl)).concat(resParam);
    }
    catch (e) {
        return '';
    }
};
var renderFormattedSummary = function (summary, query, highlightColor) {
    if (query === void 0) { query = ''; }
    if (highlightColor === void 0) { highlightColor = '#1a73e8'; }
    if (!summary)
        return null;
    // First, replace <ddd/> and </ddd/> tags with standard ellipsis "..."
    var cleaned = summary.replace(/<\/?ddd\/?>/gi, '...');
    // Normalize consecutive ellipsis/spaces
    cleaned = cleaned.replace(/\s*\.{3,}\s*/g, ' ... ');
    cleaned = cleaned.replace(/^\s*\.\.\.\s+/, '... ');
    cleaned = cleaned.replace(/\s+\.\.\.\s*$/, ' ...');
    cleaned = cleaned.trim();
    // If there are highlighting tags (<c0>, etc.), parse those tags
    if (/<c\d+>/i.test(cleaned)) {
        var tagRegex = /(<c\d+>.*?<\/c\d+>)/gi;
        var splitParts = cleaned.split(tagRegex);
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: splitParts.map(function (part, index) {
                var match = part.match(/<c\d+>(.*?)<\/c\d+>/i);
                if (match) {
                    var highlightedText = match[1];
                    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ style: {
                            backgroundColor: highlightColor === '#1a73e8' ? 'rgba(26, 115, 232, 0.15)' : "".concat(highlightColor, "15"),
                            color: highlightColor,
                            fontWeight: 'bold',
                            padding: '0 2px',
                            borderRadius: '2px',
                        } }, { children: highlightedText }), index));
                }
                return part;
            }) }));
    }
    // If there are no highlight tags, but there is a query string, highlight the query string
    if (query && query.trim()) {
        // Escape special characters in query to prevent invalid RegEx
        var escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // eslint-disable-next-line @rushstack/security/no-unsafe-regexp
        var parts = cleaned.split(new RegExp("(".concat(escapedQuery, ")"), 'gi'));
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: parts.map(function (part, i) {
                return part.toLowerCase() === query.toLowerCase() ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", __assign({ style: {
                        backgroundColor: highlightColor === '#1a73e8' ? 'rgba(26, 115, 232, 0.15)' : "".concat(highlightColor, "15"),
                        color: highlightColor,
                        fontWeight: 'bold',
                        padding: '0 2px',
                        borderRadius: '2px'
                    } }, { children: part }), i)) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: part }, i));
            }) }));
    }
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: cleaned });
};


/***/ }),

/***/ 1919:
/*!*********************************************************************!*\
  !*** ./node_modules/@microsoft/load-themed-styles/lib-es6/index.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadStyles: () => (/* binding */ loadStyles)
/* harmony export */ });
/* unused harmony exports configureLoadStyles, configureRunMode, flush, loadTheme, clearStyles, detokenize, splitStyles */
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? __webpack_require__.g : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: 0 /* Mode.sync */,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === 1 /* Mode.async */) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    return setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = 3 /* ClearStyleOptions.all */; }
    if (option === 3 /* ClearStyleOptions.all */ || option === 2 /* ClearStyleOptions.onlyNonThemable */) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === 3 /* ClearStyleOptions.all */ || option === 1 /* ClearStyleOptions.onlyThemable */) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(1 /* ClearStyleOptions.onlyThemable */);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}


/***/ }),

/***/ 943:
/*!****************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/Icon.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Icon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _defaultAttributes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./defaultAttributes.js */ 8913);
/* harmony import */ var _shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared/src/utils.js */ 7787);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */





const Icon = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(
    "svg",
    {
      ref,
      ..._defaultAttributes_js__WEBPACK_IMPORTED_MODULE_1__["default"],
      width: size,
      height: size,
      stroke: color,
      strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
      className: (0,_shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__.mergeClasses)("lucide", className),
      ...!children && !(0,_shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__.hasA11yProp)(rest) && { "aria-hidden": "true" },
      ...rest
    },
    [
      ...iconNode.map(([tag, attrs]) => (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(tag, attrs)),
      ...Array.isArray(children) ? children : [children]
    ]
  )
);




/***/ }),

/***/ 6614:
/*!****************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/createLucideIcon.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ createLucideIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared/src/utils.js */ 7787);
/* harmony import */ var _Icon_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Icon.js */ 943);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */





const createLucideIcon = (iconName, iconNode) => {
  const Component = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(
    ({ className, ...props }, ref) => (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(_Icon_js__WEBPACK_IMPORTED_MODULE_1__["default"], {
      ref,
      iconNode,
      className: (0,_shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__.mergeClasses)(
        `lucide-${(0,_shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__.toKebabCase)((0,_shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__.toPascalCase)(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component.displayName = (0,_shared_src_utils_js__WEBPACK_IMPORTED_MODULE_2__.toPascalCase)(iconName);
  return Component;
};




/***/ }),

/***/ 8913:
/*!*****************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/defaultAttributes.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ defaultAttributes)
/* harmony export */ });
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};




/***/ }),

/***/ 3278:
/*!**************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/calendar.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Calendar)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }]
];
const Calendar = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("calendar", __iconNode);




/***/ }),

/***/ 7263:
/*!******************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/chevron-left.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ChevronLeft)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }]];
const ChevronLeft = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("chevron-left", __iconNode);




/***/ }),

/***/ 1695:
/*!*******************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/chevron-right.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ChevronRight)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]];
const ChevronRight = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("chevron-right", __iconNode);




/***/ }),

/***/ 7805:
/*!**********************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/copy.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Copy)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
const Copy = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("copy", __iconNode);




/***/ }),

/***/ 5220:
/*!**************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/download.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Download)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M12 15V3", key: "m9g1x1" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }]
];
const Download = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("download", __iconNode);




/***/ }),

/***/ 8167:
/*!***********************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ EllipsisVertical)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
  ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }]
];
const EllipsisVertical = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("ellipsis-vertical", __iconNode);




/***/ }),

/***/ 4365:
/*!*******************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/external-link.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ExternalLink)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
  ["path", { d: "M10 14 21 3", key: "gplh6r" }],
  ["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", key: "a6xqqp" }]
];
const ExternalLink = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("external-link", __iconNode);




/***/ }),

/***/ 9119:
/*!**********************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/file-spreadsheet.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FileSpreadsheet)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M8 13h2", key: "yr2amv" }],
  ["path", { d: "M14 13h2", key: "un5t4a" }],
  ["path", { d: "M8 17h2", key: "2yhykz" }],
  ["path", { d: "M14 17h2", key: "10kma7" }]
];
const FileSpreadsheet = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("file-spreadsheet", __iconNode);




/***/ }),

/***/ 298:
/*!***************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/file-text.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FileText)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
];
const FileText = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("file-text", __iconNode);




/***/ }),

/***/ 6246:
/*!*****************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/folder-open.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FolderOpen)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  [
    "path",
    {
      d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
      key: "usdka0"
    }
  ]
];
const FolderOpen = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("folder-open", __iconNode);




/***/ }),

/***/ 7826:
/*!************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/folder.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Folder)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
];
const Folder = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("folder", __iconNode);




/***/ }),

/***/ 9054:
/*!*******************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/grip-vertical.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ GripVertical)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["circle", { cx: "9", cy: "12", r: "1", key: "1vctgf" }],
  ["circle", { cx: "9", cy: "5", r: "1", key: "hp0tcf" }],
  ["circle", { cx: "9", cy: "19", r: "1", key: "fkjjf6" }],
  ["circle", { cx: "15", cy: "12", r: "1", key: "1tmaij" }],
  ["circle", { cx: "15", cy: "5", r: "1", key: "19l28e" }],
  ["circle", { cx: "15", cy: "19", r: "1", key: "f4zoj3" }]
];
const GripVertical = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("grip-vertical", __iconNode);




/***/ }),

/***/ 1461:
/*!*************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/history.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ History)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["path", { d: "M12 7v5l4 2", key: "1fdv2h" }]
];
const History = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("history", __iconNode);




/***/ }),

/***/ 6329:
/*!***********************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/image.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Image)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }]
];
const Image = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("image", __iconNode);




/***/ }),

/***/ 4828:
/*!*************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/monitor.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Monitor)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["line", { x1: "8", x2: "16", y1: "21", y2: "21", key: "1svkeh" }],
  ["line", { x1: "12", x2: "12", y1: "17", y2: "21", key: "vw1qmm" }]
];
const Monitor = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("monitor", __iconNode);




/***/ }),

/***/ 9843:
/*!************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/search.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Search)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
];
const Search = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("search", __iconNode);




/***/ }),

/***/ 5244:
/*!************************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/sliders-horizontal.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SlidersHorizontal)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["line", { x1: "21", x2: "14", y1: "4", y2: "4", key: "obuewd" }],
  ["line", { x1: "10", x2: "3", y1: "4", y2: "4", key: "1q6298" }],
  ["line", { x1: "21", x2: "12", y1: "12", y2: "12", key: "1iu8h1" }],
  ["line", { x1: "8", x2: "3", y1: "12", y2: "12", key: "ntss68" }],
  ["line", { x1: "21", x2: "16", y1: "20", y2: "20", key: "14d8ph" }],
  ["line", { x1: "12", x2: "3", y1: "20", y2: "20", key: "m0wm8r" }],
  ["line", { x1: "14", x2: "14", y1: "2", y2: "6", key: "14e1ph" }],
  ["line", { x1: "8", x2: "8", y1: "10", y2: "14", key: "1i6ji0" }],
  ["line", { x1: "16", x2: "16", y1: "18", y2: "22", key: "1lctlv" }]
];
const SlidersHorizontal = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("sliders-horizontal", __iconNode);




/***/ }),

/***/ 7401:
/*!**********************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/star.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Star)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  [
    "path",
    {
      d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
      key: "r04s7s"
    }
  ]
];
const Star = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("star", __iconNode);




/***/ }),

/***/ 8735:
/*!**********************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/user.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ User)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
  ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
];
const User = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("user", __iconNode);




/***/ }),

/***/ 3521:
/*!***********************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/video.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Video)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  [
    "path",
    {
      d: "m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",
      key: "ftymec"
    }
  ],
  ["rect", { x: "2", y: "6", width: "14", height: "12", rx: "2", key: "158x01" }]
];
const Video = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("video", __iconNode);




/***/ }),

/***/ 2035:
/*!*******************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/icons/x.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ X)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createLucideIcon.js */ 6614);
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */



const __iconNode = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
];
const X = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])("x", __iconNode);




/***/ }),

/***/ 7787:
/*!****************************************************************!*\
  !*** ./node_modules/lucide-react/dist/esm/shared/src/utils.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hasA11yProp: () => (/* binding */ hasA11yProp),
/* harmony export */   mergeClasses: () => (/* binding */ mergeClasses),
/* harmony export */   toKebabCase: () => (/* binding */ toKebabCase),
/* harmony export */   toPascalCase: () => (/* binding */ toPascalCase)
/* harmony export */ });
/* unused harmony export toCamelCase */
/**
 * @license lucide-react v0.540.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);
const toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
const mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
const hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
};




/***/ }),

/***/ 2792:
/*!*********************************************!*\
  !*** ./node_modules/object-assign/index.js ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ 3869:
/*!************************************************************!*\
  !*** ./node_modules/react-paginate/dist/react-paginate.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

!function(e,a){ true?module.exports=a(__webpack_require__(/*! react */ 2650)):0}(this,(e=>(()=>{var a={703:(e,a,t)=>{"use strict";var r=t(414);function n(){}function i(){}i.resetWarningCache=n,e.exports=function(){function e(e,a,t,n,i,s){if(s!==r){var o=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw o.name="Invariant Violation",o}}function a(){return e}e.isRequired=e;var t={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:a,element:e,elementType:e,instanceOf:a,node:e,objectOf:a,oneOf:a,oneOfType:a,shape:a,exact:a,checkPropTypes:i,resetWarningCache:n};return t.PropTypes=t,t}},697:(e,a,t)=>{e.exports=t(703)()},414:e=>{"use strict";e.exports="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"},98:a=>{"use strict";a.exports=e}},t={};function r(e){var n=t[e];if(void 0!==n)return n.exports;var i=t[e]={exports:{}};return a[e](i,i.exports,r),i.exports}r.n=e=>{var a=e&&e.__esModule?()=>e.default:()=>e;return r.d(a,{a}),a},r.d=(e,a)=>{for(var t in a)r.o(a,t)&&!r.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:a[t]})},r.o=(e,a)=>Object.prototype.hasOwnProperty.call(e,a),r.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var n={};return(()=>{"use strict";r.r(n),r.d(n,{default:()=>k});var e=r(98),a=r.n(e),t=r(697),i=r.n(t);function s(){return s=Object.assign?Object.assign.bind():function(e){for(var a=1;a<arguments.length;a++){var t=arguments[a];for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])}return e},s.apply(this,arguments)}var o=function(e){var t=e.pageClassName,r=e.pageLinkClassName,n=e.page,i=e.selected,o=e.activeClassName,l=e.activeLinkClassName,c=e.getEventListener,p=e.pageSelectedHandler,u=e.href,g=e.extraAriaContext,d=e.pageLabelBuilder,f=e.rel,b=e.ariaLabel||"Page "+n+(g?" "+g:""),v=null;return i&&(v="page",b=e.ariaLabel||"Page "+n+" is your current page",t=void 0!==t?t+" "+o:o,void 0!==r?void 0!==l&&(r=r+" "+l):r=l),a().createElement("li",{className:t},a().createElement("a",s({rel:f,role:u?void 0:"button",className:r,href:u,tabIndex:i?"-1":"0","aria-label":b,"aria-current":v,onKeyPress:p},c(p)),d(n)))};o.propTypes={pageSelectedHandler:i().func.isRequired,selected:i().bool.isRequired,pageClassName:i().string,pageLinkClassName:i().string,activeClassName:i().string,activeLinkClassName:i().string,extraAriaContext:i().string,href:i().string,ariaLabel:i().string,page:i().number.isRequired,getEventListener:i().func.isRequired,pageLabelBuilder:i().func.isRequired,rel:i().string};const l=o;function c(){return c=Object.assign?Object.assign.bind():function(e){for(var a=1;a<arguments.length;a++){var t=arguments[a];for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])}return e},c.apply(this,arguments)}var p=function(e){var t=e.breakLabel,r=e.breakAriaLabel,n=e.breakClassName,i=e.breakLinkClassName,s=e.breakHandler,o=e.getEventListener,l=n||"break";return a().createElement("li",{className:l},a().createElement("a",c({className:i,role:"button",tabIndex:"0","aria-label":r,onKeyPress:s},o(s)),t))};p.propTypes={breakLabel:i().oneOfType([i().string,i().node]),breakAriaLabel:i().string,breakClassName:i().string,breakLinkClassName:i().string,breakHandler:i().func.isRequired,getEventListener:i().func.isRequired};const u=p;function g(e){var a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";return null!=e?e:a}function d(e){return d="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},d(e)}function f(){return f=Object.assign?Object.assign.bind():function(e){for(var a=1;a<arguments.length;a++){var t=arguments[a];for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])}return e},f.apply(this,arguments)}function b(e,a){for(var t=0;t<a.length;t++){var r=a[t];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function v(e,a){return v=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(e,a){return e.__proto__=a,e},v(e,a)}function h(e,a){if(a&&("object"===d(a)||"function"==typeof a))return a;if(void 0!==a)throw new TypeError("Derived constructors may only return object or undefined");return m(e)}function m(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e}function y(e){return y=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(e){return e.__proto__||Object.getPrototypeOf(e)},y(e)}function C(e,a,t){return a in e?Object.defineProperty(e,a,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[a]=t,e}var P=function(e){!function(e,a){if("function"!=typeof a&&null!==a)throw new TypeError("Super expression must either be null or a function");e.prototype=Object.create(a&&a.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),Object.defineProperty(e,"prototype",{writable:!1}),a&&v(e,a)}(o,e);var t,r,n,i,s=(n=o,i=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(e){return!1}}(),function(){var e,a=y(n);if(i){var t=y(this).constructor;e=Reflect.construct(a,arguments,t)}else e=a.apply(this,arguments);return h(this,e)});function o(e){var t,r;return function(e,a){if(!(e instanceof a))throw new TypeError("Cannot call a class as a function")}(this,o),C(m(t=s.call(this,e)),"handlePreviousPage",(function(e){var a=t.state.selected;t.handleClick(e,null,a>0?a-1:void 0,{isPrevious:!0})})),C(m(t),"handleNextPage",(function(e){var a=t.state.selected,r=t.props.pageCount;t.handleClick(e,null,a<r-1?a+1:void 0,{isNext:!0})})),C(m(t),"handlePageSelected",(function(e,a){if(t.state.selected===e)return t.callActiveCallback(e),void t.handleClick(a,null,void 0,{isActive:!0});t.handleClick(a,null,e)})),C(m(t),"handlePageChange",(function(e){t.state.selected!==e&&(t.setState({selected:e}),t.callCallback(e))})),C(m(t),"getEventListener",(function(e){return C({},t.props.eventListener,e)})),C(m(t),"handleClick",(function(e,a,r){var n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},i=n.isPrevious,s=void 0!==i&&i,o=n.isNext,l=void 0!==o&&o,c=n.isBreak,p=void 0!==c&&c,u=n.isActive,g=void 0!==u&&u;e.preventDefault?e.preventDefault():e.returnValue=!1;var d=t.state.selected,f=t.props.onClick,b=r;if(f){var v=f({index:a,selected:d,nextSelectedPage:r,event:e,isPrevious:s,isNext:l,isBreak:p,isActive:g});if(!1===v)return;Number.isInteger(v)&&(b=v)}void 0!==b&&t.handlePageChange(b)})),C(m(t),"handleBreakClick",(function(e,a){var r=t.state.selected;t.handleClick(a,e,r<e?t.getForwardJump():t.getBackwardJump(),{isBreak:!0})})),C(m(t),"callCallback",(function(e){void 0!==t.props.onPageChange&&"function"==typeof t.props.onPageChange&&t.props.onPageChange({selected:e})})),C(m(t),"callActiveCallback",(function(e){void 0!==t.props.onPageActive&&"function"==typeof t.props.onPageActive&&t.props.onPageActive({selected:e})})),C(m(t),"getElementPageRel",(function(e){var a=t.state.selected,r=t.props,n=r.nextPageRel,i=r.prevPageRel,s=r.selectedPageRel;return a-1===e?i:a===e?s:a+1===e?n:void 0})),C(m(t),"pagination",(function(){var e=[],r=t.props,n=r.pageRangeDisplayed,i=r.pageCount,s=r.marginPagesDisplayed,o=r.breakLabel,l=r.breakClassName,c=r.breakLinkClassName,p=r.breakAriaLabels,g=t.state.selected;if(i<=n)for(var d=0;d<i;d++)e.push(t.getPageElement(d));else{var f=n/2,b=n-f;g>i-n/2?f=n-(b=i-g):g<n/2&&(b=n-(f=g));var v,h,m=function(e){return t.getPageElement(e)},y=[];for(v=0;v<i;v++){var C=v+1;if(C<=s)y.push({type:"page",index:v,display:m(v)});else if(C>i-s)y.push({type:"page",index:v,display:m(v)});else if(v>=g-f&&v<=g+(0===g&&n>1?b-1:b))y.push({type:"page",index:v,display:m(v)});else if(o&&y.length>0&&y[y.length-1].display!==h&&(n>0||s>0)){var P=v<g?p.backward:p.forward;h=a().createElement(u,{key:v,breakAriaLabel:P,breakLabel:o,breakClassName:l,breakLinkClassName:c,breakHandler:t.handleBreakClick.bind(null,v),getEventListener:t.getEventListener}),y.push({type:"break",index:v,display:h})}}y.forEach((function(a,t){var r=a;"break"===a.type&&y[t-1]&&"page"===y[t-1].type&&y[t+1]&&"page"===y[t+1].type&&y[t+1].index-y[t-1].index<=2&&(r={type:"page",index:a.index,display:m(a.index)}),e.push(r.display)}))}return e})),void 0!==e.initialPage&&void 0!==e.forcePage&&console.warn("(react-paginate): Both initialPage (".concat(e.initialPage,") and forcePage (").concat(e.forcePage,") props are provided, which is discouraged.")+" Use exclusively forcePage prop for a controlled component.\nSee https://reactjs.org/docs/forms.html#controlled-components"),r=e.initialPage?e.initialPage:e.forcePage?e.forcePage:0,t.state={selected:r},t}return t=o,(r=[{key:"componentDidMount",value:function(){var e=this.props,a=e.initialPage,t=e.disableInitialCallback,r=e.extraAriaContext,n=e.pageCount,i=e.forcePage;void 0===a||t||this.callCallback(a),r&&console.warn("DEPRECATED (react-paginate): The extraAriaContext prop is deprecated. You should now use the ariaLabelBuilder instead."),Number.isInteger(n)||console.warn("(react-paginate): The pageCount prop value provided is not an integer (".concat(n,"). Did you forget a Math.ceil()?")),void 0!==a&&a>n-1&&console.warn("(react-paginate): The initialPage prop provided is greater than the maximum page index from pageCount prop (".concat(a," > ").concat(n-1,").")),void 0!==i&&i>n-1&&console.warn("(react-paginate): The forcePage prop provided is greater than the maximum page index from pageCount prop (".concat(i," > ").concat(n-1,")."))}},{key:"componentDidUpdate",value:function(e){void 0!==this.props.forcePage&&this.props.forcePage!==e.forcePage&&(this.props.forcePage>this.props.pageCount-1&&console.warn("(react-paginate): The forcePage prop provided is greater than the maximum page index from pageCount prop (".concat(this.props.forcePage," > ").concat(this.props.pageCount-1,").")),this.setState({selected:this.props.forcePage})),Number.isInteger(e.pageCount)&&!Number.isInteger(this.props.pageCount)&&console.warn("(react-paginate): The pageCount prop value provided is not an integer (".concat(this.props.pageCount,"). Did you forget a Math.ceil()?"))}},{key:"getForwardJump",value:function(){var e=this.state.selected,a=this.props,t=a.pageCount,r=e+a.pageRangeDisplayed;return r>=t?t-1:r}},{key:"getBackwardJump",value:function(){var e=this.state.selected-this.props.pageRangeDisplayed;return e<0?0:e}},{key:"getElementHref",value:function(e){var a=this.props,t=a.hrefBuilder,r=a.pageCount,n=a.hrefAllControls;if(t)return n||e>=0&&e<r?t(e+1,r,this.state.selected):void 0}},{key:"ariaLabelBuilder",value:function(e){var a=e===this.state.selected;if(this.props.ariaLabelBuilder&&e>=0&&e<this.props.pageCount){var t=this.props.ariaLabelBuilder(e+1,a);return this.props.extraAriaContext&&!a&&(t=t+" "+this.props.extraAriaContext),t}}},{key:"getPageElement",value:function(e){var t=this.state.selected,r=this.props,n=r.pageClassName,i=r.pageLinkClassName,s=r.activeClassName,o=r.activeLinkClassName,c=r.extraAriaContext,p=r.pageLabelBuilder;return a().createElement(l,{key:e,pageSelectedHandler:this.handlePageSelected.bind(null,e),selected:t===e,rel:this.getElementPageRel(e),pageClassName:n,pageLinkClassName:i,activeClassName:s,activeLinkClassName:o,extraAriaContext:c,href:this.getElementHref(e),ariaLabel:this.ariaLabelBuilder(e),page:e+1,pageLabelBuilder:p,getEventListener:this.getEventListener})}},{key:"render",value:function(){var e=this.props.renderOnZeroPageCount;if(0===this.props.pageCount&&void 0!==e)return e?e(this.props):e;var t=this.props,r=t.disabledClassName,n=t.disabledLinkClassName,i=t.pageCount,s=t.className,o=t.containerClassName,l=t.previousLabel,c=t.previousClassName,p=t.previousLinkClassName,u=t.previousAriaLabel,d=t.prevRel,b=t.nextLabel,v=t.nextClassName,h=t.nextLinkClassName,m=t.nextAriaLabel,y=t.nextRel,C=this.state.selected,P=0===C,k=C===i-1,x="".concat(g(c)).concat(P?" ".concat(g(r)):""),L="".concat(g(v)).concat(k?" ".concat(g(r)):""),N="".concat(g(p)).concat(P?" ".concat(g(n)):""),O="".concat(g(h)).concat(k?" ".concat(g(n)):""),R=P?"true":"false",E=k?"true":"false";return a().createElement("ul",{className:s||o,role:"navigation","aria-label":"Pagination"},a().createElement("li",{className:x},a().createElement("a",f({className:N,href:this.getElementHref(C-1),tabIndex:P?"-1":"0",role:"button",onKeyPress:this.handlePreviousPage,"aria-disabled":R,"aria-label":u,rel:d},this.getEventListener(this.handlePreviousPage)),l)),this.pagination(),a().createElement("li",{className:L},a().createElement("a",f({className:O,href:this.getElementHref(C+1),tabIndex:k?"-1":"0",role:"button",onKeyPress:this.handleNextPage,"aria-disabled":E,"aria-label":m,rel:y},this.getEventListener(this.handleNextPage)),b)))}}])&&b(t.prototype,r),Object.defineProperty(t,"prototype",{writable:!1}),o}(e.Component);C(P,"propTypes",{pageCount:i().number.isRequired,pageRangeDisplayed:i().number,marginPagesDisplayed:i().number,previousLabel:i().node,previousAriaLabel:i().string,prevPageRel:i().string,prevRel:i().string,nextLabel:i().node,nextAriaLabel:i().string,nextPageRel:i().string,nextRel:i().string,breakLabel:i().oneOfType([i().string,i().node]),breakAriaLabels:i().shape({forward:i().string,backward:i().string}),hrefBuilder:i().func,hrefAllControls:i().bool,onPageChange:i().func,onPageActive:i().func,onClick:i().func,initialPage:i().number,forcePage:i().number,disableInitialCallback:i().bool,containerClassName:i().string,className:i().string,pageClassName:i().string,pageLinkClassName:i().string,pageLabelBuilder:i().func,activeClassName:i().string,activeLinkClassName:i().string,previousClassName:i().string,nextClassName:i().string,previousLinkClassName:i().string,nextLinkClassName:i().string,disabledClassName:i().string,disabledLinkClassName:i().string,breakClassName:i().string,breakLinkClassName:i().string,extraAriaContext:i().string,ariaLabelBuilder:i().func,eventListener:i().string,renderOnZeroPageCount:i().func,selectedPageRel:i().string}),C(P,"defaultProps",{pageRangeDisplayed:2,marginPagesDisplayed:3,activeClassName:"selected",previousLabel:"Previous",previousClassName:"previous",previousAriaLabel:"Previous page",prevPageRel:"prev",prevRel:"prev",nextLabel:"Next",nextClassName:"next",nextAriaLabel:"Next page",nextPageRel:"next",nextRel:"next",breakLabel:"...",breakAriaLabels:{forward:"Jump forward",backward:"Jump backward"},disabledClassName:"disabled",disableInitialCallback:!1,pageLabelBuilder:function(e){return e},eventListener:"onClick",renderOnZeroPageCount:void 0,selectedPageRel:"canonical",hrefAllControls:!1});const k=P})(),n})()));


/***/ }),

/***/ 2943:
/*!*****************************************************************!*\
  !*** ./node_modules/react/cjs/react-jsx-runtime.development.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/** @license React v17.0.1
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  (function() {
'use strict';

var React = __webpack_require__(/*! react */ 2650);
var _assign = __webpack_require__(/*! object-assign */ 2792);

// ATTENTION
// When adding new symbols to this file,
// Please consider also adding to 'react-devtools-shared/src/backend/ReactSymbols'
// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var REACT_ELEMENT_TYPE = 0xeac7;
var REACT_PORTAL_TYPE = 0xeaca;
exports.Fragment = 0xeacb;
var REACT_STRICT_MODE_TYPE = 0xeacc;
var REACT_PROFILER_TYPE = 0xead2;
var REACT_PROVIDER_TYPE = 0xeacd;
var REACT_CONTEXT_TYPE = 0xeace;
var REACT_FORWARD_REF_TYPE = 0xead0;
var REACT_SUSPENSE_TYPE = 0xead1;
var REACT_SUSPENSE_LIST_TYPE = 0xead8;
var REACT_MEMO_TYPE = 0xead3;
var REACT_LAZY_TYPE = 0xead4;
var REACT_BLOCK_TYPE = 0xead9;
var REACT_SERVER_BLOCK_TYPE = 0xeada;
var REACT_FUNDAMENTAL_TYPE = 0xead5;
var REACT_SCOPE_TYPE = 0xead7;
var REACT_OPAQUE_ID_TYPE = 0xeae0;
var REACT_DEBUG_TRACING_MODE_TYPE = 0xeae1;
var REACT_OFFSCREEN_TYPE = 0xeae2;
var REACT_LEGACY_HIDDEN_TYPE = 0xeae3;

if (typeof Symbol === 'function' && Symbol.for) {
  var symbolFor = Symbol.for;
  REACT_ELEMENT_TYPE = symbolFor('react.element');
  REACT_PORTAL_TYPE = symbolFor('react.portal');
  exports.Fragment = symbolFor('react.fragment');
  REACT_STRICT_MODE_TYPE = symbolFor('react.strict_mode');
  REACT_PROFILER_TYPE = symbolFor('react.profiler');
  REACT_PROVIDER_TYPE = symbolFor('react.provider');
  REACT_CONTEXT_TYPE = symbolFor('react.context');
  REACT_FORWARD_REF_TYPE = symbolFor('react.forward_ref');
  REACT_SUSPENSE_TYPE = symbolFor('react.suspense');
  REACT_SUSPENSE_LIST_TYPE = symbolFor('react.suspense_list');
  REACT_MEMO_TYPE = symbolFor('react.memo');
  REACT_LAZY_TYPE = symbolFor('react.lazy');
  REACT_BLOCK_TYPE = symbolFor('react.block');
  REACT_SERVER_BLOCK_TYPE = symbolFor('react.server.block');
  REACT_FUNDAMENTAL_TYPE = symbolFor('react.fundamental');
  REACT_SCOPE_TYPE = symbolFor('react.scope');
  REACT_OPAQUE_ID_TYPE = symbolFor('react.opaque.id');
  REACT_DEBUG_TRACING_MODE_TYPE = symbolFor('react.debug_trace_mode');
  REACT_OFFSCREEN_TYPE = symbolFor('react.offscreen');
  REACT_LEGACY_HIDDEN_TYPE = symbolFor('react.legacy_hidden');
}

var MAYBE_ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
var FAUX_ITERATOR_SYMBOL = '@@iterator';
function getIteratorFn(maybeIterable) {
  if (maybeIterable === null || typeof maybeIterable !== 'object') {
    return null;
  }

  var maybeIterator = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL];

  if (typeof maybeIterator === 'function') {
    return maybeIterator;
  }

  return null;
}

var ReactSharedInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;

function error(format) {
  {
    for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      args[_key2 - 1] = arguments[_key2];
    }

    printWarning('error', format, args);
  }
}

function printWarning(level, format, args) {
  // When changing this logic, you might want to also
  // update consoleWithStackDev.www.js as well.
  {
    var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame;
    var stack = ReactDebugCurrentFrame.getStackAddendum();

    if (stack !== '') {
      format += '%s';
      args = args.concat([stack]);
    }

    var argsWithFormat = args.map(function (item) {
      return '' + item;
    }); // Careful: RN currently depends on this prefix

    argsWithFormat.unshift('Warning: ' + format); // We intentionally don't use spread (or .apply) directly because it
    // breaks IE9: https://github.com/facebook/react/issues/13610
    // eslint-disable-next-line react-internal/no-production-logging

    Function.prototype.apply.call(console[level], console, argsWithFormat);
  }
}

// Filter certain DOM attributes (e.g. src, href) if their values are empty strings.

var enableScopeAPI = false; // Experimental Create Event Handle API.

function isValidElementType(type) {
  if (typeof type === 'string' || typeof type === 'function') {
    return true;
  } // Note: typeof might be other than 'symbol' or 'number' (e.g. if it's a polyfill).


  if (type === exports.Fragment || type === REACT_PROFILER_TYPE || type === REACT_DEBUG_TRACING_MODE_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || type === REACT_LEGACY_HIDDEN_TYPE || enableScopeAPI ) {
    return true;
  }

  if (typeof type === 'object' && type !== null) {
    if (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_BLOCK_TYPE || type[0] === REACT_SERVER_BLOCK_TYPE) {
      return true;
    }
  }

  return false;
}

function getWrappedName(outerType, innerType, wrapperName) {
  var functionName = innerType.displayName || innerType.name || '';
  return outerType.displayName || (functionName !== '' ? wrapperName + "(" + functionName + ")" : wrapperName);
}

function getContextName(type) {
  return type.displayName || 'Context';
}

function getComponentName(type) {
  if (type == null) {
    // Host root, text node or just invalid type.
    return null;
  }

  {
    if (typeof type.tag === 'number') {
      error('Received an unexpected object in getComponentName(). ' + 'This is likely a bug in React. Please file an issue.');
    }
  }

  if (typeof type === 'function') {
    return type.displayName || type.name || null;
  }

  if (typeof type === 'string') {
    return type;
  }

  switch (type) {
    case exports.Fragment:
      return 'Fragment';

    case REACT_PORTAL_TYPE:
      return 'Portal';

    case REACT_PROFILER_TYPE:
      return 'Profiler';

    case REACT_STRICT_MODE_TYPE:
      return 'StrictMode';

    case REACT_SUSPENSE_TYPE:
      return 'Suspense';

    case REACT_SUSPENSE_LIST_TYPE:
      return 'SuspenseList';
  }

  if (typeof type === 'object') {
    switch (type.$$typeof) {
      case REACT_CONTEXT_TYPE:
        var context = type;
        return getContextName(context) + '.Consumer';

      case REACT_PROVIDER_TYPE:
        var provider = type;
        return getContextName(provider._context) + '.Provider';

      case REACT_FORWARD_REF_TYPE:
        return getWrappedName(type, type.render, 'ForwardRef');

      case REACT_MEMO_TYPE:
        return getComponentName(type.type);

      case REACT_BLOCK_TYPE:
        return getComponentName(type._render);

      case REACT_LAZY_TYPE:
        {
          var lazyComponent = type;
          var payload = lazyComponent._payload;
          var init = lazyComponent._init;

          try {
            return getComponentName(init(payload));
          } catch (x) {
            return null;
          }
        }
    }
  }

  return null;
}

// Helpers to patch console.logs to avoid logging during side-effect free
// replaying on render function. This currently only patches the object
// lazily which won't cover if the log function was extracted eagerly.
// We could also eagerly patch the method.
var disabledDepth = 0;
var prevLog;
var prevInfo;
var prevWarn;
var prevError;
var prevGroup;
var prevGroupCollapsed;
var prevGroupEnd;

function disabledLog() {}

disabledLog.__reactDisabledLog = true;
function disableLogs() {
  {
    if (disabledDepth === 0) {
      /* eslint-disable react-internal/no-production-logging */
      prevLog = console.log;
      prevInfo = console.info;
      prevWarn = console.warn;
      prevError = console.error;
      prevGroup = console.group;
      prevGroupCollapsed = console.groupCollapsed;
      prevGroupEnd = console.groupEnd; // https://github.com/facebook/react/issues/19099

      var props = {
        configurable: true,
        enumerable: true,
        value: disabledLog,
        writable: true
      }; // $FlowFixMe Flow thinks console is immutable.

      Object.defineProperties(console, {
        info: props,
        log: props,
        warn: props,
        error: props,
        group: props,
        groupCollapsed: props,
        groupEnd: props
      });
      /* eslint-enable react-internal/no-production-logging */
    }

    disabledDepth++;
  }
}
function reenableLogs() {
  {
    disabledDepth--;

    if (disabledDepth === 0) {
      /* eslint-disable react-internal/no-production-logging */
      var props = {
        configurable: true,
        enumerable: true,
        writable: true
      }; // $FlowFixMe Flow thinks console is immutable.

      Object.defineProperties(console, {
        log: _assign({}, props, {
          value: prevLog
        }),
        info: _assign({}, props, {
          value: prevInfo
        }),
        warn: _assign({}, props, {
          value: prevWarn
        }),
        error: _assign({}, props, {
          value: prevError
        }),
        group: _assign({}, props, {
          value: prevGroup
        }),
        groupCollapsed: _assign({}, props, {
          value: prevGroupCollapsed
        }),
        groupEnd: _assign({}, props, {
          value: prevGroupEnd
        })
      });
      /* eslint-enable react-internal/no-production-logging */
    }

    if (disabledDepth < 0) {
      error('disabledDepth fell below zero. ' + 'This is a bug in React. Please file an issue.');
    }
  }
}

var ReactCurrentDispatcher = ReactSharedInternals.ReactCurrentDispatcher;
var prefix;
function describeBuiltInComponentFrame(name, source, ownerFn) {
  {
    if (prefix === undefined) {
      // Extract the VM specific prefix used by each line.
      try {
        throw Error();
      } catch (x) {
        var match = x.stack.trim().match(/\n( *(at )?)/);
        prefix = match && match[1] || '';
      }
    } // We use the prefix to ensure our stacks line up with native stack frames.


    return '\n' + prefix + name;
  }
}
var reentry = false;
var componentFrameCache;

{
  var PossiblyWeakMap = typeof WeakMap === 'function' ? WeakMap : Map;
  componentFrameCache = new PossiblyWeakMap();
}

function describeNativeComponentFrame(fn, construct) {
  // If something asked for a stack inside a fake render, it should get ignored.
  if (!fn || reentry) {
    return '';
  }

  {
    var frame = componentFrameCache.get(fn);

    if (frame !== undefined) {
      return frame;
    }
  }

  var control;
  reentry = true;
  var previousPrepareStackTrace = Error.prepareStackTrace; // $FlowFixMe It does accept undefined.

  Error.prepareStackTrace = undefined;
  var previousDispatcher;

  {
    previousDispatcher = ReactCurrentDispatcher.current; // Set the dispatcher in DEV because this might be call in the render function
    // for warnings.

    ReactCurrentDispatcher.current = null;
    disableLogs();
  }

  try {
    // This should throw.
    if (construct) {
      // Something should be setting the props in the constructor.
      var Fake = function () {
        throw Error();
      }; // $FlowFixMe


      Object.defineProperty(Fake.prototype, 'props', {
        set: function () {
          // We use a throwing setter instead of frozen or non-writable props
          // because that won't throw in a non-strict mode function.
          throw Error();
        }
      });

      if (typeof Reflect === 'object' && Reflect.construct) {
        // We construct a different control for this case to include any extra
        // frames added by the construct call.
        try {
          Reflect.construct(Fake, []);
        } catch (x) {
          control = x;
        }

        Reflect.construct(fn, [], Fake);
      } else {
        try {
          Fake.call();
        } catch (x) {
          control = x;
        }

        fn.call(Fake.prototype);
      }
    } else {
      try {
        throw Error();
      } catch (x) {
        control = x;
      }

      fn();
    }
  } catch (sample) {
    // This is inlined manually because closure doesn't do it for us.
    if (sample && control && typeof sample.stack === 'string') {
      // This extracts the first frame from the sample that isn't also in the control.
      // Skipping one frame that we assume is the frame that calls the two.
      var sampleLines = sample.stack.split('\n');
      var controlLines = control.stack.split('\n');
      var s = sampleLines.length - 1;
      var c = controlLines.length - 1;

      while (s >= 1 && c >= 0 && sampleLines[s] !== controlLines[c]) {
        // We expect at least one stack frame to be shared.
        // Typically this will be the root most one. However, stack frames may be
        // cut off due to maximum stack limits. In this case, one maybe cut off
        // earlier than the other. We assume that the sample is longer or the same
        // and there for cut off earlier. So we should find the root most frame in
        // the sample somewhere in the control.
        c--;
      }

      for (; s >= 1 && c >= 0; s--, c--) {
        // Next we find the first one that isn't the same which should be the
        // frame that called our sample function and the control.
        if (sampleLines[s] !== controlLines[c]) {
          // In V8, the first line is describing the message but other VMs don't.
          // If we're about to return the first line, and the control is also on the same
          // line, that's a pretty good indicator that our sample threw at same line as
          // the control. I.e. before we entered the sample frame. So we ignore this result.
          // This can happen if you passed a class to function component, or non-function.
          if (s !== 1 || c !== 1) {
            do {
              s--;
              c--; // We may still have similar intermediate frames from the construct call.
              // The next one that isn't the same should be our match though.

              if (c < 0 || sampleLines[s] !== controlLines[c]) {
                // V8 adds a "new" prefix for native classes. Let's remove it to make it prettier.
                var _frame = '\n' + sampleLines[s].replace(' at new ', ' at ');

                {
                  if (typeof fn === 'function') {
                    componentFrameCache.set(fn, _frame);
                  }
                } // Return the line we found.


                return _frame;
              }
            } while (s >= 1 && c >= 0);
          }

          break;
        }
      }
    }
  } finally {
    reentry = false;

    {
      ReactCurrentDispatcher.current = previousDispatcher;
      reenableLogs();
    }

    Error.prepareStackTrace = previousPrepareStackTrace;
  } // Fallback to just using the name if we couldn't make it throw.


  var name = fn ? fn.displayName || fn.name : '';
  var syntheticFrame = name ? describeBuiltInComponentFrame(name) : '';

  {
    if (typeof fn === 'function') {
      componentFrameCache.set(fn, syntheticFrame);
    }
  }

  return syntheticFrame;
}
function describeFunctionComponentFrame(fn, source, ownerFn) {
  {
    return describeNativeComponentFrame(fn, false);
  }
}

function shouldConstruct(Component) {
  var prototype = Component.prototype;
  return !!(prototype && prototype.isReactComponent);
}

function describeUnknownElementTypeFrameInDEV(type, source, ownerFn) {

  if (type == null) {
    return '';
  }

  if (typeof type === 'function') {
    {
      return describeNativeComponentFrame(type, shouldConstruct(type));
    }
  }

  if (typeof type === 'string') {
    return describeBuiltInComponentFrame(type);
  }

  switch (type) {
    case REACT_SUSPENSE_TYPE:
      return describeBuiltInComponentFrame('Suspense');

    case REACT_SUSPENSE_LIST_TYPE:
      return describeBuiltInComponentFrame('SuspenseList');
  }

  if (typeof type === 'object') {
    switch (type.$$typeof) {
      case REACT_FORWARD_REF_TYPE:
        return describeFunctionComponentFrame(type.render);

      case REACT_MEMO_TYPE:
        // Memo may contain any component type so we recursively resolve it.
        return describeUnknownElementTypeFrameInDEV(type.type, source, ownerFn);

      case REACT_BLOCK_TYPE:
        return describeFunctionComponentFrame(type._render);

      case REACT_LAZY_TYPE:
        {
          var lazyComponent = type;
          var payload = lazyComponent._payload;
          var init = lazyComponent._init;

          try {
            // Lazy may contain any component type so we recursively resolve it.
            return describeUnknownElementTypeFrameInDEV(init(payload), source, ownerFn);
          } catch (x) {}
        }
    }
  }

  return '';
}

var loggedTypeFailures = {};
var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame;

function setCurrentlyValidatingElement(element) {
  {
    if (element) {
      var owner = element._owner;
      var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
      ReactDebugCurrentFrame.setExtraStackFrame(stack);
    } else {
      ReactDebugCurrentFrame.setExtraStackFrame(null);
    }
  }
}

function checkPropTypes(typeSpecs, values, location, componentName, element) {
  {
    // $FlowFixMe This is okay but Flow doesn't know it.
    var has = Function.call.bind(Object.prototype.hasOwnProperty);

    for (var typeSpecName in typeSpecs) {
      if (has(typeSpecs, typeSpecName)) {
        var error$1 = void 0; // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.

        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error((componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' + 'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.' + 'This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.');
            err.name = 'Invariant Violation';
            throw err;
          }

          error$1 = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED');
        } catch (ex) {
          error$1 = ex;
        }

        if (error$1 && !(error$1 instanceof Error)) {
          setCurrentlyValidatingElement(element);

          error('%s: type specification of %s' + ' `%s` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a %s. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).', componentName || 'React class', location, typeSpecName, typeof error$1);

          setCurrentlyValidatingElement(null);
        }

        if (error$1 instanceof Error && !(error$1.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error$1.message] = true;
          setCurrentlyValidatingElement(element);

          error('Failed %s type: %s', location, error$1.message);

          setCurrentlyValidatingElement(null);
        }
      }
    }
  }
}

var ReactCurrentOwner = ReactSharedInternals.ReactCurrentOwner;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var RESERVED_PROPS = {
  key: true,
  ref: true,
  __self: true,
  __source: true
};
var specialPropKeyWarningShown;
var specialPropRefWarningShown;
var didWarnAboutStringRefs;

{
  didWarnAboutStringRefs = {};
}

function hasValidRef(config) {
  {
    if (hasOwnProperty.call(config, 'ref')) {
      var getter = Object.getOwnPropertyDescriptor(config, 'ref').get;

      if (getter && getter.isReactWarning) {
        return false;
      }
    }
  }

  return config.ref !== undefined;
}

function hasValidKey(config) {
  {
    if (hasOwnProperty.call(config, 'key')) {
      var getter = Object.getOwnPropertyDescriptor(config, 'key').get;

      if (getter && getter.isReactWarning) {
        return false;
      }
    }
  }

  return config.key !== undefined;
}

function warnIfStringRefCannotBeAutoConverted(config, self) {
  {
    if (typeof config.ref === 'string' && ReactCurrentOwner.current && self && ReactCurrentOwner.current.stateNode !== self) {
      var componentName = getComponentName(ReactCurrentOwner.current.type);

      if (!didWarnAboutStringRefs[componentName]) {
        error('Component "%s" contains the string ref "%s". ' + 'Support for string refs will be removed in a future major release. ' + 'This case cannot be automatically converted to an arrow function. ' + 'We ask you to manually fix this case by using useRef() or createRef() instead. ' + 'Learn more about using refs safely here: ' + 'https://reactjs.org/link/strict-mode-string-ref', getComponentName(ReactCurrentOwner.current.type), config.ref);

        didWarnAboutStringRefs[componentName] = true;
      }
    }
  }
}

function defineKeyPropWarningGetter(props, displayName) {
  {
    var warnAboutAccessingKey = function () {
      if (!specialPropKeyWarningShown) {
        specialPropKeyWarningShown = true;

        error('%s: `key` is not a prop. Trying to access it will result ' + 'in `undefined` being returned. If you need to access the same ' + 'value within the child component, you should pass it as a different ' + 'prop. (https://reactjs.org/link/special-props)', displayName);
      }
    };

    warnAboutAccessingKey.isReactWarning = true;
    Object.defineProperty(props, 'key', {
      get: warnAboutAccessingKey,
      configurable: true
    });
  }
}

function defineRefPropWarningGetter(props, displayName) {
  {
    var warnAboutAccessingRef = function () {
      if (!specialPropRefWarningShown) {
        specialPropRefWarningShown = true;

        error('%s: `ref` is not a prop. Trying to access it will result ' + 'in `undefined` being returned. If you need to access the same ' + 'value within the child component, you should pass it as a different ' + 'prop. (https://reactjs.org/link/special-props)', displayName);
      }
    };

    warnAboutAccessingRef.isReactWarning = true;
    Object.defineProperty(props, 'ref', {
      get: warnAboutAccessingRef,
      configurable: true
    });
  }
}
/**
 * Factory method to create a new React element. This no longer adheres to
 * the class pattern, so do not use new to call it. Also, instanceof check
 * will not work. Instead test $$typeof field against Symbol.for('react.element') to check
 * if something is a React Element.
 *
 * @param {*} type
 * @param {*} props
 * @param {*} key
 * @param {string|object} ref
 * @param {*} owner
 * @param {*} self A *temporary* helper to detect places where `this` is
 * different from the `owner` when React.createElement is called, so that we
 * can warn. We want to get rid of owner and replace string `ref`s with arrow
 * functions, and as long as `this` and owner are the same, there will be no
 * change in behavior.
 * @param {*} source An annotation object (added by a transpiler or otherwise)
 * indicating filename, line number, and/or other information.
 * @internal
 */


var ReactElement = function (type, key, ref, self, source, owner, props) {
  var element = {
    // This tag allows us to uniquely identify this as a React Element
    $$typeof: REACT_ELEMENT_TYPE,
    // Built-in properties that belong on the element
    type: type,
    key: key,
    ref: ref,
    props: props,
    // Record the component responsible for creating this element.
    _owner: owner
  };

  {
    // The validation flag is currently mutative. We put it on
    // an external backing store so that we can freeze the whole object.
    // This can be replaced with a WeakMap once they are implemented in
    // commonly used development environments.
    element._store = {}; // To make comparing ReactElements easier for testing purposes, we make
    // the validation flag non-enumerable (where possible, which should
    // include every environment we run tests in), so the test framework
    // ignores it.

    Object.defineProperty(element._store, 'validated', {
      configurable: false,
      enumerable: false,
      writable: true,
      value: false
    }); // self and source are DEV only properties.

    Object.defineProperty(element, '_self', {
      configurable: false,
      enumerable: false,
      writable: false,
      value: self
    }); // Two elements created in two different places should be considered
    // equal for testing purposes and therefore we hide it from enumeration.

    Object.defineProperty(element, '_source', {
      configurable: false,
      enumerable: false,
      writable: false,
      value: source
    });

    if (Object.freeze) {
      Object.freeze(element.props);
      Object.freeze(element);
    }
  }

  return element;
};
/**
 * https://github.com/reactjs/rfcs/pull/107
 * @param {*} type
 * @param {object} props
 * @param {string} key
 */

function jsxDEV(type, config, maybeKey, source, self) {
  {
    var propName; // Reserved names are extracted

    var props = {};
    var key = null;
    var ref = null; // Currently, key can be spread in as a prop. This causes a potential
    // issue if key is also explicitly declared (ie. <div {...props} key="Hi" />
    // or <div key="Hi" {...props} /> ). We want to deprecate key spread,
    // but as an intermediary step, we will use jsxDEV for everything except
    // <div {...props} key="Hi" />, because we aren't currently able to tell if
    // key is explicitly declared to be undefined or not.

    if (maybeKey !== undefined) {
      key = '' + maybeKey;
    }

    if (hasValidKey(config)) {
      key = '' + config.key;
    }

    if (hasValidRef(config)) {
      ref = config.ref;
      warnIfStringRefCannotBeAutoConverted(config, self);
    } // Remaining properties are added to a new props object


    for (propName in config) {
      if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
        props[propName] = config[propName];
      }
    } // Resolve default props


    if (type && type.defaultProps) {
      var defaultProps = type.defaultProps;

      for (propName in defaultProps) {
        if (props[propName] === undefined) {
          props[propName] = defaultProps[propName];
        }
      }
    }

    if (key || ref) {
      var displayName = typeof type === 'function' ? type.displayName || type.name || 'Unknown' : type;

      if (key) {
        defineKeyPropWarningGetter(props, displayName);
      }

      if (ref) {
        defineRefPropWarningGetter(props, displayName);
      }
    }

    return ReactElement(type, key, ref, self, source, ReactCurrentOwner.current, props);
  }
}

var ReactCurrentOwner$1 = ReactSharedInternals.ReactCurrentOwner;
var ReactDebugCurrentFrame$1 = ReactSharedInternals.ReactDebugCurrentFrame;

function setCurrentlyValidatingElement$1(element) {
  {
    if (element) {
      var owner = element._owner;
      var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
      ReactDebugCurrentFrame$1.setExtraStackFrame(stack);
    } else {
      ReactDebugCurrentFrame$1.setExtraStackFrame(null);
    }
  }
}

var propTypesMisspellWarningShown;

{
  propTypesMisspellWarningShown = false;
}
/**
 * Verifies the object is a ReactElement.
 * See https://reactjs.org/docs/react-api.html#isvalidelement
 * @param {?object} object
 * @return {boolean} True if `object` is a ReactElement.
 * @final
 */

function isValidElement(object) {
  {
    return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
  }
}

function getDeclarationErrorAddendum() {
  {
    if (ReactCurrentOwner$1.current) {
      var name = getComponentName(ReactCurrentOwner$1.current.type);

      if (name) {
        return '\n\nCheck the render method of `' + name + '`.';
      }
    }

    return '';
  }
}

function getSourceInfoErrorAddendum(source) {
  {
    if (source !== undefined) {
      var fileName = source.fileName.replace(/^.*[\\\/]/, '');
      var lineNumber = source.lineNumber;
      return '\n\nCheck your code at ' + fileName + ':' + lineNumber + '.';
    }

    return '';
  }
}
/**
 * Warn if there's no key explicitly set on dynamic arrays of children or
 * object keys are not valid. This allows us to keep track of children between
 * updates.
 */


var ownerHasKeyUseWarning = {};

function getCurrentComponentErrorInfo(parentType) {
  {
    var info = getDeclarationErrorAddendum();

    if (!info) {
      var parentName = typeof parentType === 'string' ? parentType : parentType.displayName || parentType.name;

      if (parentName) {
        info = "\n\nCheck the top-level render call using <" + parentName + ">.";
      }
    }

    return info;
  }
}
/**
 * Warn if the element doesn't have an explicit key assigned to it.
 * This element is in an array. The array could grow and shrink or be
 * reordered. All children that haven't already been validated are required to
 * have a "key" property assigned to it. Error statuses are cached so a warning
 * will only be shown once.
 *
 * @internal
 * @param {ReactElement} element Element that requires a key.
 * @param {*} parentType element's parent's type.
 */


function validateExplicitKey(element, parentType) {
  {
    if (!element._store || element._store.validated || element.key != null) {
      return;
    }

    element._store.validated = true;
    var currentComponentErrorInfo = getCurrentComponentErrorInfo(parentType);

    if (ownerHasKeyUseWarning[currentComponentErrorInfo]) {
      return;
    }

    ownerHasKeyUseWarning[currentComponentErrorInfo] = true; // Usually the current owner is the offender, but if it accepts children as a
    // property, it may be the creator of the child that's responsible for
    // assigning it a key.

    var childOwner = '';

    if (element && element._owner && element._owner !== ReactCurrentOwner$1.current) {
      // Give the component that originally created this child.
      childOwner = " It was passed a child from " + getComponentName(element._owner.type) + ".";
    }

    setCurrentlyValidatingElement$1(element);

    error('Each child in a list should have a unique "key" prop.' + '%s%s See https://reactjs.org/link/warning-keys for more information.', currentComponentErrorInfo, childOwner);

    setCurrentlyValidatingElement$1(null);
  }
}
/**
 * Ensure that every element either is passed in a static location, in an
 * array with an explicit keys property defined, or in an object literal
 * with valid key property.
 *
 * @internal
 * @param {ReactNode} node Statically passed child of any type.
 * @param {*} parentType node's parent's type.
 */


function validateChildKeys(node, parentType) {
  {
    if (typeof node !== 'object') {
      return;
    }

    if (Array.isArray(node)) {
      for (var i = 0; i < node.length; i++) {
        var child = node[i];

        if (isValidElement(child)) {
          validateExplicitKey(child, parentType);
        }
      }
    } else if (isValidElement(node)) {
      // This element was passed in a valid location.
      if (node._store) {
        node._store.validated = true;
      }
    } else if (node) {
      var iteratorFn = getIteratorFn(node);

      if (typeof iteratorFn === 'function') {
        // Entry iterators used to provide implicit keys,
        // but now we print a separate warning for them later.
        if (iteratorFn !== node.entries) {
          var iterator = iteratorFn.call(node);
          var step;

          while (!(step = iterator.next()).done) {
            if (isValidElement(step.value)) {
              validateExplicitKey(step.value, parentType);
            }
          }
        }
      }
    }
  }
}
/**
 * Given an element, validate that its props follow the propTypes definition,
 * provided by the type.
 *
 * @param {ReactElement} element
 */


function validatePropTypes(element) {
  {
    var type = element.type;

    if (type === null || type === undefined || typeof type === 'string') {
      return;
    }

    var propTypes;

    if (typeof type === 'function') {
      propTypes = type.propTypes;
    } else if (typeof type === 'object' && (type.$$typeof === REACT_FORWARD_REF_TYPE || // Note: Memo only checks outer props here.
    // Inner props are checked in the reconciler.
    type.$$typeof === REACT_MEMO_TYPE)) {
      propTypes = type.propTypes;
    } else {
      return;
    }

    if (propTypes) {
      // Intentionally inside to avoid triggering lazy initializers:
      var name = getComponentName(type);
      checkPropTypes(propTypes, element.props, 'prop', name, element);
    } else if (type.PropTypes !== undefined && !propTypesMisspellWarningShown) {
      propTypesMisspellWarningShown = true; // Intentionally inside to avoid triggering lazy initializers:

      var _name = getComponentName(type);

      error('Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?', _name || 'Unknown');
    }

    if (typeof type.getDefaultProps === 'function' && !type.getDefaultProps.isReactClassApproved) {
      error('getDefaultProps is only used on classic React.createClass ' + 'definitions. Use a static property named `defaultProps` instead.');
    }
  }
}
/**
 * Given a fragment, validate that it can only be provided with fragment props
 * @param {ReactElement} fragment
 */


function validateFragmentProps(fragment) {
  {
    var keys = Object.keys(fragment.props);

    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];

      if (key !== 'children' && key !== 'key') {
        setCurrentlyValidatingElement$1(fragment);

        error('Invalid prop `%s` supplied to `React.Fragment`. ' + 'React.Fragment can only have `key` and `children` props.', key);

        setCurrentlyValidatingElement$1(null);
        break;
      }
    }

    if (fragment.ref !== null) {
      setCurrentlyValidatingElement$1(fragment);

      error('Invalid attribute `ref` supplied to `React.Fragment`.');

      setCurrentlyValidatingElement$1(null);
    }
  }
}

function jsxWithValidation(type, props, key, isStaticChildren, source, self) {
  {
    var validType = isValidElementType(type); // We warn in this case but don't throw. We expect the element creation to
    // succeed and there will likely be errors in render.

    if (!validType) {
      var info = '';

      if (type === undefined || typeof type === 'object' && type !== null && Object.keys(type).length === 0) {
        info += ' You likely forgot to export your component from the file ' + "it's defined in, or you might have mixed up default and named imports.";
      }

      var sourceInfo = getSourceInfoErrorAddendum(source);

      if (sourceInfo) {
        info += sourceInfo;
      } else {
        info += getDeclarationErrorAddendum();
      }

      var typeString;

      if (type === null) {
        typeString = 'null';
      } else if (Array.isArray(type)) {
        typeString = 'array';
      } else if (type !== undefined && type.$$typeof === REACT_ELEMENT_TYPE) {
        typeString = "<" + (getComponentName(type.type) || 'Unknown') + " />";
        info = ' Did you accidentally export a JSX literal instead of a component?';
      } else {
        typeString = typeof type;
      }

      error('React.jsx: type is invalid -- expected a string (for ' + 'built-in components) or a class/function (for composite ' + 'components) but got: %s.%s', typeString, info);
    }

    var element = jsxDEV(type, props, key, source, self); // The result can be nullish if a mock or a custom function is used.
    // TODO: Drop this when these are no longer allowed as the type argument.

    if (element == null) {
      return element;
    } // Skip key warning if the type isn't valid since our key validation logic
    // doesn't expect a non-string/function type and can throw confusing errors.
    // We don't want exception behavior to differ between dev and prod.
    // (Rendering will throw with a helpful message and as soon as the type is
    // fixed, the key warnings will appear.)


    if (validType) {
      var children = props.children;

      if (children !== undefined) {
        if (isStaticChildren) {
          if (Array.isArray(children)) {
            for (var i = 0; i < children.length; i++) {
              validateChildKeys(children[i], type);
            }

            if (Object.freeze) {
              Object.freeze(children);
            }
          } else {
            error('React.jsx: Static children should always be an array. ' + 'You are likely explicitly calling React.jsxs or React.jsxDEV. ' + 'Use the Babel transform instead.');
          }
        } else {
          validateChildKeys(children, type);
        }
      }
    }

    if (type === exports.Fragment) {
      validateFragmentProps(element);
    } else {
      validatePropTypes(element);
    }

    return element;
  }
} // These two functions exist to still get child warnings in dev
// even with the prod transform. This means that jsxDEV is purely
// opt-in behavior for better messages but that we won't stop
// giving you warnings if you use production apis.

function jsxWithValidationStatic(type, props, key) {
  {
    return jsxWithValidation(type, props, key, true);
  }
}
function jsxWithValidationDynamic(type, props, key) {
  {
    return jsxWithValidation(type, props, key, false);
  }
}

var jsx =  jsxWithValidationDynamic ; // we may want to special case jsxs internally to take advantage of static children.
// for now we can ship identical prod functions

var jsxs =  jsxWithValidationStatic ;

exports.jsx = jsx;
exports.jsxs = jsxs;
  })();
}


/***/ }),

/***/ 7613:
/*!*******************************************!*\
  !*** ./node_modules/react/jsx-runtime.js ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-jsx-runtime.development.js */ 2943);
}


/***/ }),

/***/ 8436:
/*!********************************************************!*\
  !*** ./node_modules/use-debounce/dist/index.module.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useDebounce: () => (/* binding */ l)
/* harmony export */ });
/* unused harmony exports useDebouncedCallback, useThrottledCallback */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
function c(e,u,c,i){var l=this,a=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null),o=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(0),f=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(0),v=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null),d=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]),s=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(),m=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(),h=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(e),g=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(!0),x=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(),E=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();h.current=e;var b="undefined"!=typeof window,p=!u&&0!==u&&b;if("function"!=typeof e)throw new TypeError("Expected a function");u=+u||0;var y=!!(c=c||{}).leading,w=!("trailing"in c)||!!c.trailing,T=!!c.flushOnExit&&w,O="maxWait"in c,F="debounceOnServer"in c&&!!c.debounceOnServer,L=O?Math.max(+c.maxWait||0,u):null,A=(0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function(){var r=function(r){var n=d.current,t=s.current;return d.current=s.current=null,o.current=r,f.current=f.current||r,m.current=h.current.apply(t,n)},n=function(r,n){p&&cancelAnimationFrame(v.current),v.current=p?requestAnimationFrame(r):setTimeout(r,n)},t=function(r){if(!g.current)return!1;var n=r-a.current;return!a.current||n>=u||n<0||O&&r-o.current>=L},e=function(n){return v.current=null,w&&d.current?r(n):(d.current=s.current=null,m.current)},c=function r(){var c=Date.now();if(y&&f.current===o.current&&A(),t(c))return e(c);if(g.current){var i=u-(c-a.current),l=O?Math.min(i,L-(c-o.current)):i;n(r,l)}},A=function(){i&&i({})},D=function(){if(b||F){var e,i=Date.now(),f=t(i);if(d.current=[].slice.call(arguments),s.current=l,a.current=i,T&&!x.current&&(x.current=function(){var r;"hidden"===(null==(r=globalThis.document)?void 0:r.visibilityState)&&E.current.flush()},null==(e=globalThis.document)||null==e.addEventListener||e.addEventListener("visibilitychange",x.current)),f){if(!v.current&&g.current)return o.current=a.current,n(c,u),y?r(a.current):m.current;if(O)return n(c,u),r(a.current)}return v.current||n(c,u),m.current}};return D.cancel=function(){var r=v.current;r&&(p?cancelAnimationFrame(v.current):clearTimeout(v.current)),o.current=0,d.current=a.current=s.current=v.current=null,r&&i&&i({})},D.isPending=function(){return!!v.current},D.flush=function(){return v.current?e(Date.now()):m.current},D},[y,O,u,L,w,T,p,b,F,i]);return E.current=A,(0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function(){return g.current=!0,function(){var r;T&&E.current.flush(),x.current&&(null==(r=globalThis.document)||null==r.removeEventListener||r.removeEventListener("visibilitychange",x.current),x.current=null),g.current=!1}},[T]),A}function i(r,n){return r===n}function l(n,t,l){var a=l&&l.equalityFn||i,o=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(n),f=(0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({})[1],v=c((0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(r){o.current=r,f({})},[f]),t,l,f),d=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(n);return a(d.current,n)||(v(n),d.current=n),[o.current,v]}function a(r,n,t){var e=void 0===t?{}:t,u=e.leading,i=e.trailing,l=e.flushOnExit;return c(r,n,{maxWait:n,leading:void 0===u||u,trailing:void 0===i||i,flushOnExit:void 0!==l&&l})}


/***/ }),

/***/ 2162:
/*!**********************************************************************************************!*\
  !*** ./node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/**
 * @license React
 * use-sync-external-store-shim.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */


 true &&
  (function () {
    function is(x, y) {
      return (x === y && (0 !== x || 1 / x === 1 / y)) || (x !== x && y !== y);
    }
    function useSyncExternalStore$2(subscribe, getSnapshot) {
      didWarnOld18Alpha ||
        void 0 === React.startTransition ||
        ((didWarnOld18Alpha = !0),
        console.error(
          "You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."
        ));
      var value = getSnapshot();
      if (!didWarnUncachedGetSnapshot) {
        var cachedValue = getSnapshot();
        objectIs(value, cachedValue) ||
          (console.error(
            "The result of getSnapshot should be cached to avoid an infinite loop"
          ),
          (didWarnUncachedGetSnapshot = !0));
      }
      cachedValue = useState({
        inst: { value: value, getSnapshot: getSnapshot }
      });
      var inst = cachedValue[0].inst,
        forceUpdate = cachedValue[1];
      useLayoutEffect(
        function () {
          inst.value = value;
          inst.getSnapshot = getSnapshot;
          checkIfSnapshotChanged(inst) && forceUpdate({ inst: inst });
        },
        [subscribe, value, getSnapshot]
      );
      useEffect(
        function () {
          checkIfSnapshotChanged(inst) && forceUpdate({ inst: inst });
          return subscribe(function () {
            checkIfSnapshotChanged(inst) && forceUpdate({ inst: inst });
          });
        },
        [subscribe]
      );
      useDebugValue(value);
      return value;
    }
    function checkIfSnapshotChanged(inst) {
      var latestGetSnapshot = inst.getSnapshot;
      inst = inst.value;
      try {
        var nextValue = latestGetSnapshot();
        return !objectIs(inst, nextValue);
      } catch (error) {
        return !0;
      }
    }
    function useSyncExternalStore$1(subscribe, getSnapshot) {
      return getSnapshot();
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ &&
      "function" ===
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart &&
      __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var React = __webpack_require__(/*! react */ 2650),
      objectIs = "function" === typeof Object.is ? Object.is : is,
      useState = React.useState,
      useEffect = React.useEffect,
      useLayoutEffect = React.useLayoutEffect,
      useDebugValue = React.useDebugValue,
      didWarnOld18Alpha = !1,
      didWarnUncachedGetSnapshot = !1,
      shim =
        "undefined" === typeof window ||
        "undefined" === typeof window.document ||
        "undefined" === typeof window.document.createElement
          ? useSyncExternalStore$1
          : useSyncExternalStore$2;
    exports.useSyncExternalStore =
      void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ &&
      "function" ===
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop &&
      __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  })();


/***/ }),

/***/ 655:
/*!************************************************************************************************************!*\
  !*** ./node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/**
 * @license React
 * use-sync-external-store-shim/with-selector.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */


 true &&
  (function () {
    function is(x, y) {
      return (x === y && (0 !== x || 1 / x === 1 / y)) || (x !== x && y !== y);
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ &&
      "function" ===
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart &&
      __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var React = __webpack_require__(/*! react */ 2650),
      shim = __webpack_require__(/*! use-sync-external-store/shim */ 7741),
      objectIs = "function" === typeof Object.is ? Object.is : is,
      useSyncExternalStore = shim.useSyncExternalStore,
      useRef = React.useRef,
      useEffect = React.useEffect,
      useMemo = React.useMemo,
      useDebugValue = React.useDebugValue;
    exports.useSyncExternalStoreWithSelector = function (
      subscribe,
      getSnapshot,
      getServerSnapshot,
      selector,
      isEqual
    ) {
      var instRef = useRef(null);
      if (null === instRef.current) {
        var inst = { hasValue: !1, value: null };
        instRef.current = inst;
      } else inst = instRef.current;
      instRef = useMemo(
        function () {
          function memoizedSelector(nextSnapshot) {
            if (!hasMemo) {
              hasMemo = !0;
              memoizedSnapshot = nextSnapshot;
              nextSnapshot = selector(nextSnapshot);
              if (void 0 !== isEqual && inst.hasValue) {
                var currentSelection = inst.value;
                if (isEqual(currentSelection, nextSnapshot))
                  return (memoizedSelection = currentSelection);
              }
              return (memoizedSelection = nextSnapshot);
            }
            currentSelection = memoizedSelection;
            if (objectIs(memoizedSnapshot, nextSnapshot))
              return currentSelection;
            var nextSelection = selector(nextSnapshot);
            if (void 0 !== isEqual && isEqual(currentSelection, nextSelection))
              return (memoizedSnapshot = nextSnapshot), currentSelection;
            memoizedSnapshot = nextSnapshot;
            return (memoizedSelection = nextSelection);
          }
          var hasMemo = !1,
            memoizedSnapshot,
            memoizedSelection,
            maybeGetServerSnapshot =
              void 0 === getServerSnapshot ? null : getServerSnapshot;
          return [
            function () {
              return memoizedSelector(getSnapshot());
            },
            null === maybeGetServerSnapshot
              ? void 0
              : function () {
                  return memoizedSelector(maybeGetServerSnapshot());
                }
          ];
        },
        [getSnapshot, getServerSnapshot, selector, isEqual]
      );
      var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
      useEffect(
        function () {
          inst.hasValue = !0;
          inst.value = value;
        },
        [value]
      );
      useDebugValue(value);
      return value;
    };
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ &&
      "function" ===
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop &&
      __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  })();


/***/ }),

/***/ 7741:
/*!************************************************************!*\
  !*** ./node_modules/use-sync-external-store/shim/index.js ***!
  \************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ../cjs/use-sync-external-store-shim.development.js */ 2162);
}


/***/ }),

/***/ 1363:
/*!********************************************************************!*\
  !*** ./node_modules/use-sync-external-store/shim/with-selector.js ***!
  \********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ../cjs/use-sync-external-store-shim/with-selector.development.js */ 655);
}


/***/ }),

/***/ 3126:
/*!***********************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/Assets/moreyeahLogo.png ***!
  \***********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "moreyeahLogo_1be10596e823a299736b.png";

/***/ }),

/***/ 8023:
/*!*************************************************!*\
  !*** external "@microsoft/sp-application-base" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = __WEBPACK_EXTERNAL_MODULE__8023__;

/***/ }),

/***/ 2650:
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = __WEBPACK_EXTERNAL_MODULE__2650__;

/***/ }),

/***/ 2729:
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = __WEBPACK_EXTERNAL_MODULE__2729__;

/***/ }),

/***/ 3445:
/*!********************************************!*\
  !*** ./node_modules/zustand/esm/index.mjs ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   create: () => (/* binding */ create)
/* harmony export */ });
/* unused harmony exports default, useStore */
/* harmony import */ var zustand_vanilla__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! zustand/vanilla */ 3973);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var use_sync_external_store_shim_with_selector_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! use-sync-external-store/shim/with-selector.js */ 1363);





const { useDebugValue } = react__WEBPACK_IMPORTED_MODULE_0__;
const { useSyncExternalStoreWithSelector } = use_sync_external_store_shim_with_selector_js__WEBPACK_IMPORTED_MODULE_1__;
let didWarnAboutEqualityFn = false;
const identity = (arg) => arg;
function useStore(api, selector = identity, equalityFn) {
  if (( false ? 0 : void 0) !== "production" && equalityFn && !didWarnAboutEqualityFn) {
    console.warn(
      "[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"
    );
    didWarnAboutEqualityFn = true;
  }
  const slice = useSyncExternalStoreWithSelector(
    api.subscribe,
    api.getState,
    api.getServerState || api.getInitialState,
    selector,
    equalityFn
  );
  useDebugValue(slice);
  return slice;
}
const createImpl = (createState) => {
  if (( false ? 0 : void 0) !== "production" && typeof createState !== "function") {
    console.warn(
      "[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`."
    );
  }
  const api = typeof createState === "function" ? (0,zustand_vanilla__WEBPACK_IMPORTED_MODULE_2__.createStore)(createState) : createState;
  const useBoundStore = (selector, equalityFn) => useStore(api, selector, equalityFn);
  Object.assign(useBoundStore, api);
  return useBoundStore;
};
const create = (createState) => createState ? createImpl(createState) : createImpl;
var react = (createState) => {
  if (( false ? 0 : void 0) !== "production") {
    console.warn(
      "[DEPRECATED] Default export is deprecated. Instead use `import { create } from 'zustand'`."
    );
  }
  return create(createState);
};




/***/ }),

/***/ 782:
/*!*************************************************!*\
  !*** ./node_modules/zustand/esm/middleware.mjs ***!
  \*************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   persist: () => (/* binding */ persist)
/* harmony export */ });
/* unused harmony exports combine, createJSONStorage, devtools, redux, subscribeWithSelector */
const reduxImpl = (reducer, initial) => (set, _get, api) => {
  api.dispatch = (action) => {
    set((state) => reducer(state, action), false, action);
    return action;
  };
  api.dispatchFromDevtools = true;
  return { dispatch: (...a) => api.dispatch(...a), ...initial };
};
const redux = reduxImpl;

const trackedConnections = /* @__PURE__ */ new Map();
const getTrackedConnectionState = (name) => {
  const api = trackedConnections.get(name);
  if (!api) return {};
  return Object.fromEntries(
    Object.entries(api.stores).map(([key, api2]) => [key, api2.getState()])
  );
};
const extractConnectionInformation = (store, extensionConnector, options) => {
  if (store === void 0) {
    return {
      type: "untracked",
      connection: extensionConnector.connect(options)
    };
  }
  const existingConnection = trackedConnections.get(options.name);
  if (existingConnection) {
    return { type: "tracked", store, ...existingConnection };
  }
  const newConnection = {
    connection: extensionConnector.connect(options),
    stores: {}
  };
  trackedConnections.set(options.name, newConnection);
  return { type: "tracked", store, ...newConnection };
};
const devtoolsImpl = (fn, devtoolsOptions = {}) => (set, get, api) => {
  const { enabled, anonymousActionType, store, ...options } = devtoolsOptions;
  let extensionConnector;
  try {
    extensionConnector = (enabled != null ? enabled : ( false ? 0 : void 0) !== "production") && window.__REDUX_DEVTOOLS_EXTENSION__;
  } catch (_e) {
  }
  if (!extensionConnector) {
    if (( false ? 0 : void 0) !== "production" && enabled) {
      console.warn(
        "[zustand devtools middleware] Please install/enable Redux devtools extension"
      );
    }
    return fn(set, get, api);
  }
  const { connection, ...connectionInformation } = extractConnectionInformation(store, extensionConnector, options);
  let isRecording = true;
  api.setState = (state, replace, nameOrAction) => {
    const r = set(state, replace);
    if (!isRecording) return r;
    const action = nameOrAction === void 0 ? { type: anonymousActionType || "anonymous" } : typeof nameOrAction === "string" ? { type: nameOrAction } : nameOrAction;
    if (store === void 0) {
      connection == null ? void 0 : connection.send(action, get());
      return r;
    }
    connection == null ? void 0 : connection.send(
      {
        ...action,
        type: `${store}/${action.type}`
      },
      {
        ...getTrackedConnectionState(options.name),
        [store]: api.getState()
      }
    );
    return r;
  };
  const setStateFromDevtools = (...a) => {
    const originalIsRecording = isRecording;
    isRecording = false;
    set(...a);
    isRecording = originalIsRecording;
  };
  const initialState = fn(api.setState, get, api);
  if (connectionInformation.type === "untracked") {
    connection == null ? void 0 : connection.init(initialState);
  } else {
    connectionInformation.stores[connectionInformation.store] = api;
    connection == null ? void 0 : connection.init(
      Object.fromEntries(
        Object.entries(connectionInformation.stores).map(([key, store2]) => [
          key,
          key === connectionInformation.store ? initialState : store2.getState()
        ])
      )
    );
  }
  if (api.dispatchFromDevtools && typeof api.dispatch === "function") {
    let didWarnAboutReservedActionType = false;
    const originalDispatch = api.dispatch;
    api.dispatch = (...a) => {
      if (( false ? 0 : void 0) !== "production" && a[0].type === "__setState" && !didWarnAboutReservedActionType) {
        console.warn(
          '[zustand devtools middleware] "__setState" action type is reserved to set state from the devtools. Avoid using it.'
        );
        didWarnAboutReservedActionType = true;
      }
      originalDispatch(...a);
    };
  }
  connection.subscribe((message) => {
    var _a;
    switch (message.type) {
      case "ACTION":
        if (typeof message.payload !== "string") {
          console.error(
            "[zustand devtools middleware] Unsupported action format"
          );
          return;
        }
        return parseJsonThen(
          message.payload,
          (action) => {
            if (action.type === "__setState") {
              if (store === void 0) {
                setStateFromDevtools(action.state);
                return;
              }
              if (Object.keys(action.state).length !== 1) {
                console.error(
                  `
                    [zustand devtools middleware] Unsupported __setState action format. 
                    When using 'store' option in devtools(), the 'state' should have only one key, which is a value of 'store' that was passed in devtools(),
                    and value of this only key should be a state object. Example: { "type": "__setState", "state": { "abc123Store": { "foo": "bar" } } }
                    `
                );
              }
              const stateFromDevtools = action.state[store];
              if (stateFromDevtools === void 0 || stateFromDevtools === null) {
                return;
              }
              if (JSON.stringify(api.getState()) !== JSON.stringify(stateFromDevtools)) {
                setStateFromDevtools(stateFromDevtools);
              }
              return;
            }
            if (!api.dispatchFromDevtools) return;
            if (typeof api.dispatch !== "function") return;
            api.dispatch(action);
          }
        );
      case "DISPATCH":
        switch (message.payload.type) {
          case "RESET":
            setStateFromDevtools(initialState);
            if (store === void 0) {
              return connection == null ? void 0 : connection.init(api.getState());
            }
            return connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
          case "COMMIT":
            if (store === void 0) {
              connection == null ? void 0 : connection.init(api.getState());
              return;
            }
            return connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
          case "ROLLBACK":
            return parseJsonThen(message.state, (state) => {
              if (store === void 0) {
                setStateFromDevtools(state);
                connection == null ? void 0 : connection.init(api.getState());
                return;
              }
              setStateFromDevtools(state[store]);
              connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
            });
          case "JUMP_TO_STATE":
          case "JUMP_TO_ACTION":
            return parseJsonThen(message.state, (state) => {
              if (store === void 0) {
                setStateFromDevtools(state);
                return;
              }
              if (JSON.stringify(api.getState()) !== JSON.stringify(state[store])) {
                setStateFromDevtools(state[store]);
              }
            });
          case "IMPORT_STATE": {
            const { nextLiftedState } = message.payload;
            const lastComputedState = (_a = nextLiftedState.computedStates.slice(-1)[0]) == null ? void 0 : _a.state;
            if (!lastComputedState) return;
            if (store === void 0) {
              setStateFromDevtools(lastComputedState);
            } else {
              setStateFromDevtools(lastComputedState[store]);
            }
            connection == null ? void 0 : connection.send(
              null,
              // FIXME no-any
              nextLiftedState
            );
            return;
          }
          case "PAUSE_RECORDING":
            return isRecording = !isRecording;
        }
        return;
    }
  });
  return initialState;
};
const devtools = devtoolsImpl;
const parseJsonThen = (stringified, f) => {
  let parsed;
  try {
    parsed = JSON.parse(stringified);
  } catch (e) {
    console.error(
      "[zustand devtools middleware] Could not parse the received json",
      e
    );
  }
  if (parsed !== void 0) f(parsed);
};

const subscribeWithSelectorImpl = (fn) => (set, get, api) => {
  const origSubscribe = api.subscribe;
  api.subscribe = (selector, optListener, options) => {
    let listener = selector;
    if (optListener) {
      const equalityFn = (options == null ? void 0 : options.equalityFn) || Object.is;
      let currentSlice = selector(api.getState());
      listener = (state) => {
        const nextSlice = selector(state);
        if (!equalityFn(currentSlice, nextSlice)) {
          const previousSlice = currentSlice;
          optListener(currentSlice = nextSlice, previousSlice);
        }
      };
      if (options == null ? void 0 : options.fireImmediately) {
        optListener(currentSlice, currentSlice);
      }
    }
    return origSubscribe(listener);
  };
  const initialState = fn(set, get, api);
  return initialState;
};
const subscribeWithSelector = subscribeWithSelectorImpl;

const combine = (initialState, create) => (...a) => Object.assign({}, initialState, create(...a));

function createJSONStorage(getStorage, options) {
  let storage;
  try {
    storage = getStorage();
  } catch (_e) {
    return;
  }
  const persistStorage = {
    getItem: (name) => {
      var _a;
      const parse = (str2) => {
        if (str2 === null) {
          return null;
        }
        return JSON.parse(str2, options == null ? void 0 : options.reviver);
      };
      const str = (_a = storage.getItem(name)) != null ? _a : null;
      if (str instanceof Promise) {
        return str.then(parse);
      }
      return parse(str);
    },
    setItem: (name, newValue) => storage.setItem(
      name,
      JSON.stringify(newValue, options == null ? void 0 : options.replacer)
    ),
    removeItem: (name) => storage.removeItem(name)
  };
  return persistStorage;
}
const toThenable = (fn) => (input) => {
  try {
    const result = fn(input);
    if (result instanceof Promise) {
      return result;
    }
    return {
      then(onFulfilled) {
        return toThenable(onFulfilled)(result);
      },
      catch(_onRejected) {
        return this;
      }
    };
  } catch (e) {
    return {
      then(_onFulfilled) {
        return this;
      },
      catch(onRejected) {
        return toThenable(onRejected)(e);
      }
    };
  }
};
const oldImpl = (config, baseOptions) => (set, get, api) => {
  let options = {
    getStorage: () => localStorage,
    serialize: JSON.stringify,
    deserialize: JSON.parse,
    partialize: (state) => state,
    version: 0,
    merge: (persistedState, currentState) => ({
      ...currentState,
      ...persistedState
    }),
    ...baseOptions
  };
  let hasHydrated = false;
  const hydrationListeners = /* @__PURE__ */ new Set();
  const finishHydrationListeners = /* @__PURE__ */ new Set();
  let storage;
  try {
    storage = options.getStorage();
  } catch (_e) {
  }
  if (!storage) {
    return config(
      (...args) => {
        console.warn(
          `[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`
        );
        set(...args);
      },
      get,
      api
    );
  }
  const thenableSerialize = toThenable(options.serialize);
  const setItem = () => {
    const state = options.partialize({ ...get() });
    let errorInSync;
    const thenable = thenableSerialize({ state, version: options.version }).then(
      (serializedValue) => storage.setItem(options.name, serializedValue)
    ).catch((e) => {
      errorInSync = e;
    });
    if (errorInSync) {
      throw errorInSync;
    }
    return thenable;
  };
  const savedSetState = api.setState;
  api.setState = (state, replace) => {
    savedSetState(state, replace);
    void setItem();
  };
  const configResult = config(
    (...args) => {
      set(...args);
      void setItem();
    },
    get,
    api
  );
  let stateFromStorage;
  const hydrate = () => {
    var _a;
    if (!storage) return;
    hasHydrated = false;
    hydrationListeners.forEach((cb) => cb(get()));
    const postRehydrationCallback = ((_a = options.onRehydrateStorage) == null ? void 0 : _a.call(options, get())) || void 0;
    return toThenable(storage.getItem.bind(storage))(options.name).then((storageValue) => {
      if (storageValue) {
        return options.deserialize(storageValue);
      }
    }).then((deserializedStorageValue) => {
      if (deserializedStorageValue) {
        if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
          if (options.migrate) {
            return options.migrate(
              deserializedStorageValue.state,
              deserializedStorageValue.version
            );
          }
          console.error(
            `State loaded from storage couldn't be migrated since no migrate function was provided`
          );
        } else {
          return deserializedStorageValue.state;
        }
      }
    }).then((migratedState) => {
      var _a2;
      stateFromStorage = options.merge(
        migratedState,
        (_a2 = get()) != null ? _a2 : configResult
      );
      set(stateFromStorage, true);
      return setItem();
    }).then(() => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(stateFromStorage, void 0);
      hasHydrated = true;
      finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
    }).catch((e) => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, e);
    });
  };
  api.persist = {
    setOptions: (newOptions) => {
      options = {
        ...options,
        ...newOptions
      };
      if (newOptions.getStorage) {
        storage = newOptions.getStorage();
      }
    },
    clearStorage: () => {
      storage == null ? void 0 : storage.removeItem(options.name);
    },
    getOptions: () => options,
    rehydrate: () => hydrate(),
    hasHydrated: () => hasHydrated,
    onHydrate: (cb) => {
      hydrationListeners.add(cb);
      return () => {
        hydrationListeners.delete(cb);
      };
    },
    onFinishHydration: (cb) => {
      finishHydrationListeners.add(cb);
      return () => {
        finishHydrationListeners.delete(cb);
      };
    }
  };
  hydrate();
  return stateFromStorage || configResult;
};
const newImpl = (config, baseOptions) => (set, get, api) => {
  let options = {
    storage: createJSONStorage(() => localStorage),
    partialize: (state) => state,
    version: 0,
    merge: (persistedState, currentState) => ({
      ...currentState,
      ...persistedState
    }),
    ...baseOptions
  };
  let hasHydrated = false;
  const hydrationListeners = /* @__PURE__ */ new Set();
  const finishHydrationListeners = /* @__PURE__ */ new Set();
  let storage = options.storage;
  if (!storage) {
    return config(
      (...args) => {
        console.warn(
          `[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`
        );
        set(...args);
      },
      get,
      api
    );
  }
  const setItem = () => {
    const state = options.partialize({ ...get() });
    return storage.setItem(options.name, {
      state,
      version: options.version
    });
  };
  const savedSetState = api.setState;
  api.setState = (state, replace) => {
    savedSetState(state, replace);
    void setItem();
  };
  const configResult = config(
    (...args) => {
      set(...args);
      void setItem();
    },
    get,
    api
  );
  api.getInitialState = () => configResult;
  let stateFromStorage;
  const hydrate = () => {
    var _a, _b;
    if (!storage) return;
    hasHydrated = false;
    hydrationListeners.forEach((cb) => {
      var _a2;
      return cb((_a2 = get()) != null ? _a2 : configResult);
    });
    const postRehydrationCallback = ((_b = options.onRehydrateStorage) == null ? void 0 : _b.call(options, (_a = get()) != null ? _a : configResult)) || void 0;
    return toThenable(storage.getItem.bind(storage))(options.name).then((deserializedStorageValue) => {
      if (deserializedStorageValue) {
        if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
          if (options.migrate) {
            return [
              true,
              options.migrate(
                deserializedStorageValue.state,
                deserializedStorageValue.version
              )
            ];
          }
          console.error(
            `State loaded from storage couldn't be migrated since no migrate function was provided`
          );
        } else {
          return [false, deserializedStorageValue.state];
        }
      }
      return [false, void 0];
    }).then((migrationResult) => {
      var _a2;
      const [migrated, migratedState] = migrationResult;
      stateFromStorage = options.merge(
        migratedState,
        (_a2 = get()) != null ? _a2 : configResult
      );
      set(stateFromStorage, true);
      if (migrated) {
        return setItem();
      }
    }).then(() => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(stateFromStorage, void 0);
      stateFromStorage = get();
      hasHydrated = true;
      finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
    }).catch((e) => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, e);
    });
  };
  api.persist = {
    setOptions: (newOptions) => {
      options = {
        ...options,
        ...newOptions
      };
      if (newOptions.storage) {
        storage = newOptions.storage;
      }
    },
    clearStorage: () => {
      storage == null ? void 0 : storage.removeItem(options.name);
    },
    getOptions: () => options,
    rehydrate: () => hydrate(),
    hasHydrated: () => hasHydrated,
    onHydrate: (cb) => {
      hydrationListeners.add(cb);
      return () => {
        hydrationListeners.delete(cb);
      };
    },
    onFinishHydration: (cb) => {
      finishHydrationListeners.add(cb);
      return () => {
        finishHydrationListeners.delete(cb);
      };
    }
  };
  if (!options.skipHydration) {
    hydrate();
  }
  return stateFromStorage || configResult;
};
const persistImpl = (config, baseOptions) => {
  if ("getStorage" in baseOptions || "serialize" in baseOptions || "deserialize" in baseOptions) {
    if (( false ? 0 : void 0) !== "production") {
      console.warn(
        "[DEPRECATED] `getStorage`, `serialize` and `deserialize` options are deprecated. Use `storage` option instead."
      );
    }
    return oldImpl(config, baseOptions);
  }
  return newImpl(config, baseOptions);
};
const persist = persistImpl;




/***/ }),

/***/ 3973:
/*!**********************************************!*\
  !*** ./node_modules/zustand/esm/vanilla.mjs ***!
  \**********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createStore: () => (/* binding */ createStore)
/* harmony export */ });
/* unused harmony export default */
const createStoreImpl = (createState) => {
  let state;
  const listeners = /* @__PURE__ */ new Set();
  const setState = (partial, replace) => {
    const nextState = typeof partial === "function" ? partial(state) : partial;
    if (!Object.is(nextState, state)) {
      const previousState = state;
      state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
      listeners.forEach((listener) => listener(state, previousState));
    }
  };
  const getState = () => state;
  const getInitialState = () => initialState;
  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const destroy = () => {
    if (( false ? 0 : void 0) !== "production") {
      console.warn(
        "[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."
      );
    }
    listeners.clear();
  };
  const api = { setState, getState, getInitialState, subscribe, destroy };
  const initialState = state = createState(setState, getState, api);
  return api;
};
const createStore = (createState) => createState ? createStoreImpl(createState) : createStoreImpl;
var vanilla = (createState) => {
  if (( false ? 0 : void 0) !== "production") {
    console.warn(
      "[DEPRECATED] Default export is deprecated. Instead use import { createStore } from 'zustand/vanilla'."
    );
  }
  return createStore(createState);
};




/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var _publicPath = __RUSHSTACK_CURRENT_SCRIPT__ ? __RUSHSTACK_CURRENT_SCRIPT__.src : '';
/******/ 		__webpack_require__.p = _publicPath.slice(0, _publicPath.lastIndexOf('/') + 1);
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**********************************************************************************************!*\
  !*** ./lib/extensions/globalSearchCustomizer/GlobalSearchCustomizerApplicationCustomizer.js ***!
  \**********************************************************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/sp-application-base */ 8023);
/* harmony import */ var _microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ 2650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ 2729);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_SearchModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/SearchModal */ 9941);
/* harmony import */ var _styles_PremiumSearch_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/PremiumSearch.module.scss */ 545);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();





var GlobalSearchCustomizerApplicationCustomizer = /** @class */ (function (_super) {
    __extends(GlobalSearchCustomizerApplicationCustomizer, _super);
    function GlobalSearchCustomizerApplicationCustomizer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._modalContainer = null;
        _this._observer = null;
        _this._attached = new Set();
        _this._isModalOpen = false;
        return _this;
    }
    GlobalSearchCustomizerApplicationCustomizer.prototype.onInit = function () {
        this._createModalContainer();
        this._interceptSearchBar();
        var wasOpen = sessionStorage.getItem('trivandi_search_modal_open') === 'true';
        if (wasOpen) {
            this._openModal();
        }
        return Promise.resolve();
    };
    GlobalSearchCustomizerApplicationCustomizer.prototype._createModalContainer = function () {
        this._modalContainer = document.createElement('div');
        this._modalContainer.id = 'trivandi-search-root';
        document.body.appendChild(this._modalContainer);
    };
    GlobalSearchCustomizerApplicationCustomizer.prototype._interceptSearchBar = function () {
        var _this = this;
        this._attachListeners();
        this._observer = new MutationObserver(function () {
            _this._attachListeners();
        });
        this._observer.observe(document.body, { childList: true, subtree: true });
    };
    GlobalSearchCustomizerApplicationCustomizer.prototype._attachListeners = function () {
        var _this = this;
        var SELECTORS = [
            '#O365_SearchBoxField',
            '[data-automationid="ShyHeader"] input[type="search"]',
            '[data-automationid="ShyHeader"] input',
            'input[placeholder*="Search"]',
            'input[aria-label*="Search"]',
            '[class*="searchBox"] input',
        ];
        SELECTORS.forEach(function (sel) {
            try {
                document.querySelectorAll(sel).forEach(function (el) {
                    if (_this._attached.has(el))
                        return;
                    _this._attached.add(el);
                    var handler = function (e) {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        if (!_this._isModalOpen)
                            _this._openModal();
                    };
                    el.addEventListener('click', handler, true);
                    el.addEventListener('focus', handler, true);
                });
            }
            catch (_err) { /* ignore */ }
        });
    };
    GlobalSearchCustomizerApplicationCustomizer.prototype._openModal = function () {
        var _this = this;
        if (!this._modalContainer)
            return;
        this._isModalOpen = true;
        sessionStorage.setItem('trivandi_search_modal_open', 'true');
        var element = react__WEBPACK_IMPORTED_MODULE_1__.createElement(_components_SearchModal__WEBPACK_IMPORTED_MODULE_3__["default"], {
            context: this.context,
            isOpen: true,
            onDismiss: function () { return _this._closeModal(); },
        });
        react_dom__WEBPACK_IMPORTED_MODULE_2__.render(element, this._modalContainer);
    };
    GlobalSearchCustomizerApplicationCustomizer.prototype._closeModal = function () {
        if (!this._modalContainer)
            return;
        this._isModalOpen = false;
        sessionStorage.removeItem('trivandi_search_modal_open');
        react_dom__WEBPACK_IMPORTED_MODULE_2__.unmountComponentAtNode(this._modalContainer);
    };
    GlobalSearchCustomizerApplicationCustomizer.prototype.onDispose = function () {
        if (this._observer)
            this._observer.disconnect();
        if (this._modalContainer) {
            react_dom__WEBPACK_IMPORTED_MODULE_2__.unmountComponentAtNode(this._modalContainer);
            this._modalContainer.remove();
        }
    };
    return GlobalSearchCustomizerApplicationCustomizer;
}(_microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_0__.BaseApplicationCustomizer));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalSearchCustomizerApplicationCustomizer);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});})();;
//# sourceMappingURL=global-search-customizer-application-customizer.js.map