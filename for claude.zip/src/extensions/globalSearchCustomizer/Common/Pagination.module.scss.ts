/* tslint:disable */
require("./Pagination.module.css");
const styles = {
  paginationContainer: 'paginationContainer_0ede9947',
  pagination: 'pagination_0ede9947',
  pageItem: 'pageItem_0ede9947',
  pageLink: 'pageLink_0ede9947',
  activePage: 'activePage_0ede9947',
  disabledPage: 'disabledPage_0ede9947'
};

export default styles;
/* tslint:enable */