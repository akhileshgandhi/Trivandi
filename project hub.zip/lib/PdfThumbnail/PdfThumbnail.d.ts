import * as React from "react";
interface PdfThumbnailProps {
    fileUrl: string;
    width?: number;
}
declare const PdfThumbnail: React.FC<PdfThumbnailProps>;
export default PdfThumbnail;
//# sourceMappingURL=PdfThumbnail.d.ts.map