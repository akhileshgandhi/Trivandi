
require("./ImportFromProjectDocsDialog.module.css");
const styles = {
  importDialog: 'importDialog_d5b090c7',
  documentsWrapper: 'documentsWrapper_d5b090c7',
  tabRow: 'tabRow_d5b090c7',
  documentTabs: 'documentTabs_d5b090c7',
  docTab: 'docTab_d5b090c7',
  activeDocTab: 'activeDocTab_d5b090c7',
  breadcrumbHeader: 'breadcrumbHeader_d5b090c7',
  breadcrumbsContainer: 'breadcrumbsContainer_d5b090c7',
  breadcrumb: 'breadcrumb_d5b090c7',
  active: 'active_d5b090c7',
  breadcrumbSeparator: 'breadcrumbSeparator_d5b090c7',
  tableContainer: 'tableContainer_d5b090c7',
  documentsTable: 'documentsTable_d5b090c7',
  tableRow: 'tableRow_d5b090c7',
  selected: 'selected_d5b090c7',
  imported: 'imported_d5b090c7',
  nameCol: 'nameCol_d5b090c7',
  fileIcon: 'fileIcon_d5b090c7',
  fileName: 'fileName_d5b090c7',
  folderName: 'folderName_d5b090c7',
  importedLabel: 'importedLabel_d5b090c7',
  modifiedCol: 'modifiedCol_d5b090c7',
  byCol: 'byCol_d5b090c7',
  sizeCol: 'sizeCol_d5b090c7'
};

export default styles;
