
require("./Documents.module.css");
const styles = {
  documentsWrapper: 'documentsWrapper_8a0932bc',
  tabRow: 'tabRow_8a0932bc',
  documentTabs: 'documentTabs_8a0932bc',
  docTab: 'docTab_8a0932bc',
  activeDocTab: 'activeDocTab_8a0932bc',
  h: 'h_8a0932bc',
  breadcrumbsContainer: 'breadcrumbsContainer_8a0932bc',
  breadcrumb: 'breadcrumb_8a0932bc',
  active: 'active_8a0932bc',
  breadcrumbSeparator: 'breadcrumbSeparator_8a0932bc',
  toolbar: 'toolbar_8a0932bc',
  actionButtons: 'actionButtons_8a0932bc',
  actionButton: 'actionButton_8a0932bc',
  deleteButton: 'deleteButton_8a0932bc',
  newButton: 'newButton_8a0932bc',
  plusIcon: 'plusIcon_8a0932bc',
  tableContainer: 'tableContainer_8a0932bc',
  documentsTable: 'documentsTable_8a0932bc',
  checkboxCol: 'checkboxCol_8a0932bc',
  nameCol: 'nameCol_8a0932bc',
  modifiedCol: 'modifiedCol_8a0932bc',
  byCol: 'byCol_8a0932bc',
  sizeCol: 'sizeCol_8a0932bc',
  tableRow: 'tableRow_8a0932bc',
  fileName: 'fileName_8a0932bc',
  fileIcon: 'fileIcon_8a0932bc',
  noData: 'noData_8a0932bc',
  pageNumbers: 'pageNumbers_8a0932bc',
  pageButton: 'pageButton_8a0932bc'
};

export default styles;
