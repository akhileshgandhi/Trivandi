declare const styles: {
    card: string;
    icon: string;
    iconRight: string;
    iconNoBg: string;
    fileIcon: string;
    invoiceIcon: string;
    cardContent: string;
    timeIcon: string;
    cardDocument: string;
    coloredCard: string;
};
export default styles;
//# sourceMappingURL=Card.module.scss.d.ts.map