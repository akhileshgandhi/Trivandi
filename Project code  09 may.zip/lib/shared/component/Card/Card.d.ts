import React from "react";
interface CardProps {
    key?: React.Key;
    title: string;
    subtitle?: string;
    meta?: string;
    color?: string;
    border?: string;
    isDocument?: boolean;
    iconRight?: boolean;
    hideIcon?: boolean;
    documentType?: "folder" | "book";
    variant?: "template" | "invoice";
    customIcon?: string;
    noIconBg?: boolean;
    onClick?: () => void;
}
declare const Card: React.FC<CardProps>;
export default Card;
//# sourceMappingURL=Card.d.ts.map