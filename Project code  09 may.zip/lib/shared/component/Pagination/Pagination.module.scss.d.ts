declare const styles: {
    paginationContainer: string;
    paginationLeft: string;
    paginationInfo: string;
    pageSizeSelector: string;
    pageSizeDropdown: string;
    paginationControls: string;
    pageNumbers: string;
    pageBtn: string;
    dots: string;
    activePage: string;
};
export default styles;
//# sourceMappingURL=Pagination.module.scss.d.ts.map