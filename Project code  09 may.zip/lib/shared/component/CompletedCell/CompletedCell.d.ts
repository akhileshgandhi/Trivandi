import * as React from "react";
interface CompletedCellProps {
    value: number;
}
declare const CompletedCell: React.FC<CompletedCellProps>;
export default CompletedCell;
//# sourceMappingURL=CompletedCell.d.ts.map