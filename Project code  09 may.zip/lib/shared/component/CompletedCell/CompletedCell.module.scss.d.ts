declare const styles: {
    completedWrapper: string;
    percent: string;
    bar: string;
    fill: string;
    critical: string;
    low: string;
    medium: string;
    high: string;
    complete: string;
};
export default styles;
//# sourceMappingURL=CompletedCell.module.scss.d.ts.map