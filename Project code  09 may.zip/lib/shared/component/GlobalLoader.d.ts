import * as React from "react";
interface GlobalLoaderProps {
    variant?: "overlay" | "content";
}
declare const GlobalLoader: React.FC<GlobalLoaderProps>;
export default GlobalLoader;
//# sourceMappingURL=GlobalLoader.d.ts.map