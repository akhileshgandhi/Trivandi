import * as React from "react";
export interface TableColumn {
    key: string;
    label: string;
    filterable?: boolean;
    filterType?: "search";
    sortable?: boolean;
    render?: (value: any, row: any) => React.ReactNode;
    minWidth?: number | string;
}
interface DataTableProps {
    columns: TableColumn[];
    rows: any[];
    serverSide?: boolean;
    totalItems?: number;
    currentPage?: number;
    pageSize?: number;
    onPageChange?: (page: number) => void;
    sortColumn?: string;
    sortAscending?: boolean;
    onSort?: (columnKey: string, ascending: boolean) => void;
    uniqueValues?: Record<string, string[]>;
    onFilterChange?: (filters: Record<string, string>) => void;
    onDateFilterChange?: (dateFilters: Record<string, {
        from?: string;
        to?: string;
    }>) => void;
    onResetFilters?: () => void;
    showFilterControls?: boolean;
    activeFilters?: Record<string, string>;
    onRowClick?: (row: any) => void;
}
declare const DataTable: React.FC<DataTableProps>;
export default DataTable;
//# sourceMappingURL=DataTable.d.ts.map