import * as React from "react";
import { TableColumn } from "../DataTable/DataTable";
interface TrackerTableProps {
    title: string;
    tabs: string[];
    activeTab: string;
    onTabChange: (tab: string) => void;
    columns: TableColumn[];
    rows: any[];
    showDivider?: boolean;
    showFilterIcon?: boolean;
    onFilterClick?: () => void;
    isFilterActive?: boolean;
    onResetFilters?: () => void;
    activeFilters?: Record<string, string>;
    children?: React.ReactNode;
    onSettingsClick?: () => void;
    onCreateClick?: () => void;
    serverSide?: boolean;
    totalItems?: number;
    currentPage?: number;
    pageSize?: number;
    onPageChange?: (page: number) => void;
    onPageSizeChange?: (pageSize: number) => void;
    uniqueValues?: Record<string, string[]>;
    onFilterChange?: (filters: Record<string, string>) => void;
    onDateFilterChange?: (dateFilters: Record<string, {
        from?: string;
        to?: string;
    }>) => void;
    showFilterControls?: boolean;
    onRowClick?: (row: any) => void;
    tabCounts?: Record<string, number>;
    sortColumn?: string;
    sortAscending?: boolean;
    onSort?: (columnKey: string, ascending: boolean) => void;
    searchTerm?: string;
    onSearch?: (value: string) => void;
    searchPlaceholder?: string;
}
declare const TrackerTable: React.FC<TrackerTableProps>;
export default TrackerTable;
//# sourceMappingURL=TrackerTable.d.ts.map