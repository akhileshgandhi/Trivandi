declare const styles: {
    trackerWrapper: string;
    title: string;
    controls: string;
    withDivider: string;
    tabs: string;
    tab: string;
    activeTab: string;
    tabCount: string;
    filterBtn: string;
    resetBtn: string;
    filterBtnActive: string;
    filterIcon: string;
    outerContainer: string;
    filtersRow: string;
    pagination: string;
    pageInfo: string;
    reset: string;
    createBtn: string;
    searchBox: string;
    searchInput: string;
    searchIcon: string;
    clearSearchBtn: string;
};
export default styles;
//# sourceMappingURL=TrackerTable.module.scss.d.ts.map