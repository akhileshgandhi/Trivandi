declare const styles: {
    hero: string;
    leftSpacing: string;
};
export default styles;
//# sourceMappingURL=Hero.module.scss.d.ts.map