import React from "react";
interface HeroProps {
    title: string;
    subtitle: string;
    bg: string;
}
declare const Hero: React.FC<HeroProps>;
export default Hero;
//# sourceMappingURL=Hero.d.ts.map