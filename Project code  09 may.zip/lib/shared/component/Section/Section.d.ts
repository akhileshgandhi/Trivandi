import React from "react";
interface SectionProps {
    title?: string;
    viewAll?: boolean;
    children: React.ReactNode;
}
declare const Section: React.FC<SectionProps>;
export default Section;
//# sourceMappingURL=Section.d.ts.map