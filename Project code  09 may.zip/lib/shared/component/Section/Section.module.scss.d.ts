declare const styles: {
    sectionHeader: string;
    viewAll: string;
    bgW: string;
};
export default styles;
//# sourceMappingURL=Section.module.scss.d.ts.map