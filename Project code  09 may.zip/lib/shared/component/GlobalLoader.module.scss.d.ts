declare const styles: {
    overlay: string;
    contentWrapper: string;
    saturationLoader: string;
    loaderRing: string;
    saturationSpin: string;
    loaderCore: string;
    saturationPulse: string;
};
export default styles;
//# sourceMappingURL=GlobalLoader.module.scss.d.ts.map