import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { SPFI } from "@pnp/sp/presets/all";
export interface ITeamMember {
    Id?: number;
    Title: string;
    Name: string;
    EmailAddress: string;
    MobileNumber?: string;
    Role: string;
    ProjectId?: string;
    ProjectIdId?: number;
}
/**
 * Initialize the team member service with PnP instance
 */
export declare const initTeamMemberService: (spInstance: SPFI) => void;
/**
 * Get all team members for a specific project
 */
export declare const getTeamMembersByProjectId: (projectId: number) => Promise<ITeamMember[]>;
/**
 * Add a new team member to the project
 */
export declare const addTeamMember: (projectId: number, member: {
    name: string;
    email: string;
    role: string;
    mobileNumber?: string;
}) => Promise<ITeamMember>;
/**
 * Update an existing team member
 */
export declare const updateTeamMember: (itemId: number, updates: Partial<{
    name: string;
    email: string;
    role: string;
}>) => Promise<void>;
/**
 * Delete a team member
 */
export declare const deleteTeamMember: (itemId: number) => Promise<void>;
/**
 * Send invitation email to team member (simulated - you may need to implement actual email sending)
 */
export declare const sendInvitation: (memberEmail: string, memberName: string, projectTitle: string, projectId: string) => Promise<void>;
/**
 * Ensure TeamMember list exists with proper columns
 */
export declare const ensureTeamMemberList: () => Promise<void>;
//# sourceMappingURL=teamMemberService.d.ts.map