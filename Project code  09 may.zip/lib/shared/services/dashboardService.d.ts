import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/items/get-all";
export declare const initDashboardService: (spInstance: SPFI) => void;
export declare const getProjectStats: () => Promise<any>;
export declare const getComplianceItems: () => Promise<any[]>;
export declare const getKeyPeople: () => Promise<any[]>;
export declare const getUpcomingEvents: () => Promise<any[]>;
export declare const getKeyTools: () => Promise<any[]>;
export declare const getChildLinksByParent: (parentName: string) => Promise<Array<{
    name: string;
    url: string;
}>>;
export declare const getQuickLinks: () => Promise<any[]>;
//# sourceMappingURL=dashboardService.d.ts.map