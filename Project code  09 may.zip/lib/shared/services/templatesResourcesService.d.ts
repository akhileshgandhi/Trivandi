import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/items";
import "@pnp/sp/views";
import { IDocumentLibraryResponse, IFolderStructure } from "../interfaces/ITemplatesResourcesInterfaces";
declare global {
    interface String {
        hashCode(): number;
    }
}
export declare const initTemplatesResourcesService: (spInstance: SPFI) => void;
/**
 * Get data from the specific external SharePoint site and folder
 */
export declare const getDataFromExternalSharePointSite: () => Promise<IDocumentLibraryResponse>;
export declare const getTemplatesResourcesData: () => Promise<IDocumentLibraryResponse>;
/**
 * Get complete folder structure with files from SharePoint document library
 */
export declare const getCompletefolderStructure: (libraryName?: string) => Promise<IDocumentLibraryResponse>;
/**
 * Alternative method to get data from the current site's document library
 * Use this if the direct URL approach above doesn't work
 */
export declare const getTemplatesResourcesDataFromCurrentSite: (libraryName?: string) => Promise<IDocumentLibraryResponse>;
/**
 * Get direct download URL for a file
 */
export declare const getFileDownloadUrl: (fileRef: string) => string;
/**
 * Get file preview URL for supported file types
 */
export declare const getFilePreviewUrl: (fileRef: string, fileType: string) => string;
/**
 * Get the direct URL to the external SharePoint Templates folder
 */
export declare const getExternalTemplatesFolderUrl: () => string;
/**
 * Check if the current user has access to the external SharePoint site
 */
export declare const checkExternalSiteAccess: () => Promise<boolean>;
/**
 * Recursively get folder structure from external SharePoint site using REST API
 */
export declare const getExternalFolderStructureRecursiveREST: (siteUrl: string, folderPath: string, folderName: string, level: number) => Promise<IFolderStructure>;
/**
 * Get file category based on file extension
 */
export declare const getFileCategory: (fileType: string) => 'template' | 'resource' | 'other';
/**
 * Get templates and documents from the TemplatesandDocuments list
 */
export declare const getTemplatesAndDocumentsListData: () => Promise<Array<{
    id: string;
    title: string;
    description: string;
    link: string | null;
    hasChildren: boolean;
}>>;
export declare const getTemplatesChildItemsByParent: (parentTitle: string) => Promise<Array<{
    id: string;
    title: string;
    link: string | null;
}>>;
/**
 * Get root folders from a document library with item counts
 */
export declare const getRootFoldersWithCounts: (libraryName?: string) => Promise<Array<{
    id: number;
    name: string;
    itemCount: number;
    modified: string;
    serverRelativeUrl: string;
    color: string;
}>>;
/**
 * Get empty response when no data is found
 */
export declare const getEmptyResponse: () => IDocumentLibraryResponse;
//# sourceMappingURL=templatesResourcesService.d.ts.map