import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
export declare const initLibraryDiscoveryService: (spInstance: SPFI) => void;
/**
 * Find project library by searching for libraries that match the project
 * Searches by Code, Title, or Code-Title combinations
 * Results are cached to avoid repeated API calls
 */
export declare const findProjectLibraryByProject: (projectCode?: string, projectTitle?: string) => Promise<string | null>;
/**
 * Get or construct library name with fallback
 */
export declare const getProjectLibraryName: (projectCode?: string, projectTitle?: string) => Promise<string>;
/**
 * Clear the library cache (useful for testing or refresh scenarios)
 */
export declare const clearLibraryCache: () => void;
export declare const getProjectById: (projectId: any) => Promise<"" | {
    ProjectDocumentsUrl: any;
    BidDocumentsUrl: any;
    ContractsDocumentsUrl: any;
    ProjectTitle: any;
    Code: any;
    Status: any;
    NonCmap: any;
}>;
//# sourceMappingURL=libraryDiscoveryService.d.ts.map