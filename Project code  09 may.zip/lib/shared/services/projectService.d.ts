import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/search";
import { SPFI } from "@pnp/sp/presets/all";
export interface PagedResult<T> {
    items: T[];
    totalCount: number;
}
export interface IDashboardProject {
    Id: number;
    Title: string;
    Company?: string;
    Office?: string;
}
export declare const initializePnP: (context: any) => any;
export declare const initProjectService: (spInstance: SPFI) => void;
/**
 * Default visible columns (ORDER MATTERS)
 */
export declare const DEFAULT_COLUMN_KEYS: string[];
export declare const getProjectColumns: () => Promise<any>;
export declare const enhanceProjectColumns: (columns: any[]) => any[];
export declare const getProjectsByStatus: (status: string) => Promise<any[]>;
/**
 * Fetch a paged list of projects with optional exact-match filters.
 * Returns items mapped to the same row shape and the total count.
 */
export declare const getProjectsPage: (status: string, page: number, pageSize: number, filters?: Record<string, string>, sortColumn?: string, sortAscending?: boolean, searchTerm?: string) => Promise<PagedResult<any>>;
/**
 * Fetch unique values for a column within a status (used to populate filter dropdowns)
 */
export declare const getUniqueValuesForColumn: (status: string, columnKey: string, filters?: Record<string, string>) => Promise<string[]>;
export declare const getProjectById: (id: number) => Promise<any>;
/**
 * Create a new project item in the Projects list
 */
export declare const addProject: (data: Record<string, any>) => Promise<any>;
/**
 * Get documents from a server relative URL directly
 * @param serverRelativeUrl - The full or server relative URL to the folder
 * @param subFolderPath - Optional subfolder navigation within the URL
 */
export declare const getDocumentsByServerRelativeUrl: (serverRelativeUrl: string, subFolderPath?: string, page?: number, pageSize?: number) => Promise<{
    items: any[];
    totalCount: number;
}>;
export declare const getProjectDocuments: (libraryName: string, folderPath?: string, page?: number, pageSize?: number) => Promise<{
    items: any[];
    totalCount: number;
}>;
/**
 * Create folder using server relative URL
 * @param serverRelativeUrl - The full or server relative URL to the parent folder
 * @param folderName - Name of the folder to create
 * @param subFolderPath - Optional subfolder within the URL
 */
export declare const createFolderByServerRelativeUrl: (serverRelativeUrl: string, folderName: string, subFolderPath?: string) => Promise<any>;
/**
 * Ensure folder path exists using server relative URL (creates nested folders if needed)
 * @param serverRelativeUrl - The full or server relative URL to the base folder
 * @param folderPath - The nested folder path to ensure exists
 */
export declare const ensureFolderPathByServerRelativeUrl: (serverRelativeUrl: string, folderPath: string) => Promise<void>;
/**
 * Upload document using server relative URL
 * @param serverRelativeUrl - The full or server relative URL to the folder
 * @param file - The file to upload
 * @param subFolderPath - Optional subfolder within the URL
 */
export declare const uploadDocumentByServerRelativeUrl: (serverRelativeUrl: string, file: File, subFolderPath?: string) => Promise<any>;
/**
 * Upload document with folder creation using server relative URL (for folder uploads)
 * @param serverRelativeUrl - The full or server relative URL to the folder
 * @param file - The file to upload
 * @param subFolderPath - Subfolder path that needs to be created
 */
export declare const uploadDocumentWithFolderCreation: (serverRelativeUrl: string, file: File, subFolderPath: string) => Promise<any>;
/**
 * Delete document using server relative URL
 * @param fileServerRelativeUrl - The full or server relative URL to the file
 */
export declare const deleteDocumentByServerRelativeUrl: (fileServerRelativeUrl: string) => Promise<void>;
export declare const uploadProjectDocument: (libraryName: string, file: File, folderPath?: string) => Promise<any>;
export declare const getProjectsByOwnerAndStatus: (ownerEmail: string, status: "Project" | "Potential" | string[]) => Promise<IDashboardProject[]>;
export declare const getRecentDocuments: (limit?: number) => Promise<any>;
export declare const deleteProjectDocument: (libraryName: string, fileServerRelativeUrl: string) => Promise<void>;
/**
 * Download a document from SharePoint
 * @param fileServerRelativeUrl - The server relative URL of the file
 * @param fileName - The name of the file
 */
export declare const downloadProjectDocument: (fileServerRelativeUrl: string, fileName: string) => Promise<void>;
/**
 * Get the SharePoint request digest for API calls
 * This is needed for POST/DELETE operations
 */
export declare const downloadProjectDocumentBlob: (fileServerRelativeUrl: string, fileName: string) => Promise<void>;
//# sourceMappingURL=projectService.d.ts.map