declare const styles: {};
export default styles;
//# sourceMappingURL=globalcss.scss.d.ts.map