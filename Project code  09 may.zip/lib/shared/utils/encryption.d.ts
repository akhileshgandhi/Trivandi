/**
 * Simple encryption/decryption for IDs in the URL to prevent easy manipulation
 */
/**
 * Encrypts a numeric ID to a Base64 string with a simple salt
 */
export declare const encryptId: (id: string | number) => string;
/**
 * Decrypts a Base64 string back to a numeric ID
 */
export declare const decryptId: (encryptedId: string) => number | null;
//# sourceMappingURL=encryption.d.ts.map