export declare const formatDate: (date: Date | string) => string;
//# sourceMappingURL=dateUtils.d.ts.map