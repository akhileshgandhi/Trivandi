import * as React from "react";
import type { IProjectsProps } from "./IProjectsProps";
import "react-toastify/dist/ReactToastify.css";
import "../../../shared/globalcss/globalcss.scss";
declare const Projects: React.FC<IProjectsProps>;
export default Projects;
//# sourceMappingURL=Projects.d.ts.map