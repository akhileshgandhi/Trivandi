declare const styles: {
    columnPopupOverlay: string;
    columnPopup: string;
    columnList: string;
    popupActions: string;
    columnRow: string;
    columnItem: string;
    reorderBtns: string;
    columnContent: string;
    columnLabel: string;
    dragHandle: string;
    columnPopupHeader: string;
    columnSearch: string;
    availableColumnRow: string;
    pipelineTitle: string;
    availableColumnLabel: string;
};
export default styles;
//# sourceMappingURL=Bids.module.scss.d.ts.map