import * as React from "react";
import type { IBidsProps } from "./IBidsProps";
import "../../../shared/globalcss/globalcss.scss";
declare const Bids: React.FC<IBidsProps>;
export default Bids;
//# sourceMappingURL=Bids.d.ts.map