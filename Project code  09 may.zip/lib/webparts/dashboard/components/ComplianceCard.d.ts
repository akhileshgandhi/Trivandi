import * as React from 'react';
interface ComplianceCardProps {
    title: string;
    description: string;
    color: string;
    icon: string;
    link?: string;
}
declare const ComplianceCard: React.FC<ComplianceCardProps>;
export default ComplianceCard;
//# sourceMappingURL=ComplianceCard.d.ts.map