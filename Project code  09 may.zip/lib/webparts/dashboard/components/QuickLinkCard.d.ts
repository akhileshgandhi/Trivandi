import * as React from 'react';
interface QuickLinkCardProps {
    title: string;
    url: string;
    backgroundColor: string;
    icon: string;
    hasChildren?: boolean;
    fetchChildren?: (parentTitle: string) => Promise<Array<{
        name: string;
        url: string;
    }>>;
}
declare const QuickLinkCard: React.FC<QuickLinkCardProps>;
export default QuickLinkCard;
//# sourceMappingURL=QuickLinkCard.d.ts.map