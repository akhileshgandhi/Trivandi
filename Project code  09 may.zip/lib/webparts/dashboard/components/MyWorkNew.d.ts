/// <reference types="react" />
import '../../../shared/globalcss/globalcss.scss';
declare const MyWorkNew: ({ props }: {
    props: any;
}) => JSX.Element;
export default MyWorkNew;
//# sourceMappingURL=MyWorkNew.d.ts.map