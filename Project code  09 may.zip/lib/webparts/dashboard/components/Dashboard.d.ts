import * as React from 'react';
import type { IDashboardProps } from './IDashboardProps';
import '../../../shared/globalcss/globalcss.scss';
declare const Dashboard: React.FC<IDashboardProps>;
export default Dashboard;
//# sourceMappingURL=Dashboard.d.ts.map