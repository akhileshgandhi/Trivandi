declare const styles: {
    dashboard: string;
    label: string;
    labelLine: string;
    emptyState: string;
    emptyIcon: string;
    emptyText: string;
    topSection: string;
    topSection2: string;
    grid: string;
    gridTwo: string;
    gridFiveSmall: string;
    gridFourLarge: string;
    gridDocuments: string;
    scrollWrapper: string;
    CanvasZoneSectionContainer: string;
};
export default styles;
//# sourceMappingURL=MyWorkNew.module.scss.d.ts.map