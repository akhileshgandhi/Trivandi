import * as React from 'react';
interface KeyPersonCardProps {
    name: string | null;
    title: string | null;
    imageUrl: string | null;
    email: string | null;
    phone: string | null;
}
declare const KeyPersonCard: React.FC<KeyPersonCardProps>;
export default KeyPersonCard;
//# sourceMappingURL=KeyPersonCard.d.ts.map