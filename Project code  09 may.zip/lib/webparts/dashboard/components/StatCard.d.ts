import * as React from 'react';
interface StatCardProps {
    title: string;
    value: number;
    icon: string;
    color: string;
}
declare const StatCard: React.FC<StatCardProps>;
export default StatCard;
//# sourceMappingURL=StatCard.d.ts.map