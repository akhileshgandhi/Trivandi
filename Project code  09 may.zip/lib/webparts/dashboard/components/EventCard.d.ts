import * as React from 'react';
interface EventCardProps {
    title: string;
    date: string;
    time: string;
    day: string;
    month: string;
}
declare const EventCard: React.FC<EventCardProps>;
export default EventCard;
//# sourceMappingURL=EventCard.d.ts.map