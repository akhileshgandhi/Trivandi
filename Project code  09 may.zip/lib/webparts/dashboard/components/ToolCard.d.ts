import * as React from 'react';
interface ToolCardProps {
    title: string;
    description: string;
    color: string;
    icon: string;
    link: string;
}
declare const ToolCard: React.FC<ToolCardProps>;
export default ToolCard;
//# sourceMappingURL=ToolCard.d.ts.map