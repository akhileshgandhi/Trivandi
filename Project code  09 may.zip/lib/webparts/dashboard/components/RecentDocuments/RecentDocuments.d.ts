import * as React from "react";
declare const RecentDocuments: React.FC;
export default RecentDocuments;
//# sourceMappingURL=RecentDocuments.d.ts.map