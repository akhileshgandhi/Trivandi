declare const styles: {
    wrapper: string;
    title: string;
    documentsList: string;
    documentItem: string;
    iconWrapper: string;
    fileIcon: string;
    documentInfo: string;
    fileName: string;
    metadata: string;
    emptyState: string;
};
export default styles;
//# sourceMappingURL=RecentDocuments.module.scss.d.ts.map