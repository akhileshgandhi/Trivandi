import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
import { IExternalUserAccessProps } from "./IExternalUserAccessProps";
declare const ExternalUserAccess: React.FC<IExternalUserAccessProps>;
export default ExternalUserAccess;
//# sourceMappingURL=ExternalUserAccess.d.ts.map