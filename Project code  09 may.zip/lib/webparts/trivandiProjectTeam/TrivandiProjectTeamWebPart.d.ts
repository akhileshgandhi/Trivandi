import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface ITrivandiProjectTeamWebPartProps {
    description: string;
}
export default class TrivandiProjectTeamWebPart extends BaseClientSideWebPart<ITrivandiProjectTeamWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(_: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=TrivandiProjectTeamWebPart.d.ts.map