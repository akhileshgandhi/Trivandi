import * as React from "react";
import { ITrivandiProjectTeamProps } from "./ITrivandiProjectTeamProps";
import "../../../shared/globalcss/globalcss.scss";
declare const TrivandiProjectTeam: React.FC<ITrivandiProjectTeamProps>;
export default TrivandiProjectTeam;
//# sourceMappingURL=TrivandiProjectTeam.d.ts.map