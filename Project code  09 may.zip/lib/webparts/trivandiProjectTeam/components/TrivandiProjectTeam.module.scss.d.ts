declare const styles: {
    dashboard: string;
    label: string;
    labelLine: string;
    topSection: string;
    topSection2: string;
    grid: string;
    gridTwo: string;
    gridFiveSmall: string;
    gridFourLarge: string;
    gridDocuments: string;
    scrollWrapper: string;
    CanvasZoneSectionContainer: string;
};
export default styles;
//# sourceMappingURL=TrivandiProjectTeam.module.scss.d.ts.map