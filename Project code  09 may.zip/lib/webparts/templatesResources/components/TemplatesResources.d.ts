import * as React from "react";
import type { ITemplatesResourcesProps } from "./ITemplatesResourcesProps";
import "../../../shared/globalcss/globalcss.scss";
declare const TemplatesResources: React.FC<ITemplatesResourcesProps>;
export default TemplatesResources;
//# sourceMappingURL=TemplatesResources.d.ts.map