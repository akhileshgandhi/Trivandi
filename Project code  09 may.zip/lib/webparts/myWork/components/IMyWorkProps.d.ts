export interface IMyWorkProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
    siteUrl: string;
}
//# sourceMappingURL=IMyWorkProps.d.ts.map