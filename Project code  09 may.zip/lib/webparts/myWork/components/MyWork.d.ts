import React from 'react';
import { IMyWorkProps } from './IMyWorkProps';
import '../../../shared/globalcss/globalcss.scss';
declare const MyWork: React.FC<IMyWorkProps>;
export default MyWork;
//# sourceMappingURL=MyWork.d.ts.map