declare const styles: {
    dialog: string;
    dialogContent: string;
    field: string;
    infoBox: string;
    infoIcon: string;
    infoText: string;
    errorMessage: string;
    errorIcon: string;
    primaryButton: string;
};
export default styles;
//# sourceMappingURL=InviteGuestDialog.module.scss.d.ts.map