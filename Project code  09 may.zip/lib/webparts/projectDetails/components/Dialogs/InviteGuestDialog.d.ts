import * as React from 'react';
import 'react-toastify/dist/ReactToastify.css';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IInviteGuestDialogProps {
    isOpen: boolean;
    onClose: () => void;
    context: WebPartContext;
    projectId?: string;
    onGuestInvited?: () => void;
}
export interface IInviteGuestDialogState {
    guestName: string;
    guestEmail: string;
    inviting: boolean;
    error?: string;
}
export default class InviteGuestDialog extends React.Component<IInviteGuestDialogProps, IInviteGuestDialogState> {
    private portalService;
    constructor(props: IInviteGuestDialogProps);
    private _onGuestNameChange;
    private _onGuestEmailChange;
    private _validateEmail;
    private inviteExternalUser;
    private _onInviteGuest;
    render(): React.ReactElement<IInviteGuestDialogProps>;
}
//# sourceMappingURL=InviteGuestDialog.d.ts.map