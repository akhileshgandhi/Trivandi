import * as React from 'react';
import 'react-toastify/dist/ReactToastify.css';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ProjectExternalPortalService } from '../../services/ProjectExternalPortalService';
export interface INewDocumentDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    context: WebPartContext;
    currentPath: string;
    service?: ProjectExternalPortalService;
}
export interface ISelectedFile {
    file: File;
    path: string;
    displayName: string;
}
export interface INewDocumentDialogState {
    selectedFiles: ISelectedFile[];
    shareAfterUpload: boolean;
    selectedGuests: string[];
    accessDuration: number;
    customExpiryDate: string;
    uploading: boolean;
    uploadProgress: {
        [fileName: string]: number;
    };
    error?: string;
    success?: string;
    availableGuests: Array<{
        email: string;
        name: string;
    }>;
    loadingGuests: boolean;
}
export default class NewDocumentDialog extends React.Component<INewDocumentDialogProps, INewDocumentDialogState> {
    private portalService;
    private fileInputRef;
    private folderInputRef;
    constructor(props: INewDocumentDialogProps);
    componentDidUpdate(prevProps: INewDocumentDialogProps): void;
    private _loadAvailableGuests;
    private _onFileSelect;
    private _onFolderSelect;
    private _onFileChange;
    private _onFolderChange;
    private _removeFile;
    private _clearAllFiles;
    private _onShareAfterUploadChange;
    private _onGuestToggle;
    private _onAccessDurationChange;
    private _onCustomExpiryDateChange;
    private _onUpload;
    private _resetForm;
    private _onClose;
    render(): React.ReactElement<INewDocumentDialogProps>;
}
//# sourceMappingURL=NewDocumentDialog.d.ts.map