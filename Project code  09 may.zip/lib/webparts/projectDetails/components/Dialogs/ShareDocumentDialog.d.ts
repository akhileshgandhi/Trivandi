import * as React from 'react';
import 'react-toastify/dist/ReactToastify.css';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IShareDocumentDialogProps {
    isOpen: boolean;
    onClose: () => void;
    context: WebPartContext;
    currentPath: string;
}
export interface IShareDocumentDialogState {
    externalSharing: string;
    type: string;
    name: string;
    selectedFile: File | null;
    selectedUsers: string[];
    accessDuration: number;
    uploading: boolean;
    error?: string;
}
export default class ShareDocumentDialog extends React.Component<IShareDocumentDialogProps, IShareDocumentDialogState> {
    private portalService;
    private fileInputRef;
    constructor(props: IShareDocumentDialogProps);
    private _onExternalSharingChange;
    private _onTypeChange;
    private _onNameChange;
    private _onFileSelect;
    private _onFileChange;
    private _onAccessDurationChange;
    private _onUploadAndShare;
    private _onShareAccess;
    render(): React.ReactElement<IShareDocumentDialogProps>;
}
//# sourceMappingURL=ShareDocumentDialog.d.ts.map