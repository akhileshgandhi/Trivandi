import * as React from 'react';
import 'react-toastify/dist/ReactToastify.css';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ProjectExternalPortalService } from '../../services/ProjectExternalPortalService';
import { ISharedDocument } from '../IProjectExternalPortalState';
export interface IShareAccessDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    context: WebPartContext;
    selectedDocuments: ISharedDocument[];
    service?: ProjectExternalPortalService;
}
export interface IShareAccessDialogState {
    activeDocuments: ISharedDocument[];
    autoRemovedDocs: string[];
    selectedGuests: string[];
    searchQuery: string;
    accessDuration: number;
    customExpiryDate: string;
    customExpiryTime: string;
    sharing: boolean;
    checkingConflicts: boolean;
    conflictWarnings: Array<{
        guestEmail: string;
        documentName: string;
        expiresOn: string;
    }>;
    error?: string;
    success?: string;
    availableGuests: Array<{
        email: string;
        name: string;
    }>;
    loadingGuests: boolean;
    azureAdUsers: Array<{
        email: string;
        name: string;
    }>;
    searchingAzureAd: boolean;
    showDurationPresets: boolean;
    selectedPermission: 'Read' | 'Review' | 'Edit' | 'Admin';
}
export default class ShareAccessDialog extends React.Component<IShareAccessDialogProps, IShareAccessDialogState> {
    private portalService;
    constructor(props: IShareAccessDialogProps);
    componentDidUpdate(prevProps: IShareAccessDialogProps): void;
    private _loadAvailableGuests;
    private _onGuestToggle;
    private _onSearchQueryChange;
    private _onAddUserFromSearch;
    /**
     * Re-check conflicts whenever selected guests change.
     * If conflicts found → automatically remove conflicting documents
     * from activeDocuments and show an info banner listing what was removed.
     */
    private _refreshConflicts;
    /** Manual deselect from the document list inside the dialog */
    private _removeDocument;
    private _onAccessDurationChange;
    private _onCustomExpiryDateChange;
    private _onCustomExpiryTimeChange;
    private _getCustomExpiryDateTime;
    private _onPermissionChange;
    private _onShareAccess;
    private _resetForm;
    private _onClose;
    render(): React.ReactElement<IShareAccessDialogProps>;
}
//# sourceMappingURL=ShareAccessDialog.d.ts.map