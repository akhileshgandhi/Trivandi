import * as React from 'react';
import 'react-toastify/dist/ReactToastify.css';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IImportFromProjectDocsDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    context: WebPartContext;
    targetPath: string;
    projectId: string | number;
    projectCode?: string;
    projectTitle?: string;
    service?: any;
}
export interface IProjectDocument {
    Id: number | string;
    FileLeafRef: string;
    FileRef: string;
    Modified: string;
    Editor: {
        Title: string;
    };
    FSObjType: number;
    selected?: boolean;
    isImported?: boolean;
}
declare const ImportFromProjectDocsDialog: React.FC<IImportFromProjectDocsDialogProps>;
export default ImportFromProjectDocsDialog;
//# sourceMappingURL=ImportFromProjectDocsDialog.d.ts.map