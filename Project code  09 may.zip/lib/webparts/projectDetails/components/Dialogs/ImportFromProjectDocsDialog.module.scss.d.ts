declare const styles: {
    importDialog: string;
    documentsWrapper: string;
    tabRow: string;
    documentTabs: string;
    docTab: string;
    activeDocTab: string;
    breadcrumbHeader: string;
    breadcrumbsContainer: string;
    breadcrumb: string;
    active: string;
    breadcrumbSeparator: string;
    tableContainer: string;
    documentsTable: string;
    tableRow: string;
    selected: string;
    imported: string;
    nameCol: string;
    fileIcon: string;
    fileName: string;
    folderName: string;
    importedLabel: string;
    modifiedCol: string;
    byCol: string;
};
export default styles;
//# sourceMappingURL=ImportFromProjectDocsDialog.module.scss.d.ts.map