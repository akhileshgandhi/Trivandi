declare const styles: {
    externalPortal: string;
    header: string;
    headerLeft: string;
    backIcon: string;
    headerInfo: string;
    title: string;
    subtitle: string;
    tabs: string;
    tab: string;
    active: string;
    portalHeaderContainer: string;
    content: string;
    portalHeader: string;
    portalHeaderLeft: string;
    portalIcon: string;
    portalTitle: string;
    inviteButton: string;
    portalDescription: string;
};
export default styles;
//# sourceMappingURL=ProjectExternalPortal.module.scss.d.ts.map