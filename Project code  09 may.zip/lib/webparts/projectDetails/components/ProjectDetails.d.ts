import * as React from "react";
import "react-toastify/dist/ReactToastify.css";
import { IProjectDetailsProps } from "./IProjectDetailsProps";
import "../../../shared/globalcss/globalcss.scss";
declare const ProjectDetails: React.FC<IProjectDetailsProps>;
export default ProjectDetails;
//# sourceMappingURL=ProjectDetails.d.ts.map