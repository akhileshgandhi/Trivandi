declare const styles: {
    modalOverlay: string;
    fadeIn: string;
    modalContent: string;
    slideUp: string;
    modalHeader: string;
    modalTitle: string;
    closeButton: string;
    modalBody: string;
    formGroup: string;
    label: string;
    input: string;
    selectWrapper: string;
    select: string;
    selectIcon: string;
    infoMessage: string;
    errorMessage: string;
    inputWithButton: string;
    actionButtons: string;
    callButton: string;
    copyButton: string;
    copiedToast: string;
    slideUpFadeIn: string;
    modalFooter: string;
    submitButton: string;
};
export default styles;
//# sourceMappingURL=AddTeamMemberModal.module.scss.d.ts.map