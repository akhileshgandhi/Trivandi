import * as React from "react";
import "react-toastify/dist/ReactToastify.css";
interface IAddTeamMemberModalProps {
    isOpen: boolean;
    onClose: () => void;
    onAddMember: (member: {
        name: string;
        email: string;
        role: string;
        mobileNumber: string;
    }) => Promise<void>;
    projectId: any;
    projectCode: string;
    ProjectTitle: string;
}
declare const AddTeamMemberModal: React.FC<IAddTeamMemberModalProps>;
export default AddTeamMemberModal;
//# sourceMappingURL=AddTeamMemberModal.d.ts.map