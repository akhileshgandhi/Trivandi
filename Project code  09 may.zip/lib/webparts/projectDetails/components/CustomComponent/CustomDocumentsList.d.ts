import * as React from "react";
import "react-toastify/dist/ReactToastify.css";
interface IDocumentsProps {
    projectId: number;
    projectCode?: string;
    projectTitle?: string;
    hideNewButton?: boolean;
    onNewClick?: () => void;
}
declare const CustomDocumentsList: React.FC<IDocumentsProps>;
export default CustomDocumentsList;
//# sourceMappingURL=CustomDocumentsList.d.ts.map