import * as React from "react";
interface IFileUploadModalProps {
    isOpen: boolean;
    onClose: () => void;
    onUpload: (file: File, relativePath?: string) => Promise<void>;
    onCreateFolder?: (folderName: string) => Promise<void>;
}
declare const FileUploadModal: React.FC<IFileUploadModalProps>;
export default FileUploadModal;
//# sourceMappingURL=FileUploadModal.d.ts.map