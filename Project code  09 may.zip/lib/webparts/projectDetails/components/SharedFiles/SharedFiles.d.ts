import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ISharedDocument, IBreadcrumb, ISharedFileAccessLog } from '../IProjectExternalPortalState';
import { ProjectExternalPortalService } from '../../services/ProjectExternalPortalService';
export interface ISharedFilesProps {
    context: WebPartContext;
    currentPath: string;
    breadcrumbs: IBreadcrumb[];
    onFolderNavigate: (path: string, breadcrumbs: IBreadcrumb[]) => void;
    onShowNewDocument: () => void;
    onShowShareAccess: (selectedDocs: ISharedDocument[]) => void;
    onShowImportDialog: () => void;
    onRefresh?: () => void;
    service?: ProjectExternalPortalService;
    isUserRestricted?: boolean;
    onFolderChange?: (path: string) => void;
}
export interface ISharedFilesState {
    documents: ISharedDocument[];
    loading: boolean;
    error?: string;
    selectedDocuments: number[];
    selectAll: boolean;
    currentPermission: 'Read' | 'Review' | 'Edit' | 'Admin' | null;
    guestRole: 'Viewer' | 'Editor' | null;
    showLogDialog: boolean;
    loadingLogs: boolean;
    logsError?: string;
    selectedLogDocument?: ISharedDocument;
    accessLogs: ISharedFileAccessLog[];
    totalDocumentsFound?: number;
    accessFilteredCount?: number;
    filePreview: {
        isOpen: boolean;
        fileUrl: string;
        fileName: string;
        filePath?: string;
        canDownload?: boolean;
    };
    pagination: {
        currentPage: number;
        pageSize: number;
        totalItems: number;
        totalPages: number;
    };
}
export default class SharedFiles extends React.Component<ISharedFilesProps, ISharedFilesState> {
    private portalService;
    constructor(props: ISharedFilesProps);
    private _loadDebounceTimer;
    componentDidMount(): void;
    componentDidUpdate(prevProps: ISharedFilesProps): void;
    componentWillUnmount(): void;
    private _loadDocuments;
    refreshDocuments: () => void;
    private handlePageChange;
    private handlePageSizeChange;
    private _onSelectAllChange;
    private _onDocumentSelectChange;
    private _onShareAccessClick;
    private _onBreadcrumbClick;
    private _handleFolderClick;
    private _onFolderClick;
    private _formatDate;
    private _formatExpiry;
    private _onViewLogClick;
    private _closeLogDialog;
    private _openFilePreview;
    private _closeFilePreview;
    render(): React.ReactElement<ISharedFilesProps>;
}
//# sourceMappingURL=SharedFiles.d.ts.map