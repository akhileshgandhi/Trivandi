import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IGuestUser } from '../IProjectExternalPortalState';
export interface IActiveGuestsProps {
    context: WebPartContext;
    projectId?: any;
    refreshTrigger?: number;
    isUserRestricted?: boolean;
}
export interface IActiveGuestsState {
    guests: IGuestUser[];
    loading: boolean;
    reportGenerating: boolean;
    error?: string;
    filePreview: {
        isOpen: boolean;
        fileUrl: string;
        fileName: string;
        filePath?: string;
    };
    guestFiles: {
        [guestEmail: string]: Array<{
            fileName: string;
            filePath: string;
            fileUrl: string;
        }>;
    };
    contextMenu: {
        isVisible: boolean;
        target?: any;
        fileInfo?: {
            fileName: string;
            filePath: string;
            fileUrl: string;
        };
    };
}
declare class ActiveGuestsComponent extends React.Component<IActiveGuestsProps, IActiveGuestsState> {
    private portalService;
    constructor(props: IActiveGuestsProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: IActiveGuestsProps): void;
    refreshGuests: () => void;
    private _loadGuests;
    private _getInitials;
    private _isExpired;
    private _formatExpiryDate;
    private _getTimeAgo;
    private _loadGuestFiles;
    private _constructFileUrl;
    private _openFilePreview;
    private _closeFilePreview;
    private _showContextMenu;
    private _hideContextMenu;
    private _getContextMenuItems;
    private _onManageAccess;
    private _escapeCsvValue;
    private _formatDateForCsv;
    private _downloadAccessReport;
    render(): React.ReactElement<IActiveGuestsProps>;
}
export default ActiveGuestsComponent;
//# sourceMappingURL=ActiveGuests.d.ts.map