import * as React from 'react';
export interface IFilePreviewProps {
    isOpen: boolean;
    onDismiss: () => void;
    fileUrl: string;
    fileName: string;
    filePath?: string;
    siteUrl?: string;
    canDownload?: boolean;
}
export interface IFilePreviewState {
    loading: boolean;
    error?: string;
    fileType?: string;
}
export declare class FilePreview extends React.Component<IFilePreviewProps, IFilePreviewState> {
    constructor(props: IFilePreviewProps);
    private _getFileIconByExtension;
    private _getFileType;
    private _getFileIcon;
    private _buildPreviewUrl;
    private _renderPreviewContent;
    render(): React.ReactElement<IFilePreviewProps>;
}
export default FilePreview;
//# sourceMappingURL=FilePreview.d.ts.map