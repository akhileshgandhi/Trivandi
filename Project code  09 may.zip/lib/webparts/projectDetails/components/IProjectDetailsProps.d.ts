export interface IProjectDetailsProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
}
//# sourceMappingURL=IProjectDetailsProps.d.ts.map