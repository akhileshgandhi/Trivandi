import { WebPartContext } from '@microsoft/sp-webpart-base';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/files';
import '@pnp/sp/folders';
import '@pnp/sp/sharing';
import { ISharedDocument, IGuestUser, IGuestAccessReportEntry, ISharedFileAccessLog } from '../components/IProjectExternalPortalState';
export interface IInviteGuestData {
    name: string;
    email: string;
    company?: string;
    role?: 'Viewer' | 'Editor';
    accessDuration?: number;
    phone?: string;
    projectId?: string;
}
export declare class ProjectExternalPortalService {
    private context;
    private siteUrl;
    private sp;
    private projectLibraryName;
    private externalLibraryName;
    private currentProjectId;
    private cache;
    private pendingRequests;
    private readonly CACHE_DURATION;
    private readonly RETRY_DELAY;
    private readonly MAX_RETRIES;
    private _isRestrictedGuestCache;
    private _isSiteOwnerCache;
    private _libraryCheckCache;
    constructor(context: WebPartContext);
    /**
     * Set the current project ID for scoping all portal operations
     */
    setProjectId(projectId: string | number): void;
    /**
     * Get the project-scoped root folder path (e.g. "Project-1109")
     */
    getProjectFolderPath(): string;
    /**
     * Check if ExternalShareDocument library exists and user has access
     */
    checkExternalLibraryAccess(): Promise<{
        exists: boolean;
        hasAccess: boolean;
        error?: string;
    }>;
    /**
     * Find project library by searching for libraries that match the project
     * Delegates to centralized library discovery service
     */
    findProjectLibrary(projectCode?: string, projectTitle?: string): Promise<string | null>;
    /**
     * Set project library name for external portal operations
     */
    setProjectLibraryName(libraryName: string): void;
    private _toWebRelativePath;
    /**
     * Get cached data or fetch new data
     */
    private _getCachedOrFetch;
    /**
     * Execute function with retry logic for throttle errors
     */
    private _executeWithRetry;
    /**
     * Delay helper for retry logic
     */
    private _delay;
    /**
     * Parse server relative URL to extract site and folder path
     * @param serverRelativeUrl - URL like /sites/sitename/library/folder
     */
    private _parseSiteAndFolder;
    /**
     * Check if a server relative URL is from the current site
     */
    private _isCurrentSiteUrl;
    /**
     * Download file from the correct context (handling both current and external sites)
     */
    private _downloadFileBuffer;
    /**
     * Clear cache for a specific key or all cache
     */
    clearCache(cacheKey?: string): void;
    /**
     * Get shared documents from External_Shared_Area library
     */
    getSharedDocuments(folderPath: string): Promise<ISharedDocument[]>;
    /**
     * Get active guest users (with caching)
     */
    getActiveGuests(projectId?: number, skipCache?: boolean): Promise<IGuestUser[]>;
    /**
     * Get project documents for import
     */
    getProjectDocuments(libraryName: string, folderPath?: string, page?: number, pageSize?: number): Promise<any[]>;
    /**
     * Get project documents and folders for import (with caching)
     * Uses project-specific document library
     */
    getProjectDocumentsForImport(folderPath?: string, page?: number, pageSize?: number): Promise<any[]>;
    /**
     * Get documents from all 3 document types for import (Project, Bid, Contract Documents)
     * This method fetches documents from ProjectDocumentsUrl, BidDocumentsUrl, and ContractsDocumentsUrl
     */
    getAllProjectDocumentsForImport(projectId: string, folderPath?: string, page?: number, pageSize?: number): Promise<any[]>;
    /**
     * Get project by ID
     */
    getProjectById(projectId: string): Promise<any>;
    /**
     * Upload and share a document
     */
    uploadAndShareDocument(targetPath: string, file: File, externalSharing: string, sharedWith: string[], accessDuration: number): Promise<void>;
    /**
     * Upload document without sharing
     */
    uploadDocument(targetPath: string, file: File): Promise<void>;
    /**
     * Share access to existing documents (placeholder)
     */
    shareAccess(documentPath: string, users: string[], accessDuration: number): Promise<void>;
    /**
     * Share document access with specific users
     */
    shareDocumentAccess(fileRef: string, guestEmails: string[], accessDuration: number, customExpiryDate?: Date, permission?: 'Read' | 'Review' | 'Edit' | 'Admin'): Promise<void>;
    /**
     * Share folder access with specific users.
     * Guests who already have active (non-expired) access to this folder OR
     * to any individual file inside it are automatically skipped — no duplicate
     * log entries are created for them.
     */
    shareFolderAccess(folderPath: string, guestEmails: string[], accessDuration: number, customExpiryDate?: Date, permission?: 'Read' | 'Review' | 'Edit' | 'Admin'): Promise<void>;
    /**
     * Returns the lowercase emails (from the supplied list) that already have
     * active, non-expired access to the given folder path OR to any individual
     * file stored under that folder path in SharedDocumentLog.
     */
    private _getGuestsWithActiveAccessToFolder;
    /**
     * Import documents from source library to external library (supports files and folders recursively)
     */
    importDocuments(documents: any[], targetPath: string): Promise<void>;
    /**
     * Helper to import an item (file or folder) recursively
     */
    private _importItemRecursive;
    /**
     * Ensures a full folder path exists in the external library
     */
    ensureFolderPathExists(fullPath: string): Promise<void>;
    /**
     * Add a user (by email) to a named SharePoint site group.
     * Uses PnP ensureUser so it works for both internal and B2B guest accounts.
     */
    addUserToSharePointGroup(userEmail: string, groupName: string): Promise<void>;
    /**
     * Invite guest user
     */
    inviteGuest(guestData: IInviteGuestData): Promise<void>;
    private _logShareActivity;
    /**
     * Get shared documents from ExternalShareDocument library
     */
    /**
     * Get shared documents from ExternalShareDocument library (with caching)
     * This is used for the Documents tab
     * Only returns documents the current user has access to
     * For users in ExternalGuestAccess, only shows documents explicitly shared with them
     */
    getSharedDocumentsFromExternalLibrary(folderPath?: string, page?: number, pageSize?: number): Promise<{
        items: ISharedDocument[];
        totalCount: number;
    }>;
    getSharedDocumentsFromExternalArea(folderPath: string, page?: number, pageSize?: number): Promise<{
        items: ISharedDocument[];
        totalCount: number;
    }>;
    /**
     * Ensure folder exists in ExternalShareDocument library, create if it doesn't exist
     */
    ensureFolderExists(folderPath: string): Promise<void>;
    /**
     * Upload document to ExternalShareDocument library
     */
    uploadToExternalShareDocument(targetPath: string, file: File): Promise<string>;
    /**
     * Check whether a list of guests already have active (non-expired) access to each of the
     * given document paths.  Returns an array of conflict descriptions so the caller can
     * surface a precise error to the user.
     *
     * A conflict exists when the MOST RECENT "Shared" log entry for a (guest, document) pair
     * has a permission AND its access has not yet expired.
     */
    checkExistingActiveAccess(documentPaths: string[], guestEmails: string[]): Promise<Array<{
        guestEmail: string;
        documentName: string;
        expiresOn: string;
    }>>;
    /**
     * Get active guests for sharing
     */
    getActiveGuestsForSharing(): Promise<Array<{
        email: string;
        name: string;
    }>>;
    /**
     * Copy documents from Project Documents to ExternalShareDocument library
     */
    copyDocumentsToExternalLibrary(documents: any[], targetPath: string): Promise<void>;
    /**
     * Get user's permission for a specific document from SharePoint permissions and SharedDocumentLog
     */
    getUserPermissionForDocument(documentUrl: string): Promise<'Read' | 'Review' | 'Edit' | 'Admin' | null>;
    /**
     * Check SharePoint permissions for the current user on the ExternalShareDocument library
     */
    private _checkSharePointPermissions;
    /**
     * Check if current user is site owner or has full control permissions
     */
    private _checkIfUserIsSiteOwner;
    /**
     * Get user's permission for the current folder path in ExternalShareDocument
     */
    getUserPermissionForFolderPath(folderPath: string): Promise<'Read' | 'Review' | 'Edit' | 'Admin' | null>;
    /**
     * Get access activity log for a specific shared document or folder.
     */
    getDocumentAccessLog(documentUrl: string, guestEmail?: string): Promise<ISharedFileAccessLog[]>;
    /**
     * Build access report for active guests and shared file permissions.
     * Uses latest "Shared" log entry per guest + file.
     */
    getGuestAccessReport(projectId?: number, skipCache?: boolean): Promise<IGuestAccessReportEntry[]>;
    /**
     * Get the Role ('Viewer' | 'Editor') of the current user from ExternalGuestAccess.
     * Returns null if the user is not an external guest or not found.
     */
    getCurrentGuestRole(): Promise<'Viewer' | 'Editor' | null>;
    /**
     * Check if the current logged-in user is in the ExternalGuestAccess list
     * Returns true if the user is a restricted external guest
     */
    isCurrentUserRestrictedGuest(): Promise<boolean>;
    /**
     * Filter documents for restricted external guest users based on SharedDocumentLog
     * Only shows documents that have been explicitly shared with the current user
     */
    private filterDocumentsForRestrictedUser;
}
//# sourceMappingURL=ProjectExternalPortalService.d.ts.map