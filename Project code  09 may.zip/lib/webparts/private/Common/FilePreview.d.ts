import * as React from 'react';
export interface IFilePreviewProps {
    file: {
        name: string;
        url: string;
        serverRelativeUrl: string;
    };
    onClose: () => void;
}
declare const FilePreview: React.FC<IFilePreviewProps>;
export default FilePreview;
//# sourceMappingURL=FilePreview.d.ts.map