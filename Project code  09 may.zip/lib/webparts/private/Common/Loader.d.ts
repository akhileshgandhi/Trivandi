import * as React from 'react';
export interface ILoaderProps {
    variant?: 'full' | 'content';
    message?: string;
}
declare const Loader: React.FC<ILoaderProps>;
export default Loader;
//# sourceMappingURL=Loader.d.ts.map