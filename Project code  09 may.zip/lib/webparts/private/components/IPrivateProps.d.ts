export interface IPrivateProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
    siteUrl: string;
}
//# sourceMappingURL=IPrivateProps.d.ts.map