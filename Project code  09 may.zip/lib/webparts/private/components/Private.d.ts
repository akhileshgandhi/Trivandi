import * as React from 'react';
import { IPrivateProps } from './IPrivateProps';
import '../../../shared/globalcss/globalcss.scss';
declare const Private: React.FC<IPrivateProps>;
export default Private;
//# sourceMappingURL=Private.d.ts.map