declare const styles: {
    private: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Private.module.scss.d.ts.map