import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IPrivateWebPartProps {
    description: string;
}
export default class PrivateWebPart extends BaseClientSideWebPart<IPrivateWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: any | undefined): void;
    protected onDispose(): void;
    protected getPropertyPaneConfiguration(): any;
}
//# sourceMappingURL=PrivateWebPart.d.ts.map