import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/items";
import "@pnp/sp/lists";
export interface IPrivateItem {
    Id: string;
    Name: string;
    ServerRelativeUrl: string;
    Modified: string;
    ModifiedBy: string;
    SizeOrItems: string;
    IsFolder: boolean;
    FileExtension?: string;
}
export declare class PrivateService {
    private sp;
    private libraryName;
    constructor(context: any, libraryName?: string);
    uploadFile(folderPath: string, file: File): Promise<any>;
    createFolder(folderPath: string, folderName: string): Promise<any>;
    downloadFile(serverRelativeUrl: string, fileName: string): Promise<void>;
    getLibraryContents(folderPath?: string): Promise<{
        folders: any[];
        files: any[];
        currentPath: string;
    }>;
    formatBytes(bytes: string | number, decimals?: number): string;
}
//# sourceMappingURL=PrivateService.d.ts.map