import * as React from 'react';
export interface IPrivateProps {
    context: any;
    libraryName?: string;
}
declare const PrivateComponent: React.FC<IPrivateProps>;
export default PrivateComponent;
//# sourceMappingURL=PrivateComponent.d.ts.map