import * as React from "react";
import type { IRequestsProps } from "./IRequestsProps";
import "../../../shared/globalcss/globalcss.scss";
declare const Requests: React.FC<IRequestsProps>;
export default Requests;
//# sourceMappingURL=Requests.d.ts.map