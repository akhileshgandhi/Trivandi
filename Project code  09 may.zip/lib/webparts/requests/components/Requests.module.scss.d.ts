declare const styles: {
    page: string;
    label: string;
    labelLine: string;
    outerBlock: string;
    requestsGrid: string;
};
export default styles;
//# sourceMappingURL=Requests.module.scss.d.ts.map