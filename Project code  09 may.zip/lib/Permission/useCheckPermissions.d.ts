export declare const useCheckPermissions: () => {
    role: import("./PermissionStore").UserRole;
    canAdd: boolean;
    canEdit: boolean;
    canView: boolean;
    isLoading: boolean;
};
//# sourceMappingURL=useCheckPermissions.d.ts.map