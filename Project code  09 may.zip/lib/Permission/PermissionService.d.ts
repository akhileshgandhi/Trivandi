import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare const OWNER_GROUP = "Projects Owners";
export declare const CONTRIBUTOR_GROUP = "Projects Members";
export declare const VIEWER_GROUP = "Projects Visitors";
export declare const AAD_VIEWER_GROUP_ID = "4fd8e847-82b2-4cbc-b376-d4a36abd5316";
export declare const checkPermissions: (context?: WebPartContext) => Promise<void>;
//# sourceMappingURL=PermissionService.d.ts.map