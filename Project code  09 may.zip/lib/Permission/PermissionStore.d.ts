export declare type UserRole = 'Owner' | 'Contributor' | 'Viewer' | 'None';
export interface IPermissionState {
    role: UserRole;
    canAdd: boolean;
    canEdit: boolean;
    canDelete: boolean;
    canView: boolean;
    isOwner: boolean;
    isContributor: boolean;
    isViewer: boolean;
    isLoading: boolean;
    setPermissions: (permissions: Partial<IPermissionState>) => void;
    reset: () => void;
}
export declare const usePermissionStore: import("zustand").UseBoundStore<IPermissionState, import("zustand").StoreApi<IPermissionState>>;
//# sourceMappingURL=PermissionStore.d.ts.map