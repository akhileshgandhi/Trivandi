
require("./RecentDocuments.module.css");
const styles = {
  wrapper: 'wrapper_3d42b150',
  title: 'title_3d42b150',
  documentsList: 'documentsList_3d42b150',
  documentItem: 'documentItem_3d42b150',
  iconWrapper: 'iconWrapper_3d42b150',
  fileIcon: 'fileIcon_3d42b150',
  documentInfo: 'documentInfo_3d42b150',
  fileName: 'fileName_3d42b150',
  metadata: 'metadata_3d42b150',
  emptyState: 'emptyState_3d42b150'
};

export default styles;
