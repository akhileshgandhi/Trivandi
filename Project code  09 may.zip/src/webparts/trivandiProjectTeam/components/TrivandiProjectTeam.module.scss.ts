
require("./TrivandiProjectTeam.module.css");
const styles = {
  dashboard: 'dashboard_7539bc29',
  label: 'label_7539bc29',
  labelLine: 'labelLine_7539bc29',
  topSection: 'topSection_7539bc29',
  topSection2: 'topSection2_7539bc29',
  grid: 'grid_7539bc29',
  gridTwo: 'gridTwo_7539bc29',
  gridFiveSmall: 'gridFiveSmall_7539bc29',
  gridFourLarge: 'gridFourLarge_7539bc29',
  gridDocuments: 'gridDocuments_7539bc29',
  scrollWrapper: 'scrollWrapper_7539bc29',
  CanvasZoneSectionContainer: 'CanvasZoneSectionContainer_7539bc29'
};

export default styles;
