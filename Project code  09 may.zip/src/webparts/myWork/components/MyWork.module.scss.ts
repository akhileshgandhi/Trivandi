
require("./MyWork.module.css");
const styles = {
  dashboard: 'dashboard_0f64481a',
  label: 'label_0f64481a',
  labelLine: 'labelLine_0f64481a',
  emptyState: 'emptyState_0f64481a',
  emptyIcon: 'emptyIcon_0f64481a',
  emptyText: 'emptyText_0f64481a',
  topSection: 'topSection_0f64481a',
  topSection2: 'topSection2_0f64481a',
  grid: 'grid_0f64481a',
  gridTwo: 'gridTwo_0f64481a',
  gridFiveSmall: 'gridFiveSmall_0f64481a',
  gridFourLarge: 'gridFourLarge_0f64481a',
  gridDocuments: 'gridDocuments_0f64481a',
  scrollWrapper: 'scrollWrapper_0f64481a',
  CanvasZoneSectionContainer: 'CanvasZoneSectionContainer_0f64481a'
};

export default styles;
