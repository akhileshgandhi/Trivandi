
require("./RecentDocuments.module.css");
const styles = {
  wrapper: 'wrapper_75719db0',
  title: 'title_75719db0',
  documentsList: 'documentsList_75719db0',
  documentItem: 'documentItem_75719db0',
  iconWrapper: 'iconWrapper_75719db0',
  fileIcon: 'fileIcon_75719db0',
  documentInfo: 'documentInfo_75719db0',
  fileName: 'fileName_75719db0',
  metadata: 'metadata_75719db0',
  emptyState: 'emptyState_75719db0'
};

export default styles;
