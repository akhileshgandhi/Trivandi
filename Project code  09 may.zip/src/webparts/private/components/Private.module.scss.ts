
require("./Private.module.css");
const styles = {
  private: 'private_809bd0bf',
  teams: 'teams_809bd0bf',
  welcome: 'welcome_809bd0bf',
  welcomeImage: 'welcomeImage_809bd0bf',
  links: 'links_809bd0bf'
};

export default styles;
