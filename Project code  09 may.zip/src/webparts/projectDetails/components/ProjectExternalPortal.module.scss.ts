
require("./ProjectExternalPortal.module.css");
const styles = {
  externalPortal: 'externalPortal_b1d9cc0a',
  header: 'header_b1d9cc0a',
  headerLeft: 'headerLeft_b1d9cc0a',
  backIcon: 'backIcon_b1d9cc0a',
  headerInfo: 'headerInfo_b1d9cc0a',
  title: 'title_b1d9cc0a',
  subtitle: 'subtitle_b1d9cc0a',
  tabs: 'tabs_b1d9cc0a',
  tab: 'tab_b1d9cc0a',
  active: 'active_b1d9cc0a',
  portalHeaderContainer: 'portalHeaderContainer_b1d9cc0a',
  content: 'content_b1d9cc0a',
  portalHeader: 'portalHeader_b1d9cc0a',
  portalHeaderLeft: 'portalHeaderLeft_b1d9cc0a',
  portalIcon: 'portalIcon_b1d9cc0a',
  portalTitle: 'portalTitle_b1d9cc0a',
  inviteButton: 'inviteButton_b1d9cc0a',
  portalDescription: 'portalDescription_b1d9cc0a'
};

export default styles;
