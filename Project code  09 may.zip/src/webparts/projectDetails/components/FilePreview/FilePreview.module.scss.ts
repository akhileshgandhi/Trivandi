
require("./FilePreview.module.css");
const styles = {
  modalContainer: 'modalContainer_678c7f77',
  header: 'header_678c7f77',
  headerContent: 'headerContent_678c7f77',
  fileInfo: 'fileInfo_678c7f77',
  fileTypeIcon: 'fileTypeIcon_678c7f77',
  fileTextGroup: 'fileTextGroup_678c7f77',
  fileName: 'fileName_678c7f77',
  filePath: 'filePath_678c7f77',
  closeButton: 'closeButton_678c7f77',
  content: 'content_678c7f77',
  loadingContainer: 'loadingContainer_678c7f77',
  errorContainer: 'errorContainer_678c7f77',
  errorIcon: 'errorIcon_678c7f77',
  imageContainer: 'imageContainer_678c7f77',
  previewImage: 'previewImage_678c7f77',
  readOnlyBar: 'readOnlyBar_678c7f77',
  pdfContainer: 'pdfContainer_678c7f77',
  officeContainer: 'officeContainer_678c7f77',
  textContainer: 'textContainer_678c7f77',
  previewFrame: 'previewFrame_678c7f77',
  iframeBlocker: 'iframeBlocker_678c7f77',
  officeFallback: 'officeFallback_678c7f77',
  fallbackContent: 'fallbackContent_678c7f77',
  fileIcon: 'fileIcon_678c7f77',
  fallbackActions: 'fallbackActions_678c7f77',
  videoContainer: 'videoContainer_678c7f77',
  previewVideo: 'previewVideo_678c7f77',
  unsupportedContainer: 'unsupportedContainer_678c7f77',
  downloadContainer: 'downloadContainer_678c7f77',
  downloadButton: 'downloadButton_678c7f77',
  footer: 'footer_678c7f77',
  actionButton: 'actionButton_678c7f77',
  footerLabel: 'footerLabel_678c7f77'
};

export default styles;
