
require("./Documents.module.css");
const styles = {
  documentsWrapper: 'documentsWrapper_4206757a',
  tabRow: 'tabRow_4206757a',
  documentTabs: 'documentTabs_4206757a',
  docTab: 'docTab_4206757a',
  activeDocTab: 'activeDocTab_4206757a',
  h: 'h_4206757a',
  breadcrumbsContainer: 'breadcrumbsContainer_4206757a',
  breadcrumb: 'breadcrumb_4206757a',
  active: 'active_4206757a',
  breadcrumbSeparator: 'breadcrumbSeparator_4206757a',
  toolbar: 'toolbar_4206757a',
  actionButtons: 'actionButtons_4206757a',
  actionButton: 'actionButton_4206757a',
  deleteButton: 'deleteButton_4206757a',
  newButton: 'newButton_4206757a',
  plusIcon: 'plusIcon_4206757a',
  tableContainer: 'tableContainer_4206757a',
  documentsTable: 'documentsTable_4206757a',
  checkboxCol: 'checkboxCol_4206757a',
  nameCol: 'nameCol_4206757a',
  modifiedCol: 'modifiedCol_4206757a',
  byCol: 'byCol_4206757a',
  tableRow: 'tableRow_4206757a',
  fileName: 'fileName_4206757a',
  fileIcon: 'fileIcon_4206757a',
  noData: 'noData_4206757a',
  pageNumbers: 'pageNumbers_4206757a',
  pageButton: 'pageButton_4206757a'
};

export default styles;
