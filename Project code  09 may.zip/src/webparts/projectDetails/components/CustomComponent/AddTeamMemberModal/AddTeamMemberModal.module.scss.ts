
require("./AddTeamMemberModal.module.css");
const styles = {
  modalOverlay: 'modalOverlay_1eeeabe4',
  fadeIn: 'fadeIn_1eeeabe4',
  modalContent: 'modalContent_1eeeabe4',
  slideUp: 'slideUp_1eeeabe4',
  modalHeader: 'modalHeader_1eeeabe4',
  modalTitle: 'modalTitle_1eeeabe4',
  closeButton: 'closeButton_1eeeabe4',
  modalBody: 'modalBody_1eeeabe4',
  formGroup: 'formGroup_1eeeabe4',
  label: 'label_1eeeabe4',
  input: 'input_1eeeabe4',
  selectWrapper: 'selectWrapper_1eeeabe4',
  select: 'select_1eeeabe4',
  selectIcon: 'selectIcon_1eeeabe4',
  infoMessage: 'infoMessage_1eeeabe4',
  errorMessage: 'errorMessage_1eeeabe4',
  inputWithButton: 'inputWithButton_1eeeabe4',
  actionButtons: 'actionButtons_1eeeabe4',
  callButton: 'callButton_1eeeabe4',
  copyButton: 'copyButton_1eeeabe4',
  copiedToast: 'copiedToast_1eeeabe4',
  slideUpFadeIn: 'slideUpFadeIn_1eeeabe4',
  modalFooter: 'modalFooter_1eeeabe4',
  submitButton: 'submitButton_1eeeabe4'
};

export default styles;
