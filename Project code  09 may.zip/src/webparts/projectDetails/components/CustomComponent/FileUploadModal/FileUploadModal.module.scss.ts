
require("./FileUploadModal.module.css");
const styles = {
  modalOverlay: 'modalOverlay_1b7df210',
  fadeIn: 'fadeIn_1b7df210',
  modalContent: 'modalContent_1b7df210',
  slideUp: 'slideUp_1b7df210',
  modalHeader: 'modalHeader_1b7df210',
  modalTitle: 'modalTitle_1b7df210',
  closeButton: 'closeButton_1b7df210',
  modalBody: 'modalBody_1b7df210',
  dropZone: 'dropZone_1b7df210',
  dragActive: 'dragActive_1b7df210',
  uploadIcon: 'uploadIcon_1b7df210',
  dropText: 'dropText_1b7df210',
  orText: 'orText_1b7df210',
  browseButton: 'browseButton_1b7df210',
  fileSelected: 'fileSelected_1b7df210',
  fileIcon: 'fileIcon_1b7df210',
  fileInfo: 'fileInfo_1b7df210',
  fileName: 'fileName_1b7df210',
  fileSize: 'fileSize_1b7df210',
  removeFile: 'removeFile_1b7df210',
  modalFooter: 'modalFooter_1b7df210',
  cancelButton: 'cancelButton_1b7df210',
  uploadButton: 'uploadButton_1b7df210',
  folderInput: 'folderInput_1b7df210',
  folderNameInput: 'folderNameInput_1b7df210',
  folderActions: 'folderActions_1b7df210',
  createButton: 'createButton_1b7df210',
  actionButtons: 'actionButtons_1b7df210',
  folderIcon: 'folderIcon_1b7df210',
  folderButton: 'folderButton_1b7df210'
};

export default styles;
