
require("./InviteGuestDialog.module.css");
const styles = {
  dialog: 'dialog_bcb55918',
  dialogContent: 'dialogContent_bcb55918',
  field: 'field_bcb55918',
  infoBox: 'infoBox_bcb55918',
  infoIcon: 'infoIcon_bcb55918',
  infoText: 'infoText_bcb55918',
  errorMessage: 'errorMessage_bcb55918',
  errorIcon: 'errorIcon_bcb55918',
  primaryButton: 'primaryButton_bcb55918'
};

export default styles;
