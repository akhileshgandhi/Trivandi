
require("./ImportFromProjectDocsDialog.module.css");
const styles = {
  importDialog: 'importDialog_18aed828',
  documentsWrapper: 'documentsWrapper_18aed828',
  tabRow: 'tabRow_18aed828',
  documentTabs: 'documentTabs_18aed828',
  docTab: 'docTab_18aed828',
  activeDocTab: 'activeDocTab_18aed828',
  breadcrumbHeader: 'breadcrumbHeader_18aed828',
  breadcrumbsContainer: 'breadcrumbsContainer_18aed828',
  breadcrumb: 'breadcrumb_18aed828',
  active: 'active_18aed828',
  breadcrumbSeparator: 'breadcrumbSeparator_18aed828',
  tableContainer: 'tableContainer_18aed828',
  documentsTable: 'documentsTable_18aed828',
  tableRow: 'tableRow_18aed828',
  selected: 'selected_18aed828',
  imported: 'imported_18aed828',
  nameCol: 'nameCol_18aed828',
  fileIcon: 'fileIcon_18aed828',
  fileName: 'fileName_18aed828',
  folderName: 'folderName_18aed828',
  importedLabel: 'importedLabel_18aed828',
  modifiedCol: 'modifiedCol_18aed828',
  byCol: 'byCol_18aed828'
};

export default styles;
