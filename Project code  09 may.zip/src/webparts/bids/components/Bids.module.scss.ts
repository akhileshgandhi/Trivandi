
require("./Bids.module.css");
const styles = {
  columnPopupOverlay: 'columnPopupOverlay_6bdac142',
  columnPopup: 'columnPopup_6bdac142',
  columnList: 'columnList_6bdac142',
  popupActions: 'popupActions_6bdac142',
  columnRow: 'columnRow_6bdac142',
  columnItem: 'columnItem_6bdac142',
  reorderBtns: 'reorderBtns_6bdac142',
  columnContent: 'columnContent_6bdac142',
  columnLabel: 'columnLabel_6bdac142',
  dragHandle: 'dragHandle_6bdac142',
  columnPopupHeader: 'columnPopupHeader_6bdac142',
  columnSearch: 'columnSearch_6bdac142',
  availableColumnRow: 'availableColumnRow_6bdac142',
  pipelineTitle: 'pipelineTitle_6bdac142',
  availableColumnLabel: 'availableColumnLabel_6bdac142'
};

export default styles;
