
require("./Requests.module.css");
const styles = {
  page: 'page_e6f3c0e0',
  label: 'label_e6f3c0e0',
  labelLine: 'labelLine_e6f3c0e0',
  outerBlock: 'outerBlock_e6f3c0e0',
  requestsGrid: 'requestsGrid_e6f3c0e0'
};

export default styles;
