
require("./RecentDocuments.module.css");
const styles = {
  wrapper: 'wrapper_9a1d1c3e',
  title: 'title_9a1d1c3e',
  documentsList: 'documentsList_9a1d1c3e',
  documentItem: 'documentItem_9a1d1c3e',
  iconWrapper: 'iconWrapper_9a1d1c3e',
  fileIcon: 'fileIcon_9a1d1c3e',
  documentInfo: 'documentInfo_9a1d1c3e',
  fileName: 'fileName_9a1d1c3e',
  metadata: 'metadata_9a1d1c3e',
  emptyState: 'emptyState_9a1d1c3e'
};

export default styles;
