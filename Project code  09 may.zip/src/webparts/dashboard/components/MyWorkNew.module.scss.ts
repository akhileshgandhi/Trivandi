
require("./MyWorkNew.module.css");
const styles = {
  dashboard: 'dashboard_718e2fd1',
  label: 'label_718e2fd1',
  labelLine: 'labelLine_718e2fd1',
  emptyState: 'emptyState_718e2fd1',
  emptyIcon: 'emptyIcon_718e2fd1',
  emptyText: 'emptyText_718e2fd1',
  topSection: 'topSection_718e2fd1',
  topSection2: 'topSection2_718e2fd1',
  grid: 'grid_718e2fd1',
  gridTwo: 'gridTwo_718e2fd1',
  gridFiveSmall: 'gridFiveSmall_718e2fd1',
  gridFourLarge: 'gridFourLarge_718e2fd1',
  gridDocuments: 'gridDocuments_718e2fd1',
  scrollWrapper: 'scrollWrapper_718e2fd1',
  CanvasZoneSectionContainer: 'CanvasZoneSectionContainer_718e2fd1'
};

export default styles;
