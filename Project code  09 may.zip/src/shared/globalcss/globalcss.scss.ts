
require("./globalcss.css");
const styles = {

};

export default styles;
