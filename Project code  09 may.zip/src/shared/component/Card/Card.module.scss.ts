
require("./Card.module.css");
const styles = {
  card: 'card_a935cb22',
  icon: 'icon_a935cb22',
  iconRight: 'iconRight_a935cb22',
  iconNoBg: 'iconNoBg_a935cb22',
  fileIcon: 'fileIcon_a935cb22',
  invoiceIcon: 'invoiceIcon_a935cb22',
  cardContent: 'cardContent_a935cb22',
  timeIcon: 'timeIcon_a935cb22',
  cardDocument: 'cardDocument_a935cb22',
  coloredCard: 'coloredCard_a935cb22'
};

export default styles;
