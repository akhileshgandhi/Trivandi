
require("./GlobalLoader.module.css");
const styles = {
  overlay: 'overlay_1bef7d89',
  contentWrapper: 'contentWrapper_1bef7d89',
  saturationLoader: 'saturationLoader_1bef7d89',
  loaderRing: 'loaderRing_1bef7d89',
  saturationSpin: 'saturationSpin_1bef7d89',
  loaderCore: 'loaderCore_1bef7d89',
  saturationPulse: 'saturationPulse_1bef7d89'
};

export default styles;
