
require("./Pagination.module.css");
const styles = {
  paginationContainer: 'paginationContainer_5f6359ae',
  paginationLeft: 'paginationLeft_5f6359ae',
  paginationInfo: 'paginationInfo_5f6359ae',
  pageSizeSelector: 'pageSizeSelector_5f6359ae',
  pageSizeDropdown: 'pageSizeDropdown_5f6359ae',
  paginationControls: 'paginationControls_5f6359ae',
  pageNumbers: 'pageNumbers_5f6359ae',
  pageBtn: 'pageBtn_5f6359ae',
  dots: 'dots_5f6359ae',
  activePage: 'activePage_5f6359ae'
};

export default styles;
