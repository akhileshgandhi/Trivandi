
require("./CompletedCell.module.css");
const styles = {
  completedWrapper: 'completedWrapper_3d462fc0',
  percent: 'percent_3d462fc0',
  bar: 'bar_3d462fc0',
  fill: 'fill_3d462fc0',
  critical: 'critical_3d462fc0',
  low: 'low_3d462fc0',
  medium: 'medium_3d462fc0',
  high: 'high_3d462fc0',
  complete: 'complete_3d462fc0'
};

export default styles;
