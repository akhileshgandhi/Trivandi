
require("./TrackerTable.module.css");
const styles = {
  trackerWrapper: 'trackerWrapper_ca725b31',
  title: 'title_ca725b31',
  controls: 'controls_ca725b31',
  withDivider: 'withDivider_ca725b31',
  tabs: 'tabs_ca725b31',
  tab: 'tab_ca725b31',
  activeTab: 'activeTab_ca725b31',
  tabCount: 'tabCount_ca725b31',
  filterBtn: 'filterBtn_ca725b31',
  resetBtn: 'resetBtn_ca725b31',
  filterBtnActive: 'filterBtnActive_ca725b31',
  filterIcon: 'filterIcon_ca725b31',
  outerContainer: 'outerContainer_ca725b31',
  filtersRow: 'filtersRow_ca725b31',
  pagination: 'pagination_ca725b31',
  pageInfo: 'pageInfo_ca725b31',
  reset: 'reset_ca725b31',
  createBtn: 'createBtn_ca725b31',
  searchBox: 'searchBox_ca725b31',
  searchInput: 'searchInput_ca725b31',
  searchIcon: 'searchIcon_ca725b31',
  clearSearchBtn: 'clearSearchBtn_ca725b31'
};

export default styles;
