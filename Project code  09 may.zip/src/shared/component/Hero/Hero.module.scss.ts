
require("./Hero.module.css");
const styles = {
  hero: 'hero_79c5ef1b',
  leftSpacing: 'leftSpacing_79c5ef1b'
};

export default styles;
