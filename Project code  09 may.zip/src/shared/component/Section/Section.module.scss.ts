
require("./Section.module.css");
const styles = {
  sectionHeader: 'sectionHeader_cda6753f',
  viewAll: 'viewAll_cda6753f',
  bgW: 'bgW_cda6753f'
};

export default styles;
