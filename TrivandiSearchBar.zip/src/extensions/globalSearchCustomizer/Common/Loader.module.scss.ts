/* tslint:disable */
require("./Loader.module.css");
const styles = {
  overlay: 'overlay_02327a51',
  contentWrapper: 'contentWrapper_02327a51',
  saturationLoader: 'saturationLoader_02327a51',
  loaderRing: 'loaderRing_02327a51',
  saturationSpin: 'saturationSpin_02327a51',
  loaderCore: 'loaderCore_02327a51',
  saturationPulse: 'saturationPulse_02327a51'
};

export default styles;
/* tslint:enable */