import { ISearchResult } from '../models/ISearchResult';
export declare function rerankResults(results: ISearchResult[], getClickCount: (id: string) => number, query?: string): ISearchResult[];
//# sourceMappingURL=rerankResults.d.ts.map