export declare const STATIC_BRAND_TERMS: string[];
export declare function getLevenshteinDistance(a: string, b: string): number;
export declare function fuzzyBrandMatch(query: string, terms: string[]): string | null;
//# sourceMappingURL=brandDictionary.d.ts.map