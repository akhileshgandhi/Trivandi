export declare const SYNONYMS: Record<string, string[]>;
export declare function expandQuery(query: string): string;
//# sourceMappingURL=synonymDictionary.d.ts.map