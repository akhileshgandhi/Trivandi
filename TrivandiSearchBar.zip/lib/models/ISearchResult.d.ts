export interface ISearchResult {
    id: string;
    title: string;
    webUrl: string;
    fileType: string;
    lastModified: string;
    author: string;
    originalAuthor?: string;
    size: number;
    summary: string;
    siteUrl: string;
    siteName: string;
    isStarred?: boolean;
    thumbnailUrl?: string;
    thumbnailUrlLarge?: string;
    createdDate?: string;
    objectType?: string;
    relevanceScore?: number;
    authorEmail?: string;
    driveId?: string;
    itemId?: string;
    authorPhotoUrl?: string;
    libraryUrl?: string;
}
//# sourceMappingURL=ISearchResult.d.ts.map