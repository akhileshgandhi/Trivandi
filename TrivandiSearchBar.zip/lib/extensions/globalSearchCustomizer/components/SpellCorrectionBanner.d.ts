import * as React from 'react';
export interface ISpellCorrectionBannerProps {
    correctedQuery: string | null;
    originalQuery: string;
    onUseOriginal: () => void;
}
export declare const SpellCorrectionBanner: React.FC<ISpellCorrectionBannerProps>;
//# sourceMappingURL=SpellCorrectionBanner.d.ts.map