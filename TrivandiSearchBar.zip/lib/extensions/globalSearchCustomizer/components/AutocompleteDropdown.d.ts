import * as React from 'react';
import { ISuggestion } from '../hooks/useAutocomplete';
export interface IAutocompleteDropdownProps {
    suggestions: ISuggestion[];
    onSelect: (label: string) => void;
    activeIndex: number;
}
export declare const AutocompleteDropdown: React.FC<IAutocompleteDropdownProps>;
//# sourceMappingURL=AutocompleteDropdown.d.ts.map