import * as React from 'react';
interface ISearchErrorBoundaryState {
    hasError: boolean;
    error: Error | null;
}
export declare class SearchErrorBoundary extends React.Component<React.PropsWithChildren<{}>, ISearchErrorBoundaryState> {
    constructor(props: React.PropsWithChildren<{}>);
    static getDerivedStateFromError(error: Error): ISearchErrorBoundaryState;
    componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void;
    render(): React.ReactNode;
}
export {};
//# sourceMappingURL=SearchErrorBoundary.d.ts.map