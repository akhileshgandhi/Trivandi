import { MSGraphClientFactory } from '@microsoft/sp-http';
import { ISearchResult } from '../../../models/ISearchResult';
export declare class GraphSearchService {
    private _msGraphClientFactory;
    private _spHttpClient;
    private _siteUrl;
    constructor(msGraphClientFactory: MSGraphClientFactory, spHttpClient?: any, siteUrl?: string);
    private _getTenantUrl;
    search(query: string, pageSize?: number, from?: number, fileTypes?: string[], activeTopTab?: string, date?: string, selectedAuthors?: string[], selectedSites?: string[], sortBy?: string): Promise<{
        results: ISearchResult[];
        totalCount: number;
        suggestedQuery?: string;
    }>;
    private sortAuthorsList;
    getAuthors(query?: string): Promise<string[]>;
    fetchIndexedTerms(): Promise<string[]>;
    fetchPeopleNames(): Promise<string[]>;
    searchFileSuggestions(query: string): Promise<string[]>;
}
//# sourceMappingURL=GraphSearchService.d.ts.map