export declare class RetryService {
    static withRetry<T>(fn: () => Promise<T>, maxRetries?: number): Promise<T>;
}
//# sourceMappingURL=RetryService.d.ts.map