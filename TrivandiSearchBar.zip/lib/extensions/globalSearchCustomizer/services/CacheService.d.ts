import { ServiceKey } from "@microsoft/sp-core-library";
export declare class CacheService {
    static readonly serviceKey: ServiceKey<CacheService>;
    private static _cache;
    private static DEFAULT_TTL;
    private static MAX_ENTRIES;
    private static _hits;
    private static _misses;
    private static _cleanupTimer;
    static TTL: {
        readonly SEARCH: number;
        readonly THUMBNAILS: number;
        readonly USER_PHOTOS: number;
        readonly SITE_META: number;
    };
    static buildKey(query: string, fileTypes: string[], date: string, selectedAuthors: string[], selectedSites: string[], from: number, activeTopTab: string, sortBy: string): string;
    static get(key: string): any | null;
    static set(key: string, data: any, ttl?: number): void;
    static invalidate(key: string): void;
    static invalidateByPrefix(prefix: string): void;
    static clear(): void;
    static getStats(): {
        hits: number;
        misses: number;
        hitRate: string;
        size: number;
    };
    static startCleanup(intervalMs?: number): void;
    static stopCleanup(): void;
    private static _evictExpired;
    private static _evictOldest;
}
//# sourceMappingURL=CacheService.d.ts.map