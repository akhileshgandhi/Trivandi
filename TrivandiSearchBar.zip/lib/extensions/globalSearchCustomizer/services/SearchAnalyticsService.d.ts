export interface IQueryAnalytic {
    query: string;
    count: number;
    lastSearched: string;
}
export interface IClickedDocumentAnalytic {
    id: string;
    title: string;
    url: string;
    clickCount: number;
    lastClicked: string;
}
export declare class SearchAnalyticsService {
    private static QUERIES_KEY;
    private static CLICKS_KEY;
    /**
     * Tracks a successful search query by incrementing its count
     */
    static trackSearchQuery(query: string): void;
    /**
     * Tracks a clicked search result card
     */
    static trackCardClick(resultId: string, resultTitle: string, webUrl: string): void;
    /**
     * Gets top search queries sorted by count
     */
    static getTopQueries(limit?: number): IQueryAnalytic[];
    /**
     * Gets top clicked documents
     */
    static getTopClickedDocuments(limit?: number): IClickedDocumentAnalytic[];
    /**
     * Clears all search analytics databases
     */
    static clearAnalytics(): void;
    static getClickCount(id: string): number;
    static recordClick(id: string): void;
}
//# sourceMappingURL=SearchAnalyticsService.d.ts.map