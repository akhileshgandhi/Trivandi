import { GraphSearchService } from '../services/GraphSearchService';
export interface ISuggestion {
    label: string;
    type: 'history' | 'file' | 'suggested';
}
export declare function useAutocomplete(query: string, service: GraphSearchService | null): {
    suggestions: ISuggestion[];
    loading: boolean;
    clearSuggestions: () => void;
};
//# sourceMappingURL=useAutocomplete.d.ts.map