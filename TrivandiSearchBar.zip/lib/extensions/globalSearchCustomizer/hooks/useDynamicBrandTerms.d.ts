import { GraphSearchService } from '../services/GraphSearchService';
export declare function useDynamicBrandTerms(service: GraphSearchService | null): string[];
//# sourceMappingURL=useDynamicBrandTerms.d.ts.map