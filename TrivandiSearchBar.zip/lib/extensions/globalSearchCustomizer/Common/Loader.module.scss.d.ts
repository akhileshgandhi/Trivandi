declare const styles: {
    overlay: string;
    contentWrapper: string;
    saturationLoader: string;
    loaderRing: string;
    saturationSpin: string;
    loaderCore: string;
    saturationPulse: string;
};
export default styles;
//# sourceMappingURL=Loader.module.scss.d.ts.map