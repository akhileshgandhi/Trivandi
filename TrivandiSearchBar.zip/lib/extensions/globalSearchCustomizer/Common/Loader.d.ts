import * as React from "react";
interface GlobalLoaderProps {
    variant?: "overlay" | "content";
}
export declare const Loader: React.FC<GlobalLoaderProps>;
export default Loader;
//# sourceMappingURL=Loader.d.ts.map