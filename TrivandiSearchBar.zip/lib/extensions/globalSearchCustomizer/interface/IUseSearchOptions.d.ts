import { GraphSearchService } from '../services/GraphSearchService';
export interface IUseSearchOptions {
    service: GraphSearchService | null;
    initialQuery?: string;
    pageSize?: number;
    dynamicTerms?: string[];
    selectedSites?: string[];
}
//# sourceMappingURL=IUseSearchOptions.d.ts.map