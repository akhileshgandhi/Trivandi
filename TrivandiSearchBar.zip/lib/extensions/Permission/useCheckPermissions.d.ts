import { UserRole } from './PermissionStore';
export interface ICheckPermissionsResult {
    role: UserRole;
    canAdd: boolean;
    canEdit: boolean;
    canDelete: boolean;
    canView: boolean;
    isLoading: boolean;
}
export declare const useCheckPermissions: (context?: any) => ICheckPermissionsResult;
//# sourceMappingURL=useCheckPermissions.d.ts.map