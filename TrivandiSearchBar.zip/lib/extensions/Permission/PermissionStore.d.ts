export declare type UserRole = 'Owner' | 'Contributor' | 'Viewer' | 'None';
export interface IPermissionState {
    role: UserRole;
    canAdd: boolean;
    canEdit: boolean;
    canDelete: boolean;
    canView: boolean;
    isOwner: boolean;
    isContributor: boolean;
    isViewer: boolean;
    isLoading: boolean;
    allowedSites: string[];
    setPermissions: (permissions: Partial<IPermissionState>) => void;
    reset: () => void;
}
export declare const usePermissionStore: import("zustand").UseBoundStore<import("zustand").StoreApi<IPermissionState>>;
//# sourceMappingURL=PermissionStore.d.ts.map