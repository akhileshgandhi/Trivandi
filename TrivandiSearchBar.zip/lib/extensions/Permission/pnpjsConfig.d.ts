import { BaseComponentContext } from "@microsoft/sp-component-base";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";
import "@pnp/sp/site-users/web";
import "@pnp/sp/profiles";
import "@pnp/sp/items/get-all";
import "@pnp/sp/folders";
import "@pnp/sp/files/folder";
import "@pnp/sp/fields";
import "@pnp/sp/files";
import "@pnp/sp/security";
import "@pnp/sp/presets/all";
export declare const getSP: (context?: BaseComponentContext | any) => SPFI;
export declare const getSPContext: (context?: BaseComponentContext | any) => SPFI;
//# sourceMappingURL=pnpjsConfig.d.ts.map