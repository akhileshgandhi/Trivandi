import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import "@pnp/sp/site-groups/web";
export declare const OWNER_GROUP: string[];
export declare const CONTRIBUTOR_GROUP: string[];
export declare const VIEWER_GROUP: string[];
export declare const AAD_VIEWER_GROUP_ID: string[];
export declare const checkPermissions: (context?: any) => Promise<void>;
//# sourceMappingURL=PermissionService.d.ts.map